﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace serverComp
{
    class ForPCOperationImpl : MarshalByRefObject, ForPCOperation
    {
        public static List<ForPC> lstTovarF = new List<ForPC>();
        public List<ForPC> addTovarF(ForPC item)
        {
            lstTovarF.Add(item);
            return lstTovarF;
        }

        public List<ForPC> delTovarF(int index)
        {
            lstTovarF.RemoveAt(index);
            return lstTovarF;
        }

        public List<ForPC> getListOfTovarF()
        {
            return lstTovarF;
        }

        public int getSumOfTovarF()
        {
            int sum = 0;
            foreach (ForPC forpc in lstTovarF)
                sum += forpc.getKolF() * forpc.getPriceF();
            return sum;
        }
    }
}
