﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace serverComp
{
    public interface ForPCOperation
    {
        List<ForPC> getListOfTovarF();
        List<ForPC> addTovarF(ForPC item);
        List<ForPC> delTovarF(int index);
        int getSumOfTovarF();
    }
}
