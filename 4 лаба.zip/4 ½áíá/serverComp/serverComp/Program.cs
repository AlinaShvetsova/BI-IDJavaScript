﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;


namespace serverComp
{
    class Program
    {
        static void Main()
        {
            // Register channel
            TcpChannel channel = new TcpChannel(9000);
            ChannelServices.RegisterChannel(channel, false);
            TovarOperationImpl lstTovar = new TovarOperationImpl();
            lstTovar.addNewTovar(new Tovar("Товар1", 10, 100));
            lstTovar.addNewTovar(new Tovar("Товар2", 20, 200));
            lstTovar.addNewTovar(new Tovar("Товар3", 30, 300));
            lstTovar.addNewTovar(new Tovar("Товар4", 40, 400));
            RemotingServices.Marshal(lstTovar, "TalkIsGoodTovar");

            
            AccesuarsOperationImpl lstTovarA = new AccesuarsOperationImpl();
            lstTovarA.addNewTovarA(new Accesuars("Товар1", 10, 100));
            lstTovarA.addNewTovarA(new Accesuars("Товар2", 20, 200));
            lstTovarA.addNewTovarA(new Accesuars("Товар3", 30, 300));
            lstTovarA.addNewTovarA(new Accesuars("Товар4", 40, 400));
            RemotingServices.Marshal(lstTovarA, "TalkIsGoodAccesuars");

            
            ForPCOperationImpl lstTovarF = new ForPCOperationImpl();
            lstTovarF.addTovarF(new ForPC("Товар1", 10, 100));
            lstTovarF.addTovarF(new ForPC("Товар2", 20, 200));
            lstTovarF.addTovarF(new ForPC("Товар3", 30, 300));
            lstTovarF.addTovarF(new ForPC("Товар4", 40, 400));
            RemotingServices.Marshal(lstTovarF, "TalkIsGoodForPC");
            // Register MyRemoteObject
            /* RemotingConfiguration.RegisterWellKnownServiceType(
                 typeof(TovarOperationImpl),
                 "TalkIsGood",
                 WellKnownObjectMode.Singleton);*/
            // Также можно зарегестрировать не тип, а неоходимый объект:

            //lstTovar – объект, который необходимо передать, "TalkIsGood" - параметр, который //используется клиентом для активизации объекта (унифицированный идентификатор ресурса)
            Console.WriteLine("Press enter to stop this process.");
            Console.ReadLine();
        }
    }
}

