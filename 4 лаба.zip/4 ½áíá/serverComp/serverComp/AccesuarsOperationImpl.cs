﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace serverComp
{
    public class AccesuarsOperationImpl : MarshalByRefObject, AccesuarsOperation
    {
        public static List<Accesuars> lstTovarA = new List<Accesuars>();

        public List<Accesuars> addNewTovarA(Accesuars item)
        {
            lstTovarA.Add(item);
            return lstTovarA;
        }

        public List<Accesuars> delTovarA(int index)
        {
            lstTovarA.RemoveAt(index);
            return lstTovarA;
        }

        public List<Accesuars> getListOfTovarA()
        {
            return lstTovarA;
        }

        public int getSumOfTovarA()
        {
            int sum = 0;
            foreach (Accesuars accesuars in lstTovarA)
                sum += accesuars.getKolA() * accesuars.getPriceA();
            return sum;
        } 
    }
}


    
