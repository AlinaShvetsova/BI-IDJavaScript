﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace serverComp
{
    [Serializable]
    public class Accesuars
    {
    private String nameA;
    private int kolA;
    private int priceA;

    public Accesuars()
    {
        this.nameA = "";
        this.kolA = 0;
        this.priceA = 0;
    }

    public Accesuars(String nameA, int kolA, int priceA)
    {
        this.nameA = nameA;
        this.kolA = kolA;
        this.priceA = priceA;
    }

    public String getNameA()
    {
        return nameA;
    }

    public void setNameA(String nameA)
    {
        this.nameA = nameA;
    }

    public int getKolA()
    {
        return kolA;
    }

    public void setKolA(int kolA)
    {
        this.kolA = kolA;
    }

    public int getPriceA()
    {
        return priceA;
    }

    public void setPriceA(int priceA)
    {
        this.priceA = priceA;
    }}}
