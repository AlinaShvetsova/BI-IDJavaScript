﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace serverComp
{
    [Serializable]
    public class ForPC
    {
    private String nameF;
    private int kolF;
    private int priceF;

    public ForPC()
    {
        this.nameF = "";
        this.kolF = 0;
        this.priceF = 0;
    }

    public ForPC(String nameF, int kolF, int priceF)
    {
        this.nameF = nameF;
        this.kolF = kolF;
        this.priceF = priceF;
    }

    public String getNameF()
    {
        return nameF;
    }

    public void setNameF(String nameF)
    {
        this.nameF = nameF;
    }

    public int getKolF()
    {
        return kolF;
    }

    public void setKolF(int kolF)
    {
        this.kolF = kolF;
    }

    public int getPriceF()
    {
        return priceF;
    }

    public void setPriceF(int priceF)
    {
        this.priceF = priceF;
    }

}

}
