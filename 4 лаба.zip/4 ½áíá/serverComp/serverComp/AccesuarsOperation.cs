﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace serverComp
{
    public interface AccesuarsOperation
    {
        List<Accesuars> getListOfTovarA();
        List<Accesuars> addNewTovarA(Accesuars item);
        List<Accesuars> delTovarA(int index);
        int getSumOfTovarA();
    }
}
