﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using serverComp;


namespace Computer
{
    public partial class addASUS : Form
    {
        public addASUS()
        {
            InitializeComponent();
        }

        private void addASUS_Load(object sender, EventArgs e)
        {
            cmbNameAs.SelectedIndex = 0;
        }
        Tovar tovar = null;
        public Tovar getTovar
        {
            get
            {
                return tovar;
            }
        }
        public addASUS(TovarOperation tovarOperation)
        {
            InitializeComponent();
            this.tovarOperation = tovarOperation;
        }
        TovarOperation tovarOperation = null;
        private void btnCancelAs_Click(object sender, EventArgs e)
        {
            
            Post p = new Post();
            p.ShowDialog();
        }

        private void btnAddTovarAs_Click(object sender, EventArgs e)
        {

            //код проверки на правильность ввода
            if (rdbYesParamAs.Checked)
            {
                tovar = new Tovar(cmbNameAs.SelectedItem.ToString(), Convert.ToInt32(spnKolAs.Value), scrPrice.Value);
            }
            else
            {
                tovar = new Tovar();
                tovar.setName(cmbNameAs.SelectedItem.ToString());
                tovar.setKol(Convert.ToInt32(spnKolAs.Value));
                tovar.setPrice(scrPrice.Value);
            }
            if (tovarOperation != null)
            {
                tovarOperation.addNewTovar(tovar);
            }
            this.Close();
        }
    }
}
