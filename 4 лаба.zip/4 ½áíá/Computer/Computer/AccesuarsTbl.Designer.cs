﻿namespace Computer
{
    partial class AccesuarsTbl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvListA = new System.Windows.Forms.ListView();
            this.Номер = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Название = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Цена = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Количество = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Сумма = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.txtA = new System.Windows.Forms.TextBox();
            this.lbl = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.btnAddA = new System.Windows.Forms.ToolStripMenuItem();
            this.btnDecideA = new System.Windows.Forms.ToolStripMenuItem();
            this.btnDelA = new System.Windows.Forms.ToolStripMenuItem();
            this.btnUpdateA = new System.Windows.Forms.ToolStripMenuItem();
            this.btnCancelA = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lvListA
            // 
            this.lvListA.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Номер,
            this.Название,
            this.Цена,
            this.Количество,
            this.Сумма});
            this.lvListA.GridLines = true;
            this.lvListA.HideSelection = false;
            this.lvListA.Location = new System.Drawing.Point(29, 38);
            this.lvListA.Name = "lvListA";
            this.lvListA.Size = new System.Drawing.Size(302, 163);
            this.lvListA.TabIndex = 11;
            this.lvListA.UseCompatibleStateImageBehavior = false;
            this.lvListA.View = System.Windows.Forms.View.Details;
            // 
            // Номер
            // 
            this.Номер.Text = "№";
            this.Номер.Width = 31;
            // 
            // Название
            // 
            this.Название.Text = "Название";
            this.Название.Width = 72;
            // 
            // Цена
            // 
            this.Цена.Text = "Цена";
            this.Цена.Width = 74;
            // 
            // Количество
            // 
            this.Количество.Text = "Количество";
            this.Количество.Width = 55;
            // 
            // Сумма
            // 
            this.Сумма.Text = "Сумма";
            this.Сумма.Width = 91;
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(166, 223);
            this.txtA.Name = "txtA";
            this.txtA.ReadOnly = true;
            this.txtA.Size = new System.Drawing.Size(100, 20);
            this.txtA.TabIndex = 10;
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.Location = new System.Drawing.Point(44, 226);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(116, 13);
            this.lbl.TabIndex = 9;
            this.lbl.Text = "Общая сумма товара";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.btnAddA,
            this.btnDecideA,
            this.btnDelA,
            this.btnUpdateA,
            this.btnCancelA});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(376, 24);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(12, 20);
            // 
            // btnAddA
            // 
            this.btnAddA.Name = "btnAddA";
            this.btnAddA.Size = new System.Drawing.Size(71, 20);
            this.btnAddA.Text = "Добавить";
            this.btnAddA.Click += new System.EventHandler(this.btnAddA_Click);
            // 
            // btnDecideA
            // 
            this.btnDecideA.Name = "btnDecideA";
            this.btnDecideA.Size = new System.Drawing.Size(80, 20);
            this.btnDecideA.Text = "Вычислить";
            this.btnDecideA.Click += new System.EventHandler(this.btnDecideA_Click);
            // 
            // btnDelA
            // 
            this.btnDelA.Name = "btnDelA";
            this.btnDelA.Size = new System.Drawing.Size(63, 20);
            this.btnDelA.Text = "Удалить";
            this.btnDelA.Click += new System.EventHandler(this.btnDelA_Click);
            // 
            // btnUpdateA
            // 
            this.btnUpdateA.Name = "btnUpdateA";
            this.btnUpdateA.Size = new System.Drawing.Size(73, 20);
            this.btnUpdateA.Text = "Обновить";
            this.btnUpdateA.Click += new System.EventHandler(this.btnUpdateA_Click);
            // 
            // btnCancelA
            // 
            this.btnCancelA.Name = "btnCancelA";
            this.btnCancelA.Size = new System.Drawing.Size(51, 20);
            this.btnCancelA.Text = "Назад";
            this.btnCancelA.Click += new System.EventHandler(this.btnCancelA_Click);
            // 
            // AccesuarsTbl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(376, 271);
            this.Controls.Add(this.lvListA);
            this.Controls.Add(this.txtA);
            this.Controls.Add(this.lbl);
            this.Controls.Add(this.menuStrip1);
            this.Name = "AccesuarsTbl";
            this.Text = "AccesuarsTbl";
            this.Load += new System.EventHandler(this.AccesuarsTbl_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView lvListA;
        private System.Windows.Forms.ColumnHeader Номер;
        private System.Windows.Forms.ColumnHeader Название;
        private System.Windows.Forms.ColumnHeader Цена;
        private System.Windows.Forms.ColumnHeader Количество;
        private System.Windows.Forms.ColumnHeader Сумма;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem btnAddA;
        private System.Windows.Forms.ToolStripMenuItem btnDecideA;
        private System.Windows.Forms.ToolStripMenuItem btnDelA;
        private System.Windows.Forms.ToolStripMenuItem btnUpdateA;
        private System.Windows.Forms.ToolStripMenuItem btnCancelA;
    }
}