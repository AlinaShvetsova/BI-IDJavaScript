﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using serverComp;

namespace Computer
{
    public partial class ComputersTbl : Form
    {
        public ComputersTbl()
        {
            InitializeComponent();
        }
        TcpClientChannel chan = new TcpClientChannel();
        public void doVivod(List<serverComp.Tovar> lstTovar)
        {
            lvList.Items.Clear();
            int i = 1;
            foreach (serverComp.Tovar tovar in lstTovar)
            {
                ListViewItem newItem = new ListViewItem(i.ToString());
                lvList.Items.Add(newItem);
                newItem.SubItems.Add(tovar.getName());
                newItem.SubItems.Add(tovar.getPrice().ToString());
                newItem.SubItems.Add(tovar.getKol().ToString());
                newItem.SubItems.Add((tovar.getKol() * tovar.getPrice()).ToString());
                i++;
            }
        }
        TovarOperation tovarOperation = null;
        private void btnAdd_Click(object sender, EventArgs e)
        {
            Post p = new Post();
            p.ShowDialog();
            
        }

        private void ComputersTbl_Load(object sender, EventArgs e)
        {
            try
            {
                ChannelServices.RegisterChannel(chan, false);
                tovarOperation = (TovarOperation)Activator.GetObject(
                typeof(TovarOperation), "tcp://localhost:9000/TalkIsGoodTovar");
                doVivod(tovarOperation.getListOfTovar());
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDecide_Click(object sender, EventArgs e)
        {
            try
            {
                txt.Text = tovarOperation.getSumOfTovar().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (lvList.SelectedIndices.Count < 1)
            {
                MessageBox.Show(this, "Выберите элемент для удаления!", "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                try
                {
                    tovarOperation.delTovar(lvList.SelectedIndices[0]);
                    doVivod(tovarOperation.getListOfTovar());
                    if (lbl.Text != "") btnDecide_Click(sender, e);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                doVivod(tovarOperation.getListOfTovar());
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancelC_Click(object sender, EventArgs e)
        {
            this.Close();
            ChannelServices.UnregisterChannel(chan);
        }
    }
}
