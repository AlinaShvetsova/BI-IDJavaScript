﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using serverComp;

namespace Computer
{
    public partial class AccesuarsTbl : Form
    {
        public AccesuarsTbl()
        {
            InitializeComponent();
        }

        private void doVivod()
        {
            List<serverComp.Accesuars> lstTovarA = accesuarsOperation.getListOfTovarA();
            lvListA.Items.Clear();
            int i = 1;
            foreach (serverComp.Accesuars accesuars in lstTovarA)
            {
                ListViewItem newItem = new ListViewItem(i.ToString());
                lvListA.Items.Add(newItem);
                newItem.SubItems.Add(accesuars.getNameA());
                newItem.SubItems.Add(accesuars.getPriceA().ToString());
                newItem.SubItems.Add(accesuars.getKolA().ToString());
                newItem.SubItems.Add((accesuars.getKolA() * accesuars.getPriceA()).ToString());
                i++;
            }
        }
        AccesuarsOperation accesuarsOperation = null;
        TcpClientChannel chanA = new TcpClientChannel();
        private void btnCancelA_Click(object sender, EventArgs e)
        {
            this.Close();
            ChannelServices.UnregisterChannel(chanA);
        }

        private void btnUpdateA_Click(object sender, EventArgs e)
        {
            try
            {
                doVivod();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelA_Click(object sender, EventArgs e)
        {
            if (lvListA.SelectedIndices.Count < 1)
            {
                MessageBox.Show(this, "Выберите элемент для удаления!", "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                try
                {
                    accesuarsOperation.delTovarA(lvListA.SelectedIndices[0]);
                    doVivod();
                    if (lbl.Text != "")
                        btnDecideA_Click(sender, e);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnAddA_Click(object sender, EventArgs e)
        {
            addAcc p = new addAcc(accesuarsOperation);
            p.ShowDialog();
                try
                {
                    doVivod();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        private void btnDecideA_Click(object sender, EventArgs e)
        {
            try
            {
                txtA.Text = accesuarsOperation.getSumOfTovarA().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AccesuarsTbl_Load(object sender, EventArgs e)
        {
            try
            {
                ChannelServices.RegisterChannel(chanA, false);
                accesuarsOperation = (AccesuarsOperation)Activator.GetObject(
                typeof(AccesuarsOperation), "tcp://localhost:9000/TalkIsGoodAccesuars");
                doVivod();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
