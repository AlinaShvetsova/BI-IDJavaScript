﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using serverComp;

namespace Computer
{
    public partial class ForPCTbl : Form
    {
        public ForPCTbl()
        {
            InitializeComponent();
        }
        TcpClientChannel chanF = new TcpClientChannel();
        private void doVivod(List<serverComp.ForPC> lstTovarF)
        {
            lvListF.Items.Clear();
            int i = 1;
            foreach (serverComp.ForPC forpc in lstTovarF)
            {
                ListViewItem newItem = new ListViewItem(i.ToString());
                lvListF.Items.Add(newItem);
                newItem.SubItems.Add(forpc.getNameF());
                newItem.SubItems.Add(forpc.getPriceF().ToString());
                newItem.SubItems.Add(forpc.getKolF().ToString());
                newItem.SubItems.Add((forpc.getKolF() * forpc.getPriceF()).ToString());
                i++;
            }
        }
        ForPCOperation forpcOperation = null;
        private void ForPCTbl_Load(object sender, EventArgs e)
        {
            try
            {
                ChannelServices.RegisterChannel(chanF, false);
                forpcOperation = (ForPCOperation)Activator.GetObject(
                typeof(ForPCOperation), "tcp://localhost:9000/TalkIsGoodForPC");
                doVivod(forpcOperation.getListOfTovarF());
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAddF_Click(object sender, EventArgs e)
        {
            addForPC p = new addForPC();
            p.ShowDialog();
            if (p.getTovarF != null)
            {
                try
                {
                    doVivod(forpcOperation.addTovarF(p.getTovarF));
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnDecideF_Click(object sender, EventArgs e)
        {
            try
            {
                txtF.Text = forpcOperation.getSumOfTovarF().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelF_Click(object sender, EventArgs e)
        {
            if (lvListF.SelectedIndices.Count < 1)
            {
                MessageBox.Show(this, "Выберите элемент для удаления!", "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                try
                {
                    forpcOperation.delTovarF(lvListF.SelectedIndices[0]);
                    doVivod(forpcOperation.getListOfTovarF());
                    if (lbl.Text != "")
                        btnDecideF_Click(sender, e);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnUpdateF_Click(object sender, EventArgs e)
        {
            try
            {
                doVivod(forpcOperation.getListOfTovarF());
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancelF_Click(object sender, EventArgs e)
        {
            this.Close();
            ChannelServices.UnregisterChannel(chanF);
        }
    }
}
