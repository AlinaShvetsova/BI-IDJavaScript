﻿namespace Computer
{
    partial class Menu
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnComp = new System.Windows.Forms.Button();
            this.btnPC = new System.Windows.Forms.Button();
            this.btnAcc = new System.Windows.Forms.Button();
            this.btnAdress = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnComp
            // 
            this.btnComp.Location = new System.Drawing.Point(76, 27);
            this.btnComp.Name = "btnComp";
            this.btnComp.Size = new System.Drawing.Size(140, 23);
            this.btnComp.TabIndex = 0;
            this.btnComp.Text = "Компьютеры/Ноутбуки";
            this.btnComp.UseVisualStyleBackColor = true;
            this.btnComp.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnPC
            // 
            this.btnPC.Location = new System.Drawing.Point(76, 120);
            this.btnPC.Name = "btnPC";
            this.btnPC.Size = new System.Drawing.Size(140, 23);
            this.btnPC.TabIndex = 1;
            this.btnPC.Text = "Комплектующие ля ПК";
            this.btnPC.UseVisualStyleBackColor = true;
            this.btnPC.Click += new System.EventHandler(this.btnPC_Click);
            // 
            // btnAcc
            // 
            this.btnAcc.Location = new System.Drawing.Point(76, 71);
            this.btnAcc.Name = "btnAcc";
            this.btnAcc.Size = new System.Drawing.Size(140, 23);
            this.btnAcc.TabIndex = 2;
            this.btnAcc.Text = "Аксессуары";
            this.btnAcc.UseVisualStyleBackColor = true;
            this.btnAcc.Click += new System.EventHandler(this.btnAcc_Click);
            // 
            // btnAdress
            // 
            this.btnAdress.Location = new System.Drawing.Point(76, 171);
            this.btnAdress.Name = "btnAdress";
            this.btnAdress.Size = new System.Drawing.Size(140, 23);
            this.btnAdress.TabIndex = 3;
            this.btnAdress.Text = "Адреса";
            this.btnAdress.UseVisualStyleBackColor = true;
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(76, 240);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(140, 23);
            this.Exit.TabIndex = 4;
            this.Exit.Text = "Выход";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(317, 303);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.btnAdress);
            this.Controls.Add(this.btnAcc);
            this.Controls.Add(this.btnPC);
            this.Controls.Add(this.btnComp);
            this.Name = "Menu";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnComp;
        private System.Windows.Forms.Button btnPC;
        private System.Windows.Forms.Button btnAcc;
        private System.Windows.Forms.Button btnAdress;
        private System.Windows.Forms.Button Exit;
    }
}

