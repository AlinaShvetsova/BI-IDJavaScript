﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using serverComp;

namespace Computer
{
    public partial class addForPC : Form
    {
        public addForPC()
        {
            InitializeComponent();
        }

        public ForPC getTovarF
        {
            get
            {
                return forpc;
            }
        }

        private void btnAddTovarF_Click(object sender, EventArgs e)
        {
            if (rdbYesParamF.Checked)
            {
                forpc = new ForPC(cmbNameF.SelectedItem.ToString(), Convert.ToInt32(spnKolF.Value), scrPrice.Value);
            }
            else
            {
                forpc = new ForPC();
                forpc.setNameF(cmbNameF.SelectedItem.ToString());
                forpc.setKolF(Convert.ToInt32(spnKolF.Value));
                forpc.setPriceF(scrPrice.Value);
            }
            this.Close();
        }
        ForPC forpc = null;
        private void addForPC_Load(object sender, EventArgs e)
        {
            cmbNameF.SelectedIndex = 0;
        }

        private void btnCancelF_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}