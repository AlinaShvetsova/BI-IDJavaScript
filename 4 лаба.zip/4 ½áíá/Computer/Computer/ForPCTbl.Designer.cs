﻿namespace Computer
{
    partial class ForPCTbl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvListF = new System.Windows.Forms.ListView();
            this.Номер = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Название = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Цена = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Количество = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Сумма = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.txtF = new System.Windows.Forms.TextBox();
            this.lbl = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.btnAddF = new System.Windows.Forms.ToolStripMenuItem();
            this.btnDecideF = new System.Windows.Forms.ToolStripMenuItem();
            this.btnDelF = new System.Windows.Forms.ToolStripMenuItem();
            this.btnUpdateF = new System.Windows.Forms.ToolStripMenuItem();
            this.btnCancelF = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lvListF
            // 
            this.lvListF.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Номер,
            this.Название,
            this.Цена,
            this.Количество,
            this.Сумма});
            this.lvListF.GridLines = true;
            this.lvListF.HideSelection = false;
            this.lvListF.Location = new System.Drawing.Point(50, 36);
            this.lvListF.Name = "lvListF";
            this.lvListF.Size = new System.Drawing.Size(302, 163);
            this.lvListF.TabIndex = 11;
            this.lvListF.UseCompatibleStateImageBehavior = false;
            this.lvListF.View = System.Windows.Forms.View.Details;
            // 
            // Номер
            // 
            this.Номер.Text = "№";
            this.Номер.Width = 31;
            // 
            // Название
            // 
            this.Название.Text = "Название";
            this.Название.Width = 72;
            // 
            // Цена
            // 
            this.Цена.Text = "Цена";
            this.Цена.Width = 74;
            // 
            // Количество
            // 
            this.Количество.Text = "Количество";
            this.Количество.Width = 55;
            // 
            // Сумма
            // 
            this.Сумма.Text = "Сумма";
            this.Сумма.Width = 91;
            // 
            // txtF
            // 
            this.txtF.Location = new System.Drawing.Point(187, 221);
            this.txtF.Name = "txtF";
            this.txtF.ReadOnly = true;
            this.txtF.Size = new System.Drawing.Size(100, 20);
            this.txtF.TabIndex = 10;
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.Location = new System.Drawing.Point(65, 224);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(116, 13);
            this.lbl.TabIndex = 9;
            this.lbl.Text = "Общая сумма товара";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.btnAddF,
            this.btnDecideF,
            this.btnDelF,
            this.btnUpdateF,
            this.btnCancelF});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(424, 24);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(12, 20);
            // 
            // btnAddF
            // 
            this.btnAddF.Name = "btnAddF";
            this.btnAddF.Size = new System.Drawing.Size(71, 20);
            this.btnAddF.Text = "Добавить";
            this.btnAddF.Click += new System.EventHandler(this.btnAddF_Click);
            // 
            // btnDecideF
            // 
            this.btnDecideF.Name = "btnDecideF";
            this.btnDecideF.Size = new System.Drawing.Size(80, 20);
            this.btnDecideF.Text = "Вычислить";
            this.btnDecideF.Click += new System.EventHandler(this.btnDecideF_Click);
            // 
            // btnDelF
            // 
            this.btnDelF.Name = "btnDelF";
            this.btnDelF.Size = new System.Drawing.Size(63, 20);
            this.btnDelF.Text = "Удалить";
            this.btnDelF.Click += new System.EventHandler(this.btnDelF_Click);
            // 
            // btnUpdateF
            // 
            this.btnUpdateF.Name = "btnUpdateF";
            this.btnUpdateF.Size = new System.Drawing.Size(73, 20);
            this.btnUpdateF.Text = "Обновить";
            this.btnUpdateF.Click += new System.EventHandler(this.btnUpdateF_Click);
            // 
            // btnCancelF
            // 
            this.btnCancelF.Name = "btnCancelF";
            this.btnCancelF.Size = new System.Drawing.Size(51, 20);
            this.btnCancelF.Text = "Назад";
            this.btnCancelF.Click += new System.EventHandler(this.btnCancelF_Click);
            // 
            // ForPCTbl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(424, 260);
            this.Controls.Add(this.lvListF);
            this.Controls.Add(this.txtF);
            this.Controls.Add(this.lbl);
            this.Controls.Add(this.menuStrip1);
            this.Name = "ForPCTbl";
            this.Text = "ForPCTbl";
            this.Load += new System.EventHandler(this.ForPCTbl_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView lvListF;
        private System.Windows.Forms.ColumnHeader Номер;
        private System.Windows.Forms.ColumnHeader Название;
        private System.Windows.Forms.ColumnHeader Цена;
        private System.Windows.Forms.ColumnHeader Количество;
        private System.Windows.Forms.ColumnHeader Сумма;
        private System.Windows.Forms.TextBox txtF;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem btnAddF;
        private System.Windows.Forms.ToolStripMenuItem btnDecideF;
        private System.Windows.Forms.ToolStripMenuItem btnDelF;
        private System.Windows.Forms.ToolStripMenuItem btnUpdateF;
        private System.Windows.Forms.ToolStripMenuItem btnCancelF;
    }
}