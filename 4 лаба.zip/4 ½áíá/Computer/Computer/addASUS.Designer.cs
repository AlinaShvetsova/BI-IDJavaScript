﻿namespace Computer
{
    partial class addASUS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.scrPrice = new System.Windows.Forms.HScrollBar();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblPriceInfo = new System.Windows.Forms.Label();
            this.lblKol = new System.Windows.Forms.Label();
            this.btnCancelAs = new System.Windows.Forms.Button();
            this.btnAddTovarAs = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbNoParamAs = new System.Windows.Forms.RadioButton();
            this.rdbYesParamAs = new System.Windows.Forms.RadioButton();
            this.spnKolAs = new System.Windows.Forms.NumericUpDown();
            this.cmbNameAs = new System.Windows.Forms.ComboBox();
            this.lblName = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spnKolAs)).BeginInit();
            this.SuspendLayout();
            // 
            // scrPrice
            // 
            this.scrPrice.Location = new System.Drawing.Point(125, 104);
            this.scrPrice.Name = "scrPrice";
            this.scrPrice.Size = new System.Drawing.Size(120, 17);
            this.scrPrice.TabIndex = 29;
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(30, 104);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(33, 13);
            this.lblPrice.TabIndex = 28;
            this.lblPrice.Text = "Цена";
            // 
            // lblPriceInfo
            // 
            this.lblPriceInfo.AutoSize = true;
            this.lblPriceInfo.Location = new System.Drawing.Point(183, 91);
            this.lblPriceInfo.Name = "lblPriceInfo";
            this.lblPriceInfo.Size = new System.Drawing.Size(19, 13);
            this.lblPriceInfo.TabIndex = 27;
            this.lblPriceInfo.Text = "50";
            // 
            // lblKol
            // 
            this.lblKol.AutoSize = true;
            this.lblKol.Location = new System.Drawing.Point(30, 63);
            this.lblKol.Name = "lblKol";
            this.lblKol.Size = new System.Drawing.Size(66, 13);
            this.lblKol.TabIndex = 26;
            this.lblKol.Text = "Количество";
            // 
            // btnCancelAs
            // 
            this.btnCancelAs.Location = new System.Drawing.Point(247, 270);
            this.btnCancelAs.Name = "btnCancelAs";
            this.btnCancelAs.Size = new System.Drawing.Size(75, 23);
            this.btnCancelAs.TabIndex = 25;
            this.btnCancelAs.Text = "Отмена";
            this.btnCancelAs.UseVisualStyleBackColor = true;
            this.btnCancelAs.Click += new System.EventHandler(this.btnCancelAs_Click);
            // 
            // btnAddTovarAs
            // 
            this.btnAddTovarAs.Location = new System.Drawing.Point(81, 270);
            this.btnAddTovarAs.Name = "btnAddTovarAs";
            this.btnAddTovarAs.Size = new System.Drawing.Size(75, 23);
            this.btnAddTovarAs.TabIndex = 24;
            this.btnAddTovarAs.Text = "Добавить";
            this.btnAddTovarAs.UseVisualStyleBackColor = true;
            this.btnAddTovarAs.Click += new System.EventHandler(this.btnAddTovarAs_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbNoParamAs);
            this.groupBox1.Controls.Add(this.rdbYesParamAs);
            this.groupBox1.Location = new System.Drawing.Point(81, 147);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(241, 100);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Конструктор";
            // 
            // rdbNoParamAs
            // 
            this.rdbNoParamAs.AutoSize = true;
            this.rdbNoParamAs.Location = new System.Drawing.Point(127, 53);
            this.rdbNoParamAs.Name = "rdbNoParamAs";
            this.rdbNoParamAs.Size = new System.Drawing.Size(108, 17);
            this.rdbNoParamAs.TabIndex = 1;
            this.rdbNoParamAs.TabStop = true;
            this.rdbNoParamAs.Text = "Без параметров";
            this.rdbNoParamAs.UseVisualStyleBackColor = true;
            // 
            // rdbYesParamAs
            // 
            this.rdbYesParamAs.AutoSize = true;
            this.rdbYesParamAs.Location = new System.Drawing.Point(17, 53);
            this.rdbYesParamAs.Name = "rdbYesParamAs";
            this.rdbYesParamAs.Size = new System.Drawing.Size(104, 17);
            this.rdbYesParamAs.TabIndex = 0;
            this.rdbYesParamAs.TabStop = true;
            this.rdbYesParamAs.Text = "С параметрами";
            this.rdbYesParamAs.UseVisualStyleBackColor = true;
            // 
            // spnKolAs
            // 
            this.spnKolAs.Location = new System.Drawing.Point(125, 56);
            this.spnKolAs.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.spnKolAs.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.spnKolAs.Name = "spnKolAs";
            this.spnKolAs.Size = new System.Drawing.Size(120, 20);
            this.spnKolAs.TabIndex = 22;
            this.spnKolAs.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // cmbNameAs
            // 
            this.cmbNameAs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNameAs.Items.AddRange(new object[] {
            "Тетрадь",
            "Ручка",
            "Карандаш"});
            this.cmbNameAs.Location = new System.Drawing.Point(124, 14);
            this.cmbNameAs.Name = "cmbNameAs";
            this.cmbNameAs.Size = new System.Drawing.Size(121, 21);
            this.cmbNameAs.TabIndex = 21;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(30, 22);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(83, 13);
            this.lblName.TabIndex = 20;
            this.lblName.Text = "Наименование";
            // 
            // addASUS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(370, 309);
            this.Controls.Add(this.scrPrice);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblPriceInfo);
            this.Controls.Add(this.lblKol);
            this.Controls.Add(this.btnCancelAs);
            this.Controls.Add(this.btnAddTovarAs);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.spnKolAs);
            this.Controls.Add(this.cmbNameAs);
            this.Controls.Add(this.lblName);
            this.Name = "addASUS";
            this.Text = "addASUS";
            this.Load += new System.EventHandler(this.addASUS_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spnKolAs)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.HScrollBar scrPrice;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblPriceInfo;
        private System.Windows.Forms.Label lblKol;
        private System.Windows.Forms.Button btnCancelAs;
        private System.Windows.Forms.Button btnAddTovarAs;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbNoParamAs;
        private System.Windows.Forms.RadioButton rdbYesParamAs;
        private System.Windows.Forms.NumericUpDown spnKolAs;
        private System.Windows.Forms.ComboBox cmbNameAs;
        private System.Windows.Forms.Label lblName;
    }
}