﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using serverComp;

namespace Computer
{
    public partial class addApple : Form
    {
        Tovar tovar = null;
        public addApple()
        {
            InitializeComponent();
        }

        public addApple(TovarOperation tovarOperation)
        {
            InitializeComponent();
            this.tovarOperation = tovarOperation;
        }
        TovarOperation tovarOperation = null;

        private void addApple_Load(object sender, EventArgs e)
        {
            cmbName.SelectedIndex = 0;
        }

        public Tovar getTovar
        {
            get
            {
                return tovar;
            }
        }
        private void btnAddTovar_Click(object sender, EventArgs e)
        {
            //код проверки на правильность ввода
            if (rdbYesParam.Checked)
            {
                tovar = new Tovar(cmbName.SelectedItem.ToString(), Convert.ToInt32(spnKol.Value), scrPrice.Value);
            }
            else
            {
                tovar = new Tovar();
                tovar.setName(cmbName.SelectedItem.ToString());
                tovar.setKol(Convert.ToInt32(spnKol.Value));
                tovar.setPrice(scrPrice.Value);
            }
            if(tovarOperation != null)
            {
                tovarOperation.addNewTovar(tovar);
            }
            this.Close();
        }

        private void scrPrice_Scroll(object sender, ScrollEventArgs e)
        {
            lblPriceInfo.Text = scrPrice.Value.ToString();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Post p = new Post();
            p.ShowDialog();
        }
    }
}
