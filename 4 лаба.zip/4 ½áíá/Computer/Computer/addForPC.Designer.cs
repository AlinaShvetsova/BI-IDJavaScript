﻿namespace Computer
{
    partial class addForPC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.scrPrice = new System.Windows.Forms.HScrollBar();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblPriceInfo = new System.Windows.Forms.Label();
            this.lblKol = new System.Windows.Forms.Label();
            this.btnCancelF = new System.Windows.Forms.Button();
            this.btnAddTovarF = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbNoParamF = new System.Windows.Forms.RadioButton();
            this.rdbYesParamF = new System.Windows.Forms.RadioButton();
            this.spnKolF = new System.Windows.Forms.NumericUpDown();
            this.cmbNameF = new System.Windows.Forms.ComboBox();
            this.lblName = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spnKolF)).BeginInit();
            this.SuspendLayout();
            // 
            // scrPrice
            // 
            this.scrPrice.Location = new System.Drawing.Point(160, 125);
            this.scrPrice.Name = "scrPrice";
            this.scrPrice.Size = new System.Drawing.Size(120, 17);
            this.scrPrice.TabIndex = 29;
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(65, 125);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(33, 13);
            this.lblPrice.TabIndex = 28;
            this.lblPrice.Text = "Цена";
            // 
            // lblPriceInfo
            // 
            this.lblPriceInfo.AutoSize = true;
            this.lblPriceInfo.Location = new System.Drawing.Point(218, 112);
            this.lblPriceInfo.Name = "lblPriceInfo";
            this.lblPriceInfo.Size = new System.Drawing.Size(19, 13);
            this.lblPriceInfo.TabIndex = 27;
            this.lblPriceInfo.Text = "50";
            // 
            // lblKol
            // 
            this.lblKol.AutoSize = true;
            this.lblKol.Location = new System.Drawing.Point(65, 84);
            this.lblKol.Name = "lblKol";
            this.lblKol.Size = new System.Drawing.Size(66, 13);
            this.lblKol.TabIndex = 26;
            this.lblKol.Text = "Количество";
            // 
            // btnCancelF
            // 
            this.btnCancelF.Location = new System.Drawing.Point(282, 291);
            this.btnCancelF.Name = "btnCancelF";
            this.btnCancelF.Size = new System.Drawing.Size(75, 23);
            this.btnCancelF.TabIndex = 25;
            this.btnCancelF.Text = "Отмена";
            this.btnCancelF.UseVisualStyleBackColor = true;
            this.btnCancelF.Click += new System.EventHandler(this.btnCancelF_Click);
            // 
            // btnAddTovarF
            // 
            this.btnAddTovarF.Location = new System.Drawing.Point(116, 291);
            this.btnAddTovarF.Name = "btnAddTovarF";
            this.btnAddTovarF.Size = new System.Drawing.Size(75, 23);
            this.btnAddTovarF.TabIndex = 24;
            this.btnAddTovarF.Text = "Добавить";
            this.btnAddTovarF.UseVisualStyleBackColor = true;
            this.btnAddTovarF.Click += new System.EventHandler(this.btnAddTovarF_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbNoParamF);
            this.groupBox1.Controls.Add(this.rdbYesParamF);
            this.groupBox1.Location = new System.Drawing.Point(116, 168);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(241, 100);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Конструктор";
            // 
            // rdbNoParamF
            // 
            this.rdbNoParamF.AutoSize = true;
            this.rdbNoParamF.Location = new System.Drawing.Point(127, 53);
            this.rdbNoParamF.Name = "rdbNoParamF";
            this.rdbNoParamF.Size = new System.Drawing.Size(108, 17);
            this.rdbNoParamF.TabIndex = 1;
            this.rdbNoParamF.TabStop = true;
            this.rdbNoParamF.Text = "Без параметров";
            this.rdbNoParamF.UseVisualStyleBackColor = true;
            // 
            // rdbYesParamF
            // 
            this.rdbYesParamF.AutoSize = true;
            this.rdbYesParamF.Location = new System.Drawing.Point(17, 53);
            this.rdbYesParamF.Name = "rdbYesParamF";
            this.rdbYesParamF.Size = new System.Drawing.Size(104, 17);
            this.rdbYesParamF.TabIndex = 0;
            this.rdbYesParamF.TabStop = true;
            this.rdbYesParamF.Text = "С параметрами";
            this.rdbYesParamF.UseVisualStyleBackColor = true;
            // 
            // spnKolF
            // 
            this.spnKolF.Location = new System.Drawing.Point(160, 77);
            this.spnKolF.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.spnKolF.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.spnKolF.Name = "spnKolF";
            this.spnKolF.Size = new System.Drawing.Size(120, 20);
            this.spnKolF.TabIndex = 22;
            this.spnKolF.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // cmbNameF
            // 
            this.cmbNameF.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNameF.Items.AddRange(new object[] {
            "Тетрадь",
            "Ручка",
            "Карандаш"});
            this.cmbNameF.Location = new System.Drawing.Point(159, 35);
            this.cmbNameF.Name = "cmbNameF";
            this.cmbNameF.Size = new System.Drawing.Size(121, 21);
            this.cmbNameF.TabIndex = 21;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(65, 43);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(83, 13);
            this.lblName.TabIndex = 20;
            this.lblName.Text = "Наименование";
            // 
            // addForPC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(422, 348);
            this.Controls.Add(this.scrPrice);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblPriceInfo);
            this.Controls.Add(this.lblKol);
            this.Controls.Add(this.btnCancelF);
            this.Controls.Add(this.btnAddTovarF);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.spnKolF);
            this.Controls.Add(this.cmbNameF);
            this.Controls.Add(this.lblName);
            this.Name = "addForPC";
            this.Text = "addForPC";
            this.Load += new System.EventHandler(this.addForPC_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spnKolF)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.HScrollBar scrPrice;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblPriceInfo;
        private System.Windows.Forms.Label lblKol;
        private System.Windows.Forms.Button btnCancelF;
        private System.Windows.Forms.Button btnAddTovarF;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbNoParamF;
        private System.Windows.Forms.RadioButton rdbYesParamF;
        private System.Windows.Forms.NumericUpDown spnKolF;
        private System.Windows.Forms.ComboBox cmbNameF;
        private System.Windows.Forms.Label lblName;
    }
}