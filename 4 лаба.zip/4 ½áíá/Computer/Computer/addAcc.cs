﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using serverComp;

namespace Computer
{
    public partial class addAcc : Form
    {
        Accesuars accesuars = null;
        public addAcc()
        {
            InitializeComponent();
        }
        public addAcc(AccesuarsOperation accesuarsOperation)
        {
            InitializeComponent();
            this.accesuarsOperation = accesuarsOperation;
        }

        AccesuarsOperation accesuarsOperation = null;

        public Accesuars getAccesuars
        {
            get
            {
                return accesuars;
            }
        }
        
        private void btnAddTovarA_Click(object sender, EventArgs e)
        {
            //код проверки на правильность ввода
            if (rdbYesParamA.Checked)
            {
                accesuars = new Accesuars(cmbNameA.SelectedItem.ToString(), Convert.ToInt32(spnKolA.Value), scrPriceA.Value);
            }
            else
            {
                accesuars = new Accesuars();
                accesuars.setNameA(cmbNameA.SelectedItem.ToString());
                accesuars.setKolA(Convert.ToInt32(spnKolA.Value));
                accesuars.setPriceA(scrPriceA.Value);
            }

            if(accesuarsOperation != null)
            {
                accesuarsOperation.addNewTovarA(accesuars);
            }
            this.Close();
        }

        private void addAcc_Load(object sender, EventArgs e)
        {
            cmbNameA.SelectedIndex = 0;
        }

        private void scrPriceA_Scroll(object sender, ScrollEventArgs e)
        {
            lblPriceInfoAc.Text = scrPriceA.Value.ToString();
        }
    }
}
