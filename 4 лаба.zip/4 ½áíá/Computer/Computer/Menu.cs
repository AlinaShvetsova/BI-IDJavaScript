﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using serverComp;

namespace Computer
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ComputersTbl p = new ComputersTbl();
            p.ShowDialog();
        }

        private void btnAcc_Click(object sender, EventArgs e)
        {
            AccesuarsTbl a = new AccesuarsTbl();
            a.ShowDialog();
        }
    
        private void btnPC_Click(object sender, EventArgs e)
        {
            ForPCTbl a = new ForPCTbl();
            a.ShowDialog();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
