﻿namespace Computer
{
    partial class addMSI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.scrPriceMs = new System.Windows.Forms.HScrollBar();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblPriceInfo = new System.Windows.Forms.Label();
            this.lblKol = new System.Windows.Forms.Label();
            this.btnCancelMs = new System.Windows.Forms.Button();
            this.btnAddTovarMs = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbNoParamMs = new System.Windows.Forms.RadioButton();
            this.rdbYesParamMs = new System.Windows.Forms.RadioButton();
            this.spnKolMs = new System.Windows.Forms.NumericUpDown();
            this.cmbNameMs = new System.Windows.Forms.ComboBox();
            this.lblName = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spnKolMs)).BeginInit();
            this.SuspendLayout();
            // 
            // scrPriceMs
            // 
            this.scrPriceMs.Location = new System.Drawing.Point(139, 116);
            this.scrPriceMs.Name = "scrPriceMs";
            this.scrPriceMs.Size = new System.Drawing.Size(120, 17);
            this.scrPriceMs.TabIndex = 39;
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(44, 116);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(33, 13);
            this.lblPrice.TabIndex = 38;
            this.lblPrice.Text = "Цена";
            // 
            // lblPriceInfo
            // 
            this.lblPriceInfo.AutoSize = true;
            this.lblPriceInfo.Location = new System.Drawing.Point(197, 103);
            this.lblPriceInfo.Name = "lblPriceInfo";
            this.lblPriceInfo.Size = new System.Drawing.Size(19, 13);
            this.lblPriceInfo.TabIndex = 37;
            this.lblPriceInfo.Text = "50";
            // 
            // lblKol
            // 
            this.lblKol.AutoSize = true;
            this.lblKol.Location = new System.Drawing.Point(44, 75);
            this.lblKol.Name = "lblKol";
            this.lblKol.Size = new System.Drawing.Size(66, 13);
            this.lblKol.TabIndex = 36;
            this.lblKol.Text = "Количество";
            // 
            // btnCancelMs
            // 
            this.btnCancelMs.Location = new System.Drawing.Point(261, 282);
            this.btnCancelMs.Name = "btnCancelMs";
            this.btnCancelMs.Size = new System.Drawing.Size(75, 23);
            this.btnCancelMs.TabIndex = 35;
            this.btnCancelMs.Text = "Отмена";
            this.btnCancelMs.UseVisualStyleBackColor = true;
            this.btnCancelMs.Click += new System.EventHandler(this.btnCancelMs_Click);
            // 
            // btnAddTovarMs
            // 
            this.btnAddTovarMs.Location = new System.Drawing.Point(95, 282);
            this.btnAddTovarMs.Name = "btnAddTovarMs";
            this.btnAddTovarMs.Size = new System.Drawing.Size(75, 23);
            this.btnAddTovarMs.TabIndex = 34;
            this.btnAddTovarMs.Text = "Добавить";
            this.btnAddTovarMs.UseVisualStyleBackColor = true;
            this.btnAddTovarMs.Click += new System.EventHandler(this.btnAddTovarMs_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbNoParamMs);
            this.groupBox1.Controls.Add(this.rdbYesParamMs);
            this.groupBox1.Location = new System.Drawing.Point(95, 159);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(241, 100);
            this.groupBox1.TabIndex = 33;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Конструктор";
            // 
            // rdbNoParamMs
            // 
            this.rdbNoParamMs.AutoSize = true;
            this.rdbNoParamMs.Location = new System.Drawing.Point(127, 53);
            this.rdbNoParamMs.Name = "rdbNoParamMs";
            this.rdbNoParamMs.Size = new System.Drawing.Size(108, 17);
            this.rdbNoParamMs.TabIndex = 1;
            this.rdbNoParamMs.TabStop = true;
            this.rdbNoParamMs.Text = "Без параметров";
            this.rdbNoParamMs.UseVisualStyleBackColor = true;
            // 
            // rdbYesParamMs
            // 
            this.rdbYesParamMs.AutoSize = true;
            this.rdbYesParamMs.Location = new System.Drawing.Point(17, 53);
            this.rdbYesParamMs.Name = "rdbYesParamMs";
            this.rdbYesParamMs.Size = new System.Drawing.Size(104, 17);
            this.rdbYesParamMs.TabIndex = 0;
            this.rdbYesParamMs.TabStop = true;
            this.rdbYesParamMs.Text = "С параметрами";
            this.rdbYesParamMs.UseVisualStyleBackColor = true;
            // 
            // spnKolMs
            // 
            this.spnKolMs.Location = new System.Drawing.Point(139, 68);
            this.spnKolMs.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.spnKolMs.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.spnKolMs.Name = "spnKolMs";
            this.spnKolMs.Size = new System.Drawing.Size(120, 20);
            this.spnKolMs.TabIndex = 32;
            this.spnKolMs.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // cmbNameMs
            // 
            this.cmbNameMs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNameMs.Items.AddRange(new object[] {
            "Тетрадь",
            "Ручка",
            "Карандаш"});
            this.cmbNameMs.Location = new System.Drawing.Point(138, 26);
            this.cmbNameMs.Name = "cmbNameMs";
            this.cmbNameMs.Size = new System.Drawing.Size(121, 21);
            this.cmbNameMs.TabIndex = 31;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(44, 34);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(83, 13);
            this.lblName.TabIndex = 30;
            this.lblName.Text = "Наименование";
            // 
            // addMSI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(380, 330);
            this.Controls.Add(this.scrPriceMs);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblPriceInfo);
            this.Controls.Add(this.lblKol);
            this.Controls.Add(this.btnCancelMs);
            this.Controls.Add(this.btnAddTovarMs);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.spnKolMs);
            this.Controls.Add(this.cmbNameMs);
            this.Controls.Add(this.lblName);
            this.Name = "addMSI";
            this.Text = "addMSI";
            this.Load += new System.EventHandler(this.addMSI_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spnKolMs)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.HScrollBar scrPriceMs;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblPriceInfo;
        private System.Windows.Forms.Label lblKol;
        private System.Windows.Forms.Button btnCancelMs;
        private System.Windows.Forms.Button btnAddTovarMs;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbNoParamMs;
        private System.Windows.Forms.RadioButton rdbYesParamMs;
        private System.Windows.Forms.NumericUpDown spnKolMs;
        private System.Windows.Forms.ComboBox cmbNameMs;
        private System.Windows.Forms.Label lblName;
    }
}