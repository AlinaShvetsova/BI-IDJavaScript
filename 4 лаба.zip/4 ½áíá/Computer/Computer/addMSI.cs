﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using serverComp;

namespace Computer
{
    public partial class addMSI : Form
    {
        public addMSI()
        {
            InitializeComponent();
        }

        private void btnCancelMs_Click(object sender, EventArgs e)
        {
            Post p = new Post();
            p.ShowDialog();
        }
        public addMSI(TovarOperation tovarOperation)
        {
            InitializeComponent();
            this.tovarOperation = tovarOperation;
        }
        TovarOperation tovarOperation = null;

        private void btnAddTovarMs_Click(object sender, EventArgs e)
        {

            //код проверки на правильность ввода
            if (rdbYesParamMs.Checked)
            {
                tovar = new Tovar(cmbNameMs.SelectedItem.ToString(), Convert.ToInt32(spnKolMs.Value), scrPriceMs.Value);
            }
            else
            {
                tovar = new Tovar();
                tovar.setName(cmbNameMs.SelectedItem.ToString());
                tovar.setKol(Convert.ToInt32(spnKolMs.Value));
                tovar.setPrice(scrPriceMs.Value);
            }

            if (tovarOperation != null)
            {
                tovarOperation.addNewTovar(tovar);
            }
            this.Close();
        }
        Tovar tovar = null;
        public Tovar getTovar
        {
            get
            {
                return tovar;
            }
        }
        private void addMSI_Load(object sender, EventArgs e)
        {
            cmbNameMs.SelectedIndex = 0;
        }
    }
}
