﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using serverComp;

namespace Computer
{

    public partial class Post : Form
    {
        public Post()
        {
            InitializeComponent();

        }
        public Post(TovarOperation tovarOperation)
        {
            InitializeComponent();
            this.tovarOperation = tovarOperation;
        }
        TovarOperation tovarOperation = null;

        private void btnApple_Click(object sender, EventArgs e)
        {

            this.Hide();
            addApple p = new addApple(tovarOperation);
            p.ShowDialog(this);
        }

        private void btnASUS_Click(object sender, EventArgs e)
        {

            this.Hide();
            addASUS p = new addASUS(tovarOperation);
            p.ShowDialog(this);
        }

        private void btnMSI_Click(object sender, EventArgs e)
        {

            this.Hide();
            addMSI p = new addMSI(tovarOperation);
            p.ShowDialog(this);
        }

        private void btnCancelPost_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Post_Load(object sender, EventArgs e)
        {

        }
    }
}
