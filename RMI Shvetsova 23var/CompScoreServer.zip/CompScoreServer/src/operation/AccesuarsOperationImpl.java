package operation;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;
import types.Accesuars;

public class AccesuarsOperationImpl extends UnicastRemoteObject implements AccesuarsOperation{
    static List<Accesuars> lstAccesuars = new ArrayList<Accesuars>();
    public AccesuarsOperationImpl() throws RemoteException{
   }
    @Override
    public List<Accesuars> getListOfTovarA(){
        return lstAccesuars;
    }
    @Override
    public List<Accesuars> addNewTovarA(Accesuars item){
        lstAccesuars.add(item);
        return lstAccesuars;
    }
    @Override
    public int getSumOfTovarA(){
        int sum =0;
        for(Accesuars accesuars: lstAccesuars)
            sum+= accesuars.getKolA()*accesuars.getPriceA();
        return sum;}}

