package operation;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;
import types.ForPC;

public class ForPCOperationImpl extends UnicastRemoteObject implements ForPCOperation{
    static List<ForPC> lstForPC = new ArrayList<ForPC>();
     static {
        lstForPC.add(new ForPC("Товар1", 10, 100));
        lstForPC.add(new ForPC("Товар2", 20, 100));
        lstForPC.add(new ForPC("Товар3", 30, 100));
        lstForPC.add(new ForPC("Товар4", 40, 100));
    }
     public ForPCOperationImpl() throws RemoteException{
     }
           
    @Override
    public List<ForPC> getListOfTovarF()throws RemoteException{
        return lstForPC;
    }
    @Override
    public List<ForPC> addNewTovarF(ForPC item)throws RemoteException{
        lstForPC.add(item);
        return lstForPC;
    }
    @Override
    public int getSumOfTovarF()throws RemoteException{
        int sum =0;
        for(ForPC forPC: lstForPC)
            sum+= forPC.getKolF()*forPC.getPriceF();
        return sum;
    }}

