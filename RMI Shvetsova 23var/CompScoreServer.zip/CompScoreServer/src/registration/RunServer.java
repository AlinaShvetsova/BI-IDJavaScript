package registration;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import operation.TovarOperationImpl;
import operation.AccesuarsOperationImpl;
import operation.ForPCOperationImpl;

public class RunServer {
    
  public static void main (String[] argv) {
    try {
                        // создание экземпляров классов для регистрации
			TovarOperationImpl tovarOperationImpl = new TovarOperationImpl();
                        AccesuarsOperationImpl accesuarsOperationImpl = new AccesuarsOperationImpl();
                        ForPCOperationImpl forpcOperationImpl = new ForPCOperationImpl();
			
			// создаём реестр
			Registry registry = LocateRegistry.createRegistry(1199);
			
			// регистрация классов
			registry.bind("rmiTest01", tovarOperationImpl); 
                        registry.bind("rmiTest02", accesuarsOperationImpl);   
                        registry.bind("rmiTest03", forpcOperationImpl);
        
      System.out.println ("Tovar Server is ready.");
    } catch (Exception e) {
      System.out.println ("Tovar Server failed: " + e);
    }
  }
}
