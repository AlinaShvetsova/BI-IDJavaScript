package operation;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import types.ForPC;

public interface ForPCOperation extends Remote{
    List<ForPC> getListOfTovarF() throws RemoteException;
    List<ForPC> addNewTovarF(ForPC forpc) throws RemoteException;
    int getSumOfTovarF() throws RemoteException;
}
