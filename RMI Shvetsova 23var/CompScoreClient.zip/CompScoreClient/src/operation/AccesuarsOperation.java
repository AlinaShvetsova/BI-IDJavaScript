package operation;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import types.Accesuars;
    
public interface AccesuarsOperation extends Remote{
    List<Accesuars> getListOfTovarA() throws RemoteException;
    List<Accesuars> addNewTovarA(Accesuars accesuars) throws RemoteException;
    int getSumOfTovarA() throws RemoteException;
}

