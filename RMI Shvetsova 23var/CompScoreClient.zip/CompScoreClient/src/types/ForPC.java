package types;

import java.io.Serializable;

public class ForPC implements Serializable{
    private String nameF;
    private int kolF;
    private double priceF;

    public ForPC() {
        this.nameF ="";
        this.kolF=0;
        this.priceF=0;
    }

    public ForPC(String nameF, int kolF, double priceF) {
        this.nameF = nameF;
        this.kolF = kolF;
        this.priceF = priceF;
    }

    public String getNameF() {
        return nameF;
    }

    public void setNameF(String nameF) {
        this.nameF = nameF;
    }

    public int getKolF() {
        return kolF;
    }

    public void setKolF(int kolF) {
        this.kolF = kolF;
    }

    public double getPriceF() {
        return priceF;
    }

    public void setPriceF(double priceF) {
        this.priceF = priceF;
    }
    
}
