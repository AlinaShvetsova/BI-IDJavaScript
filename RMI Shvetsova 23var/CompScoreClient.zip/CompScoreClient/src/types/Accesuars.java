package types;

import java.io.Serializable;

public class Accesuars implements Serializable{
    private String nameA;
    private int kolA;
    private double priceA;

    public Accesuars() {
        this.nameA ="";
        this.kolA=0;
        this.priceA=0;
    }

    public Accesuars(String nameA, int kolA, double priceA) {
        this.nameA = nameA;
        this.kolA = kolA;
        this.priceA = priceA;
    }

    public String getNameA() {
        return nameA;
    }

    public void setNameA(String nameA) {
        this.nameA = nameA;
    }

    public int getKolA() {
        return kolA;
    }

    public void setKolA(int kolA) {
        this.kolA = kolA;
    }

    public double getPriceA() {
        return priceA;
    }

    public void setPriceA(double priceA) {
        this.priceA = priceA;
    }
    
}
