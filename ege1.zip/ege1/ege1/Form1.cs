﻿using ege1.ServiceReference1;
using ege1.ServiceReference2;
using ege1.ServiceReference3;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ege1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    ExamsPortClient port = new ExamsPortClient();
                    exams[] response = port.getAllExams(new getAllExamsRequest());
                    printExams(response);
                    break;
                


                case 1:
                    RegionPortClient port1 = new RegionPortClient();
                    region[] response1 = port1.getAllRegion(new getAllRegionRequest());
                    printRegion(response1);
                    break;


                case 2:
                    StatisticPortClient port2 = new StatisticPortClient();
                    statistic[] response2 = port2.getAllStatistic(new getAllStatisticRequest());
                    printStatistic(response2);
                    break;

                default:
                    richTextBox1.Text += "Не выбран  источник данных!\r\n";
                    break;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void printExams(exams[] exam)
        {
            richTextBox1.Text += "Колличество экзаменов: " + exam.Length + "\r\n";
            richTextBox1.Text += "Список экзаменов: \r\n";
            foreach(exams examItem in exam)
            {
                richTextBox1.Text += string.Format("\tИдентификатор - {0},\t\tНаименование - {1},\r\n\tОписание - {2}\r\n\t\n", 
                    examItem.id_exam, examItem.name_exam, examItem.description);
                richTextBox1.Text += "---------------------------------------------------------\r\n";
            }
        }

        private void printRegion(region[] regions)
        {
            richTextBox1.Text += "Колличество регионов: " + regions.Length + "\r\n";
            richTextBox1.Text += "Список Регионов: \r\n";
            foreach (region regionItem in regions)
            {
                richTextBox1.Text += string.Format("\tИдентификатор - {0},\n\tКод региона - {1},\r\n\tНазвание региона - {2}\r\n\t\n",
                    regionItem.id_region, regionItem.code_region, regionItem.name_region);
                richTextBox1.Text += "---------------------------------------------------------\r\n";
            }
        }

        private void printStatistic(statistic[] statistics)
        {
            richTextBox1.Text += "Колличество статистик: " + statistics.Length + "\r\n";
            richTextBox1.Text += "Статистики: \r\n";
            foreach (statistic regionItem in statistics)
            {
                richTextBox1.Text += string.Format("\tИдентификатор - {0},\t\tИдентификатор экзамена - {1},\r\n\tИдентификатор региона - {2}," +
                    "\t\tКоличество сдающих - {3},\r\n\tБаллы - {4}, \t\n\tКоличество несдавших - {5},\r\n\tДата - {6}\r\n\t\n",
                    regionItem.id_statistic, regionItem.id_exam, regionItem.id_region, 
                    regionItem.quarnity, regionItem.points, regionItem.failed_exam, regionItem.day_month_year);
                richTextBox1.Text += "---------------------------------------------------------\r\n";
            }
        }
    }
}
