﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Language
{
    class Odin
    {
        private static Odin al = null;
        private string inf;
        public string Info => inf;
        private Odin(string inf1)
        {
            inf = inf1;
        }
        public static Odin GetInitialize(string inf1)
        {
            if (al == null)
                al = new Odin(inf1);
            return al;
        }

        public static Odin GetInitialized()
        {
            return al;
        }

    }
}
