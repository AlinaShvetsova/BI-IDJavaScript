﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Language
{
    public partial class Orders : Form
    {
        SqlConnectionStringBuilder builder;
        SqlConnection cn;

        public Orders()
        {
            InitializeComponent();
            builder = new SqlConnectionStringBuilder();
            builder.DataSource = @".\SQLExpress";
            builder.IntegratedSecurity = true;
            var odin = Odin.GetInitialized();
            builder.AttachDBFilename = odin.Info;
            All();
        }

        // ПРОВЕРКА ПРАВИЛЬНОСТИ ВВОДА В ТЕКСТОВЫЕ ПОЛЯ
        private Boolean txtCheck()
        {
            int k = 0;
            char[] n = textBox1.Text.ToString().ToCharArray(), s = textBox2.Text.ToString().ToCharArray();
            for (int i = 0; i < textBox1.TextLength; i++)
            {
                if (Char.IsDigit(n[i]))
                    k++;
            }
            for (int i = 0; i < textBox2.TextLength; i++)
            {
                if (Char.IsDigit(s[i]))
                    k++;
            }

            if (k == 0)
                return true;
            else return false;
        }

        // ВЫВОД ВСЕХ ЗАПИСЕЙ 
        private void All()
        {
            string strSQL = "Select Orders.ID_order as ID, Client.Name as Имя, Client.Surname as Фамилия, Client.Telephone as Телефон," +
                "Price.Language as Услуга, " +
                "Orders.Status as Статус From Orders, Client, Price WHERE Orders.ID_client = Client.ID_client" +
                "AND Orders.ID_language = Price.ID_language";

            using (cn = new SqlConnection(builder.ConnectionString))
            {
                try
                {
                    cn.Open();
                    SqlCommand cmd = new SqlCommand(strSQL, cn);
                    SqlDataReader rdr = cmd.ExecuteReader();
                    DataTable t = new DataTable();
                    t.Load(rdr);
                    dataGridView1.DataSource = t.DefaultView;
                    cn.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
         // ВЫБОР ID 
        private int choose(string id, string table, string column, string cmb)
        {
            int k = 0;
            using (cn = new SqlConnection(builder.ConnectionString))
            {
                try
                {
                    cn.Open();
                    string strSQL = "Select " + id + " From " + table + " Where " + column + " like '" + cmb + "' ";
                    SqlCommand cmd = new SqlCommand(strSQL, cn);
                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            k = Convert.ToInt32(rdr.GetValue(0));
                        }
                    }
                    rdr.Close();
                    cn.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                if (k != 0)
                    return k;
                else
                    return 0;
            }
        }

        // добавление в бд
        private void button1_Click(object sender, EventArgs e)
        {
            if (txtCheck())
            {
                int or = choose("ID_language", "Price", "Language", comboBox1.Text);
                string stat = "В процессе";
                using (cn = new SqlConnection(builder.ConnectionString))
                {
                    try
                    {
                        // ДОБАВЛЕНИЕ КЛИЕНТА
                        cn.Open();
                        string strSQL = "INSERT INTO Client VALUES (" + "'" + textBox1.Text +
                            "','" + textBox2.Text + "','" + textBox3.Text + "')";
                        SqlCommand cmd = new SqlCommand(strSQL, cn);
                        if (cmd.ExecuteNonQuery() == 1)
                            MessageBox.Show("Клиент успешно добавлен!");
                        cn.Close();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show("В Клиентах " + ex.Message);
                    }
                }
                int id = 0;
                using (cn = new SqlConnection(builder.ConnectionString))
                {
                    try
                    {
                        // ВЫБОР ID ДОБАВЛЕННОГО КЛИЕНТА
                        cn.Open();
                        string strSQL = "Select ID_client From Client Where Telephone = '" + textBox3.Text + "'";
                        SqlCommand cmd = new SqlCommand(strSQL, cn);
                        SqlDataReader rdr = cmd.ExecuteReader();
                        while (rdr.Read())
                        {
                            id = Convert.ToInt32(rdr["ID_client"]);
                        }
                        rdr.Close();
                        cn.Close();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }

                using (cn = new SqlConnection(builder.ConnectionString))
                {
                    try
                    {
                        // ДОБАВЛЕНИЕ ЗАКАЗА
                        cn.Open();
                        string strSQL1 = "INSERT INTO Orders VALUES (" + id +
                            "," + 3 + "," + or  +",'" + stat + "')";

                        SqlCommand cmd = new SqlCommand(strSQL1, cn);
                        if (cmd.ExecuteNonQuery() == 1)
                            MessageBox.Show("Заказ успешно добавлен!");
                        cn.Close();
                        All();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show("В ЗАКАЗАХ " + ex.Message);
                    }
                }
            }
            else
                MessageBox.Show("Некорректные данные в поле: Имя и/или Фамилия!" + "\n" +
                    "Вводите только буквы!");
        }
        // КАЛЬКУЛЯТОР
        private void button3_Click(object sender, EventArgs e)
        {
            /*string kol = "SELECT SUM(Price.Cost) FROM Price, Orders WHERE  Price.ID_service = OrderS.ID_service " +
                "AND ID_order =" + textBox6.Text + "GROUP BY OrderS.Quarnity  ";
            using (cn = new SqlConnection(builder.ConnectionString))
            {
                try
                {

                    cn.Open();
                    SqlCommand da = new SqlCommand(kol, cn);
                    label10.Text = da.ExecuteScalar().ToString();
                    cn.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }*/
        }

        private void button2_Click(object sender, EventArgs e)
        {
            {
                int row = dataGridView1.CurrentCell.RowIndex;
                using (cn = new SqlConnection(builder.ConnectionString))
                {
                    try
                    {
                        cn.Open();
                        string rs = "DELETE FROM Orders WHERE Orders.ID_order = '" + Convert.ToInt32(textBox5.Text) + "'";
                        SqlCommand cmd = new SqlCommand(rs, cn);
                        if (cmd.ExecuteNonQuery() == 1)
                            MessageBox.Show("Запись успешно удалена!");
                        cn.Close();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                All();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login L = new Login();
            L.Show();
        }
    }
}

