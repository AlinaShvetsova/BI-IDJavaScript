﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Language
{
    public partial class Work : Form
    {
        SqlConnectionStringBuilder builder;
        SqlConnection cn;
        public Work()
        {
            InitializeComponent();
            builder = new SqlConnectionStringBuilder();
            builder.DataSource = @".\SQLExpress";
            builder.IntegratedSecurity = true;
            var odin = Odin.GetInitialized();
            builder.AttachDBFilename = odin.Info;
            All();
        }

        private void All()
        {
            string strSQL = "Select Orders.ID_order as ID, Client.Name as Имя, Client.Surname as Фамилия, Client.Telephone as Телефон," +
                "Price.Language as Услуга, " +
                "Orders.Status as Статус From Orders, Client, Price WHERE Orders.ID_client = Client.ID_client" +
                "AND Orders.ID_language = Price.ID_language";

            using (cn = new SqlConnection(builder.ConnectionString))
            {
                try
                {
                    cn.Open();
                    SqlCommand cmd = new SqlCommand(strSQL, cn);
                    SqlDataReader rdr = cmd.ExecuteReader();
                    DataTable t = new DataTable();
                    t.Load(rdr);
                    dataGridView1.DataSource = t.DefaultView;
                    cn.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
            private void button2_Click(object sender, EventArgs e)
            {
                if (radioButton1.Checked == true)
                {
                    string strSQL = "Select Orders.ID_order as ID, Client.Name as Имя, Client.Surname as Фамилия, Client.Telephone as Телефон," +
                    "Price.Language as Услуга, " +
                    "Orders.Status as Статус From Orders, Client, Price WHERE Orders.ID_client = Client.ID_client" +
                    "AND Orders.ID_language = Price.ID_language AND Client.Telephone LIKE '" + textBox1.Text + "%'";
                    using (cn = new SqlConnection(builder.ConnectionString))
                    {
                        try
                        {
                            cn.Open();
                            SqlCommand cmd = new SqlCommand(strSQL, cn);
                            SqlDataReader rdr = cmd.ExecuteReader();

                            DataTable t = new DataTable();
                            t.Load(rdr);
                            dataGridView1.DataSource = t.DefaultView;
                            rdr.Close();
                            cn.Close();
                        }

                        catch (SqlException ex)

                        {

                            MessageBox.Show(ex.Message);

                        }

                    }
                }


                if (radioButton2.Checked == true)
                {
                    string strSQL = "Select Orders.ID_order as ID, Client.Name as Имя, Client.Surname as Фамилия, Client.Telephone as Телефон," +
                    "Price.Language as Услуга, " +
                    "Orders.Status as Статус From Orders, Client, Price WHERE Orders.ID_client = Client.ID_client" +
                    "AND Orders.ID_language = Price.ID_language AND Price.Language LIKE '" + comboBox2.Text + "'";

                    using (cn = new SqlConnection(builder.ConnectionString))
                    {
                        try
                        {
                            cn.Open();
                            SqlCommand cmd = new SqlCommand(strSQL, cn);
                            SqlDataReader rdr = cmd.ExecuteReader();

                            DataTable t = new DataTable();
                            t.Load(rdr);
                            dataGridView1.DataSource = t.DefaultView;
                            rdr.Close();
                            cn.Close();
                        }

                        catch (SqlException ex)

                        {

                            MessageBox.Show(ex.Message);

                        }

                    }
                }

                if (radioButton1.Checked == false && radioButton2.Checked == false && radioButton3.Checked == true)
                {
                    string strSQL = "Select Orders.ID_order as ID, Client.Name as Имя, Client.Surname as Фамилия, Client.Telephone as Телефон," +
                    "Price.Language as Услуга, " +
                    "Orders.Status as Статус From Orders, Client, Price WHERE Orders.ID_client = Client.ID_client" +
                    "AND Orders.ID_language = Price.ID_language AND Client.Telephone LIKE '" + textBox1.Text + "%'" +
                    "AND Price.Language LIKE '" + comboBox2.Text + "'";

                    using (cn = new SqlConnection(builder.ConnectionString))
                    {
                        try
                        {
                            cn.Open();
                            SqlCommand cmd = new SqlCommand(strSQL, cn);
                            SqlDataReader rdr = cmd.ExecuteReader();

                            DataTable t = new DataTable();
                            t.Load(rdr);
                            dataGridView1.DataSource = t.DefaultView;
                            rdr.Close();
                            cn.Close();
                        }

                        catch (SqlException ex)

                        {

                            MessageBox.Show(ex.Message);

                        }

                    }
                }
                if (radioButton1.Checked == false && radioButton2.Checked == false && radioButton3.Checked == false)
                {
                    MessageBox.Show("Пожалуйста, выберите критерий!");
                }
            }

        private void button4_Click(object sender, EventArgs e)
        {
            int IDorder = Convert.ToInt32(textBox2.Text);

            using (cn = new SqlConnection(builder.ConnectionString))
            {
                try
                {
                    cn.Open();
                    string strSQL = "Select Orders.ID_order as ID, Client.Name as Имя, Client.Surname as Фамилия, Client.Telephone as Телефон," +
                "Price.Language as Услуга, " +
                "Orders.Status as Статус From Orders, Client, Price WHERE Orders.ID_client = Client.ID_client" +
                "AND Orders.ID_language = Price.ID_language AND Orders.ID_order=" + IDorder;

                    SqlDataAdapter da = new SqlDataAdapter(strSQL, cn);

                    DataTable t = new DataTable("OrderS");

                    da.Fill(t);
                    dataGridView1.DataSource = t;
                    button1.Enabled = true;
                    cn.Close();
                }

                catch (SqlException ex)

                {

                    MessageBox.Show(ex.Message);

                }
            }
        
    }

        private void button1_Click(object sender, EventArgs e)
        {
            int row = dataGridView1.CurrentCell.RowIndex;
            using (cn = new SqlConnection(builder.ConnectionString))
            {
                try
                {
                    cn.Open();

                    string strUpd = "UPDATE [Orders] " +
                        "SET Status=@Status" +
                        " WHERE ID_order=@ID_order";

                    SqlCommand cmdUpd = new SqlCommand(strUpd, cn);

                    cmdUpd.Parameters.AddWithValue("@ID_order", Convert.ToInt32(this.textBox2.Text));
                    cmdUpd.Parameters.AddWithValue("@Status", comboBox1.Text);

                    int res = cmdUpd.ExecuteNonQuery();

                    if (res == 1)

                    {

                        MessageBox.Show("Запись успешно отредактирована!");
                        All();
                    }

                    else

                        MessageBox.Show("Запись не отредактирована!");
                    cn.Close();
                }

                catch (SqlException ex)

                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login L = new Login();
            L.Show();
        }
    }
    }
