﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Language
{
    public partial class Login : Form
    {
        SqlConnectionStringBuilder builder;
        public Login()
        {
            InitializeComponent();
            builder = new SqlConnectionStringBuilder();
            builder.DataSource = @".\SQLExpress";
            builder.IntegratedSecurity = true;
            var odin = Odin.GetInitialized();
            builder.AttachDBFilename = odin.Info;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int k = 0;

            using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
            {
                try
                {
                    connection.Open();
                    String strSQL = "SELECT ID_login FROM Log WHERE Login LIKE '" + textBox1.Text
                     + "' AND Password LIKE '" + textBox2.Text + "';";
                    SqlCommand cmd = new SqlCommand(strSQL, connection);
                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            k = Convert.ToInt32(rdr.GetValue(0));

                            if (k > 1)
                            {
                                this.Hide();
                                Orders m = new Orders();
                                m.Show();
                            }
                            else if (k == 1)
                            {
                                this.Hide();
                                Work m = new Work();
                                m.Show();
                            }
                        }
                    }
                    else MessageBox.Show("Неправильный логин и/или пароль!");
                    rdr.Close();
                    connection.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Obzor l = new Obzor();
            l.Show();
        }
    }
}
