package operation;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import types.Wow;

public interface WowOperation extends Remote {
    List<Wow> getListOfTovarW() throws RemoteException;
    List<Wow> addNewTovarW(Wow item) throws RemoteException;
    int getSumOfTovarW() throws RemoteException;}