package registration;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import operation.TovarOperationImpl;
import operation.WowOperationImpl;

public class RunServer {
    
  public static void main (String[] argv) {
    try {
                             // создание экземпляров классов для регистрации
			TovarOperationImpl tovarOperationImpl = new TovarOperationImpl();
			WowOperationImpl wowOperationImpl = new WowOperationImpl();
			// создаём реестр
			Registry registry = LocateRegistry.createRegistry(1199);
			
			// регистрация классов
			registry.bind("rmiTest02", tovarOperationImpl); 
                        registry.bind("rmiTest03", wowOperationImpl);
        
      System.out.println ("Tovar Server is ready.");
    } catch (Exception e) {
    System.out.println ("Tovar Server failed: " + e);
    }
  }
}
