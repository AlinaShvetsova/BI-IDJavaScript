﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace KursovayaFootwearCSharp
{
    public partial class Master : Form
    {
        SqlConnectionStringBuilder builder;
        SqlConnection cn;

        public Master()
        {
            InitializeComponent();

            builder = new SqlConnectionStringBuilder();
            builder.DataSource = @".\SQLExpress";
            builder.IntegratedSecurity = true;
            var alone = Alone.GetInitialized();
            builder.AttachDBFilename = alone.Info;
            All();
            using (cn = new SqlConnection(builder.ConnectionString))
            {
                try
                {
                    cn.Open();
                    string strSQL = "Select Service From Price";
                    SqlCommand cmd = new SqlCommand(strSQL, cn);
                    SqlDataReader rdr = cmd.ExecuteReader();
                    int i = 0;
                    while (rdr.Read())
                    {
                        comboBox2.Items.Insert(i, rdr["Service"]);
                    }
                    cn.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void All()
        {
            string strSQL = "Select OrderS.ID_order as ID, Users.UName as Имя, Users.USurname as Фамилия, Users.Telephone as Телефон," +
                " Price.Service as Услуга, OrderS.Quarnity as Количество, OrderS.DTime as Дата, " +
                "OrderS.Status as Статус From OrderS, Users, Price WHERE OrderS.ID_user = Users.ID_user " +
                "AND OrderS.ID_service=Price.ID_service";

            using (cn = new SqlConnection(builder.ConnectionString))
            {
                try
                {
                    cn.Open();
                    SqlCommand cmd = new SqlCommand(strSQL, cn);
                    SqlDataReader rdr = cmd.ExecuteReader();
                    DataTable t = new DataTable();
                    t.Load(rdr);
                    dataGridView1.DataSource = t.DefaultView;
                    cn.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        // ПОИСК ПО ФАМИЛИИ И/ИЛИ УСЛУГЕ
        private void button2_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                string strSQL = "Select OrderS.ID_order as ID, Users.UName as Имя, Users.USurname as Фамилия, Users.Telephone as Телефон," +
                        " Price.Service as Услуга, OrderS.Quarnity as Количество, OrderS.DTime as Дата, " +
                        "OrderS.Status as Статус From OrderS, Users, Price WHERE OrderS.ID_user = Users.ID_user " +
                        "AND OrderS.ID_service=Price.ID_service AND Users.USurname LIKE '" + textBox1.Text + "%'";
                using (cn = new SqlConnection(builder.ConnectionString))
                {
                    try
                    {
                        cn.Open();
                        SqlCommand cmd = new SqlCommand(strSQL, cn);
                        SqlDataReader rdr = cmd.ExecuteReader();

                        DataTable t = new DataTable();
                        t.Load(rdr);
                        dataGridView1.DataSource = t.DefaultView;
                        rdr.Close();
                        cn.Close();
                    }

                    catch (SqlException ex)

                    {

                        MessageBox.Show(ex.Message);

                    }

                }
            }


            if (radioButton2.Checked == true)
            {
                string strSQL = "Select OrderS.ID_order as ID, Users.UName as Имя, Users.USurname as Фамилия, Users.Telephone as Телефон," +
                     " Price.Service as Услуга, OrderS.Quarnity as Количество, OrderS.DTime as Дата, " +
                     "OrderS.Status as Статус From OrderS, Users, Price WHERE OrderS.ID_user = Users.ID_user " +
                     "AND OrderS.ID_service=Price.ID_service AND Price.Service LIKE '" + comboBox2.Text + "'";

                using (cn = new SqlConnection(builder.ConnectionString))
                {
                    try
                    {
                        cn.Open();
                        SqlCommand cmd = new SqlCommand(strSQL, cn);
                        SqlDataReader rdr = cmd.ExecuteReader();

                        DataTable t = new DataTable();
                        t.Load(rdr);
                        dataGridView1.DataSource = t.DefaultView;
                        rdr.Close();
                        cn.Close();
                    }

                    catch (SqlException ex)

                    {

                        MessageBox.Show(ex.Message);

                    }

                }
            }

            if (radioButton1.Checked == false && radioButton2.Checked == false && radioButton3.Checked == true)
            {
                string strSQL = "Select OrderS.ID_order as ID, Users.UName as Имя, Users.USurname as Фамилия, Users.Telephone as Телефон," +
                 " Price.Service as Услуга, OrderS.Quarnity as Количество, OrderS.DTime as Дата, " +
                 "OrderS.Status as Статус From OrderS, Users, Price WHERE OrderS.ID_user = Users.ID_user " +
                 "AND OrderS.ID_service=Price.ID_service AND Users.USurname LIKE '" + textBox1.Text + "%' " +
                 "AND Price.Service LIKE '" + comboBox2.Text + "'";

                using (cn = new SqlConnection(builder.ConnectionString))
                {
                    try
                    {
                        cn.Open();
                        SqlCommand cmd = new SqlCommand(strSQL, cn);
                        SqlDataReader rdr = cmd.ExecuteReader();

                        DataTable t = new DataTable();
                        t.Load(rdr);
                        dataGridView1.DataSource = t.DefaultView;
                        rdr.Close();
                        cn.Close();
                    }

                    catch (SqlException ex)

                    {

                        MessageBox.Show(ex.Message);

                    }

                }
            }
            if (radioButton1.Checked == false && radioButton2.Checked == false && radioButton3.Checked == false)
            {
                MessageBox.Show("Пожалуйста, выберите критерий!");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int row = dataGridView1.CurrentCell.RowIndex;
            using (cn = new SqlConnection(builder.ConnectionString))
            {
                try
                {
                    cn.Open();

                    string strUpd = "UPDATE [OrderS] " +
                        "SET Status=@Status" +
                        " WHERE ID_order=@ID_order";

                    SqlCommand cmdUpd = new SqlCommand(strUpd, cn);

                    cmdUpd.Parameters.AddWithValue("@ID_order", Convert.ToInt32(this.textBox2.Text));
                    cmdUpd.Parameters.AddWithValue("@Status", comboBox1.Text);

                    int res = cmdUpd.ExecuteNonQuery();

                    if (res == 1)

                    {

                        MessageBox.Show("Запись успешно отредактирована!");
                        All();
                    }

                    else

                        MessageBox.Show("Запись не отредактирована!");
                    cn.Close();
                }

                catch (SqlException ex)

                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        // ПОИСК ПО ID И РЕДАКТИРОВАНЕИ СТАТУСА ЗАКАЗА
        private void button4_Click(object sender, EventArgs e)
        {

            int IDorder = Convert.ToInt32(textBox2.Text);

            using (cn = new SqlConnection(builder.ConnectionString))
            {
                try
                {
                    cn.Open();
                    string strSQL = "Select OrderS.ID_order as ID, Users.UName as Имя, Users.USurname as Фамилия, Users.Telephone as Телефон," +
                " Price.Service as Услуга, OrderS.Quarnity as Количество, OrderS.DTime as Дата," +
                "OrderS.Status as Статус From OrderS, Users, Price WHERE OrderS.ID_user = Users.ID_user " +
                "AND OrderS.ID_service=Price.ID_service AND OrderS.ID_order=" + IDorder;

                    SqlDataAdapter da = new SqlDataAdapter(strSQL, cn);

                    DataTable t = new DataTable("OrderS");

                    da.Fill(t);
                    dataGridView1.DataSource = t;
                    button1.Enabled = true;
                    cn.Close();
                }

                catch (SqlException ex)

                {

                    MessageBox.Show(ex.Message);

                }
            }
        }

        // ПОКАЗАТЬ ВСЕ
        private void button5_Click(object sender, EventArgs e)
        {
            All();
        }

        // ВЫХОД
        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginIN L = new LoginIN();
            L.Show();
        }
    }
}
