﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace KursovayaFootwearCSharp
{
    public partial class Clients : Form
    {
        SqlConnectionStringBuilder builder;
        SqlConnection cn;

        public Clients()
        {
            InitializeComponent();

            // ПОДСОЕДИНЕНИЕ К БД
            builder = new SqlConnectionStringBuilder();
            builder.DataSource = @".\SQLExpress";
            builder.IntegratedSecurity = true;
            var alone = Alone.GetInitialized();
            builder.AttachDBFilename = alone.Info;
            All();
            Spisok();
        }

        // НАЗАД
        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Menu m = new Menu();
            m.Show();
        }

        // ПОИСК КЛИЕНТА ПО ИМЕНИ И ФАМИЛИИ
        private void button1_Click(object sender, EventArgs e)
        {
            string strSQL = "SELECT * FROM Users WHERE UName LIKE '" + textBox1.Text + "' "
                        + "AND USurname LIKE '" + textBox2.Text + "'";
            //if(textBox1.Text )
            using (cn = new SqlConnection(builder.ConnectionString))
            {
                try
                {
                    cn.Open();
                    SqlCommand cmd = new SqlCommand(strSQL, cn);
                    SqlDataReader rdr = cmd.ExecuteReader();

                    DataTable t = new DataTable();
                    t.Load(rdr);
                    dataGridView1.DataSource = t.DefaultView;

                    cn.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        // ВЫВОД КЛИЕНТОВ В TABLEVIEW
        private void All()
        {
            using (cn = new SqlConnection(builder.ConnectionString))
            {
                try
                {
                    cn.Open();
                    string strSQL = "SELECT ID_user as ID, UName as Имя, USurname as Фамилия, Telephone as Телефон FROM Users";
                    SqlCommand cmd = new SqlCommand(strSQL, cn);
                    SqlDataReader rdr = cmd.ExecuteReader();
                    DataTable t = new DataTable();
                    t.Load(rdr);
                    dataGridView1.DataSource = t.DefaultView;
                    rdr.Close();
                    cn.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }

        // ВЫВОД СПИСКА КЛИЕНТОВ
        public void Spisok()
        {
            // ПОДСЧЕТ КОЛИЧЕСТВА КЛИЕНТОВ
            string kol = "SELECT COUNT(DISTINCT Telephone) FROM Users; ";
            using (cn = new SqlConnection(builder.ConnectionString))
            {
                try
                {
                    cn.Open();
                    SqlCommand da = new SqlCommand(kol, cn);
                    label9.Text = da.ExecuteScalar().ToString();
                    cn.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

            // ВЕСЬ СПИСОК В LISTBOX1
            string strSQL2;
            string info;
            using (cn = new SqlConnection(builder.ConnectionString))
            {
                try
                {
                    cn.Open();
                    strSQL2 = "SELECT * From Users";
                    SqlCommand cmd = new SqlCommand(strSQL2, cn);
                    SqlDataReader rdr2 = cmd.ExecuteReader();
                    while (rdr2.Read())
                    {

                        //Формируем строку с информацией о заказе
                        // в нужной последовательности
                        info = rdr2["ID_user"] + " " +
                            Convert.ToString(rdr2["UName"]) + " " + Convert.ToString(rdr2["USurname"]) + " " +
                            Convert.ToString(rdr2["Telephone"]);
                        this.listBox1.Items.Add(info);


                    }
                    cn.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        // УДАЛЕНИЕ ПО ID
        private void button2_Click(object sender, EventArgs e)
        {
            {
                int row = dataGridView1.CurrentCell.RowIndex;
                using (cn = new SqlConnection(builder.ConnectionString))
                {
                    try
                    {
                        cn.Open();
                        string rs = "DELETE FROM Users WHERE ID_user = '" + Convert.ToInt32(textBox3.Text) + "'";
                        SqlCommand cmd = new SqlCommand(rs, cn);
                        if (cmd.ExecuteNonQuery() == 1)
                            MessageBox.Show("Запись успешно удалена!");
                        cn.Close();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                All();
            }
        }

        // ПОКАЗАТЬ ВЕСЬ СПИСОК
        private void button4_Click(object sender, EventArgs e)
        {
            All();
        }
    }
}