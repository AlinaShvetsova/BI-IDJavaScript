﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KursovayaFootwearCSharp.MVC
{
    class Controller
    {
        public string Question(string msg)//msg - то что ищем  
        {
            Model model = new Model();
            return "На даный момент:  "
                + model.GetAnser(msg);
        }
    }
}
