﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KursovayaFootwearCSharp.MVC
{
    static class DataBase
    {
        public static string GetAnser(string question)
        {

            SqlConnectionStringBuilder builder;
            SqlConnection cn;
            builder = new SqlConnectionStringBuilder();
            builder.DataSource = @".\SQLExpress";
            builder.IntegratedSecurity = true;
            var alone = Alone.GetInitialized();
            builder.AttachDBFilename = alone.Info;

            string anser = "";
            string status = "Select Status From OrderS Where ID_order =" + question;
            // создаем обьект (читатель)  
            using (cn = new SqlConnection(builder.ConnectionString))
            {
                try
                {
                    cn.Open();
                    SqlCommand cmd = new SqlCommand(status, cn);
                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            anser = rdr.GetValue(0).ToString();
                        }
                    }
                    else
                        return "Не существует";
                    cn.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            return anser;
        }
    }
}
