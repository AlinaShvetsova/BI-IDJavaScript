﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KursovayaFootwearCSharp.MVC
{
    class Model
    {
        //question - то что ищем  
        public string GetAnser(string question)
        {
            
            return DataBase.GetAnser(question); 
        }
    }
}
