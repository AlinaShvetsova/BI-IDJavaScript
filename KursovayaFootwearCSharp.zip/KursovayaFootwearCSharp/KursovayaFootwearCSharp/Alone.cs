﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KursovayaFootwearCSharp
{
    class Alone
    {
        private static Alone al = null;
        private string inf;
        public string Info => inf;
        private Alone(string inf1)
        {
            inf = inf1;
        }
        public static Alone GetInitialize(string inf1)
        {
            if (al == null)
                al = new Alone(inf1);
            return al;
        }

        public static Alone GetInitialized()
        {
            return al;
        }
        
    }
}
