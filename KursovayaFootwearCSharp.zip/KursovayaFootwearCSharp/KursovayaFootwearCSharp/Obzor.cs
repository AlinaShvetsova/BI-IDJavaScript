﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace KursovayaFootwearCSharp
{

    public partial class Obzor : Form
    {

        public Obzor()
        {

            builder = new SqlConnectionStringBuilder();
            InitializeComponent();
            
        }
       // ВЫБОР БАЗЫ ДАННЫХ
        SqlConnectionStringBuilder builder;
        private void button1_Click(object sender, EventArgs e)
        {
            using (openFileDialog1 = new OpenFileDialog())
            {
                openFileDialog1.InitialDirectory = @"C:\Bd";
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    var alone = Alone.GetInitialize(openFileDialog1.FileName);
                    textBox1.Text = alone.Info;
                }
            }
        }

        // АКТИВАЦИЯ КНОПКИ "ДАЛЕЕ"
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text.Length >= 8)
            {
                button2.Enabled = true;
            }
        }

        // ПЕРЕХОД В ОКНО АВТОРИЗАЦИИ
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginIN l = new LoginIN();
            var alone = Alone.GetInitialized();
            builder.AttachDBFilename = alone.Info;
            l.ShowDialog(this);
        }

        private void Obzor_Load(object sender, EventArgs e)
        {

        }
    }
}
