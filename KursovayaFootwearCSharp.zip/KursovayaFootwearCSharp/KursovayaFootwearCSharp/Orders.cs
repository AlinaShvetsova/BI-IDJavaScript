﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace KursovayaFootwearCSharp
{
    public partial class Orders : Form
    {
        SqlConnectionStringBuilder builder;
        SqlConnection cn;

        public Orders()
        {
            InitializeComponent();

            builder = new SqlConnectionStringBuilder();
            builder.DataSource = @".\SQLExpress";
            builder.IntegratedSecurity = true;
            var alone = Alone.GetInitialized();
            builder.AttachDBFilename = alone.Info;
            All();

            using (cn = new SqlConnection(builder.ConnectionString))
            {
                try
                {
                    cn.Open();
                    string strSQL = "Select Service From Price";
                    SqlCommand cmd = new SqlCommand(strSQL, cn);
                    SqlDataReader rdr = cmd.ExecuteReader();
                    int i = 0;
                    while (rdr.Read())
                    {
                        comboBox1.Items.Insert(i, rdr["Service"]);
                    }
                    cn.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void All()
        {
            string strSQL = "Select OrderS.ID_order as ID, Users.UName as Имя, Users.USurname as Фамилия, Users.Telephone as Телефон," +
                " Price.Service as Услуга, OrderS.Quarnity as Количество, OrderS.DTime as Дата, " +
                "OrderS.Status as Статус From OrderS, Users, Price WHERE OrderS.ID_user = Users.ID_user " +
                "AND OrderS.ID_service=Price.ID_service";

            using (cn = new SqlConnection(builder.ConnectionString))
            {
                try
                {
                    cn.Open();
                    SqlCommand cmd = new SqlCommand(strSQL, cn);
                    SqlDataReader rdr = cmd.ExecuteReader();
                    DataTable t = new DataTable();
                    t.Load(rdr);
                    dataGridView1.DataSource = t.DefaultView;
                    cn.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private int choose(string id, string table, string column, string cmb)
        {
            int k = 0;
            using (cn = new SqlConnection(builder.ConnectionString))
            {
                try
                {
                    cn.Open();
                    string strSQL = "Select " + id + " From " + table + " Where " + column + " like '" + cmb + "' ";
                    SqlCommand cmd = new SqlCommand(strSQL, cn);
                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            k = Convert.ToInt32(rdr.GetValue(0));
                        }
                    }
                    rdr.Close();
                    cn.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                if (k != 0)
                    return k;
                else
                    return 0;
            }
        }

        private Boolean txtCheck()
        {
            int k = 0;
            char[] n = textBox1.Text.ToString().ToCharArray(), s = textBox2.Text.ToString().ToCharArray();
            for (int i = 0; i < textBox1.TextLength; i++)
            {
                if (Char.IsDigit(n[i]))
                    k++;
            }
            for (int i = 0; i < textBox2.TextLength; i++)
            {
                if (Char.IsDigit(s[i]))
                    k++;
            }

            if (k == 0)
                return true;
            else return false;
        }

        // ДОБАВИТЬ НОВЫЙ ЗАКАЗ
        private void button1_Click_1(object sender, EventArgs e)
        {
            if (txtCheck())
            {
                int or = choose("ID_service", "Price", "Service", comboBox1.Text);
                string stat = "В процессе";
                using (cn = new SqlConnection(builder.ConnectionString))
                {
                    try
                    {
                        // ДОБАВЛЕНИЕ КЛИЕНТА
                        cn.Open();
                        string strSQL = "INSERT INTO Users VALUES (" + "'" + textBox2.Text +
                            "','" + textBox1.Text + "','" + maskedTextBox1.Text + "')";
                        SqlCommand cmd = new SqlCommand(strSQL, cn);
                        if (cmd.ExecuteNonQuery() == 1)
                            MessageBox.Show("Клиент успешно добавлен!");
                        cn.Close();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show("В Клиентах " + ex.Message);
                    }
                }
                int id = 0;
                using (cn = new SqlConnection(builder.ConnectionString))
                {
                    try
                    {
                        // ВЫБОР ID ДОБАВЛЕННОГО КЛИЕНТА
                        cn.Open();
                        string strSQL = "Select ID_user From Users Where Telephone = '" + maskedTextBox1.Text + "'";
                        SqlCommand cmd = new SqlCommand(strSQL, cn);
                        SqlDataReader rdr = cmd.ExecuteReader();
                        while (rdr.Read())
                        {
                            id = Convert.ToInt32(rdr["ID_user"]);
                        }
                        rdr.Close();
                        cn.Close();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }

                using (cn = new SqlConnection(builder.ConnectionString))
                {
                    try
                    {
                        // ДОБАВЛЕНИЕ ЗАКАЗА
                        cn.Open();
                        string strSQL1 = "INSERT INTO OrderS VALUES (" + id +
                            "," + or + "," + 1 + ",'" + DateTime.Now.ToString() + "'," + Convert.ToInt32(textBox3.Text) + ",'" + stat + "')";

                        SqlCommand cmd = new SqlCommand(strSQL1, cn);
                        if (cmd.ExecuteNonQuery() == 1)
                            MessageBox.Show("Заказ успешно добавлен!");
                        cn.Close();
                        All();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show("В ЗАКАЗАХ " + ex.Message);
                    }
                }
            }
            else
                MessageBox.Show("Некорректные данные в поле: Имя и/или Фамилия!" + "\n"+
                    "Вводите только буквы!");
        }

        // ПОДСЧЕТ ИТОГОВОЙ СУММЫ
        private void button3_Click(object sender, EventArgs e)
        {
            string kol = "SELECT SUM(Price.Cost)* OrderS.Quarnity FROM Price, OrderS WHERE  Price.ID_service= OrderS.ID_service " +
                "AND ID_order =" + textBox6.Text + "GROUP BY OrderS.Quarnity  ";
            using (cn = new SqlConnection(builder.ConnectionString))
            {
                try
                {

                    cn.Open();
                    SqlCommand da = new SqlCommand(kol, cn);
                    //DataTable t = new DataTable();

                    //da.Fill(t);
                    label10.Text = da.ExecuteScalar().ToString();
                    cn.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        //УДАЛЕНИЕ ЗАКАЗА ПО ID
        private void button2_Click(object sender, EventArgs e)
        {
            {
                int row = dataGridView1.CurrentCell.RowIndex;
                using (cn = new SqlConnection(builder.ConnectionString))
                {
                    try
                    {
                        cn.Open();
                        string rs = "DELETE FROM OrderS WHERE OrderS.ID_order = '" + Convert.ToInt32(textBox5.Text) + "'";
                        SqlCommand cmd = new SqlCommand(rs, cn);
                        if (cmd.ExecuteNonQuery() == 1)
                            MessageBox.Show("Запись успешно удалена!");
                        cn.Close();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                All();
            }
        }

        // НАЗАД
        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Menu m = new Menu();
            m.Show();
        }

        // ПРИМЕНЕНИЕ ПАТТЕРНА MVC
        // создаем объект класса Controller  
        MVC.Controller controller = new MVC.Controller();

        private void button5_Click_1(object sender, EventArgs e)
        {
            if (textBox4.Text != "")
                // выводим результат  
                MessageBox.Show(controller.Question(textBox4.Text));
            
        }
    }
}
