package base;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import service.endpoint.TovarServiceService;
import service.endpoint.ForPCServiceService;
import service.endpoint.AccesuarsServiceService;
import types.ListOfTovar;
import types.ListOfForPC;
import types.ListOfAccesuars;
import types.Tovar;
import types.ForPC;
import types.Accesuars;

public class menu extends javax.swing.JFrame {
    public menu() {
        initComponents();
    }

    static DefaultTableModel model = new DefaultTableModel();
    static TovarServiceService tovarService = null;
    static{
        tovarService = new TovarServiceService();
    }

    static DefaultTableModel model1 = new DefaultTableModel();
    static ForPCServiceService forpcService = null;
    static{
        forpcService = new ForPCServiceService();
    }
    
    static DefaultTableModel model2 = new DefaultTableModel();
    static AccesuarsServiceService accesuarsService = null;
    static{
        accesuarsService = new AccesuarsServiceService();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Computers = new javax.swing.JDialog();
        txtTotalSumma = new javax.swing.JTextField();
        lbl = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl = new javax.swing.JTable();
        tlBar = new javax.swing.JToolBar();
        btnAdd = new javax.swing.JButton();
        spr1 = new javax.swing.JToolBar.Separator();
        btnDecide = new javax.swing.JButton();
        spr7 = new javax.swing.JToolBar.Separator();
        btnDelete = new javax.swing.JButton();
        spr2 = new javax.swing.JToolBar.Separator();
        btnCancelComp = new javax.swing.JButton();
        Post = new javax.swing.JDialog();
        jLabel2 = new javax.swing.JLabel();
        btnApple = new javax.swing.JButton();
        btnASUS = new javax.swing.JButton();
        btnMSI = new javax.swing.JButton();
        btnCancelP = new javax.swing.JButton();
        forPC = new javax.swing.JDialog();
        spnKol2 = new javax.swing.JSpinner();
        btnAddTovar2 = new javax.swing.JButton();
        btnCancel2 = new javax.swing.JButton();
        lblName2 = new javax.swing.JLabel();
        lblKol2 = new javax.swing.JLabel();
        cmbName2 = new javax.swing.JComboBox();
        scrPrice = new javax.swing.JScrollBar();
        lblPrice = new javax.swing.JLabel();
        lblPriceInfo = new javax.swing.JLabel();
        tblAcc = new javax.swing.JDialog();
        txtTotalSumma2 = new javax.swing.JTextField();
        lbl2 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl2 = new javax.swing.JTable();
        tlBar2 = new javax.swing.JToolBar();
        btnAdd2 = new javax.swing.JButton();
        spr5 = new javax.swing.JToolBar.Separator();
        btnDecide2 = new javax.swing.JButton();
        spr6 = new javax.swing.JToolBar.Separator();
        btnDelete1 = new javax.swing.JButton();
        spr8 = new javax.swing.JToolBar.Separator();
        btnCancelComp2 = new javax.swing.JButton();
        tblForPC = new javax.swing.JDialog();
        txtTotalSumma1 = new javax.swing.JTextField();
        lbl1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl1 = new javax.swing.JTable();
        tlBar1 = new javax.swing.JToolBar();
        btnAdd1 = new javax.swing.JButton();
        spr3 = new javax.swing.JToolBar.Separator();
        btnDecide1 = new javax.swing.JButton();
        spr4 = new javax.swing.JToolBar.Separator();
        btnDelete2 = new javax.swing.JButton();
        spr9 = new javax.swing.JToolBar.Separator();
        btnCancelComp1 = new javax.swing.JButton();
        addAcc = new javax.swing.JDialog();
        lblPriceInfo1 = new javax.swing.JLabel();
        lblPrice1 = new javax.swing.JLabel();
        scrPrice1 = new javax.swing.JScrollBar();
        cmbName3 = new javax.swing.JComboBox();
        lblKol3 = new javax.swing.JLabel();
        lblName3 = new javax.swing.JLabel();
        btnCancel3 = new javax.swing.JButton();
        btnAddTovar3 = new javax.swing.JButton();
        spnKol3 = new javax.swing.JSpinner();
        addApple = new javax.swing.JDialog();
        lblPriceInfo2 = new javax.swing.JLabel();
        spnKol4 = new javax.swing.JSpinner();
        btnAddTovar4 = new javax.swing.JButton();
        btnCancel4 = new javax.swing.JButton();
        lblName4 = new javax.swing.JLabel();
        lblKol4 = new javax.swing.JLabel();
        cmbName4 = new javax.swing.JComboBox();
        scrPrice2 = new javax.swing.JScrollBar();
        lblPrice2 = new javax.swing.JLabel();
        addMSI = new javax.swing.JDialog();
        lblPriceInfo3 = new javax.swing.JLabel();
        spnKol5 = new javax.swing.JSpinner();
        btnAddTovar5 = new javax.swing.JButton();
        btnCancel5 = new javax.swing.JButton();
        lblName5 = new javax.swing.JLabel();
        lblKol5 = new javax.swing.JLabel();
        cmbName5 = new javax.swing.JComboBox();
        scrPrice3 = new javax.swing.JScrollBar();
        lblPrice3 = new javax.swing.JLabel();
        addASUS = new javax.swing.JDialog();
        lblPriceInfo4 = new javax.swing.JLabel();
        spnKol6 = new javax.swing.JSpinner();
        btnAddTovar6 = new javax.swing.JButton();
        btnCancel6 = new javax.swing.JButton();
        lblName6 = new javax.swing.JLabel();
        lblKol6 = new javax.swing.JLabel();
        cmbName6 = new javax.swing.JComboBox();
        scrPrice4 = new javax.swing.JScrollBar();
        lblPrice4 = new javax.swing.JLabel();
        Scores = new javax.swing.JDialog();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        doComputers = new javax.swing.JButton();
        btnAcc = new javax.swing.JButton();
        btnExitMenu = new javax.swing.JButton();
        btnForPC = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        Computers.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                ComputersWindowOpened(evt);
            }
        });

        txtTotalSumma.setEditable(false);
        txtTotalSumma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalSummaActionPerformed(evt);
            }
        });

        lbl.setText("Общая сумма товаров");

        tbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "№ п,п", "Название", "Цена", "Количество", "Сумма"
            }
        ));
        tbl.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                tblAncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane1.setViewportView(tbl);

        tlBar.setRollover(true);

        btnAdd.setText("Добавить");
        btnAdd.setFocusable(false);
        btnAdd.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnAdd.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });
        tlBar.add(btnAdd);
        tlBar.add(spr1);

        btnDecide.setText("Вычислить");
        btnDecide.setFocusable(false);
        btnDecide.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnDecide.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnDecide.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDecideActionPerformed(evt);
            }
        });
        tlBar.add(btnDecide);
        tlBar.add(spr7);

        btnDelete.setText("Удалить");
        btnDelete.setFocusable(false);
        btnDelete.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnDelete.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        tlBar.add(btnDelete);
        tlBar.add(spr2);

        btnCancelComp.setText("Назад");
        btnCancelComp.setFocusable(false);
        btnCancelComp.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnCancelComp.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnCancelComp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelCompActionPerformed(evt);
            }
        });
        tlBar.add(btnCancelComp);

        javax.swing.GroupLayout ComputersLayout = new javax.swing.GroupLayout(Computers.getContentPane());
        Computers.getContentPane().setLayout(ComputersLayout);
        ComputersLayout.setHorizontalGroup(
            ComputersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ComputersLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(ComputersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(ComputersLayout.createSequentialGroup()
                        .addComponent(lbl)
                        .addGap(18, 18, 18)
                        .addComponent(txtTotalSumma, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 106, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(ComputersLayout.createSequentialGroup()
                .addComponent(tlBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        ComputersLayout.setVerticalGroup(
            ComputersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ComputersLayout.createSequentialGroup()
                .addComponent(tlBar, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(ComputersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTotalSumma, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl))
                .addContainerGap(36, Short.MAX_VALUE))
        );

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel2.setText("Выберите поставщика");

        btnApple.setText("Apple");
        btnApple.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAppleActionPerformed(evt);
            }
        });

        btnASUS.setText("ASUS");
        btnASUS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnASUSActionPerformed(evt);
            }
        });

        btnMSI.setText("MSI");
        btnMSI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMSIActionPerformed(evt);
            }
        });

        btnCancelP.setText("Назад");
        btnCancelP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelPActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PostLayout = new javax.swing.GroupLayout(Post.getContentPane());
        Post.getContentPane().setLayout(PostLayout);
        PostLayout.setHorizontalGroup(
            PostLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PostLayout.createSequentialGroup()
                .addGroup(PostLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PostLayout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(jLabel2))
                    .addGroup(PostLayout.createSequentialGroup()
                        .addGap(91, 91, 91)
                        .addGroup(PostLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnApple, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnASUS, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnMSI, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnCancelP, javax.swing.GroupLayout.DEFAULT_SIZE, 82, Short.MAX_VALUE))))
                .addContainerGap(45, Short.MAX_VALUE))
        );
        PostLayout.setVerticalGroup(
            PostLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PostLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(30, 30, 30)
                .addComponent(btnApple, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnASUS, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnMSI, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                .addComponent(btnCancelP, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38))
        );

        spnKol2.setModel(new javax.swing.SpinnerNumberModel(0, 0, 30, 1));

        btnAddTovar2.setText("Добавить");
        btnAddTovar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddTovar2ActionPerformed(evt);
            }
        });

        btnCancel2.setText("Отменить");
        btnCancel2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancel2ActionPerformed(evt);
            }
        });

        lblName2.setText("Наименование");

        lblKol2.setText("Количество");

        cmbName2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Что-то для ПК", "Что-то для ПК2", "Что-то для ПК3" }));
        cmbName2.setToolTipText("");
        cmbName2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbName2ActionPerformed(evt);
            }
        });

        scrPrice.setMaximum(4000);
        scrPrice.setMinimum(1000);
        scrPrice.setOrientation(javax.swing.JScrollBar.HORIZONTAL);
        scrPrice.setToolTipText("");
        scrPrice.setUnitIncrement(1000);
        scrPrice.setValue(4000);
        scrPrice.setVisibleAmount(10);
        scrPrice.addAdjustmentListener(new java.awt.event.AdjustmentListener() {
            public void adjustmentValueChanged(java.awt.event.AdjustmentEvent evt) {
                scrPriceAdjustmentValueChanged(evt);
            }
        });

        lblPrice.setText("Цена");

        lblPriceInfo.setText("4000");

        javax.swing.GroupLayout forPCLayout = new javax.swing.GroupLayout(forPC.getContentPane());
        forPC.getContentPane().setLayout(forPCLayout);
        forPCLayout.setHorizontalGroup(
            forPCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(forPCLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(forPCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(forPCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(forPCLayout.createSequentialGroup()
                            .addComponent(lblPrice)
                            .addGap(83, 83, 83)
                            .addComponent(scrPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, forPCLayout.createSequentialGroup()
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblPriceInfo)
                            .addGap(75, 75, 75)))
                    .addGroup(forPCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(forPCLayout.createSequentialGroup()
                            .addComponent(lblKol2)
                            .addGap(31, 31, 31)
                            .addGroup(forPCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(forPCLayout.createSequentialGroup()
                                    .addComponent(btnAddTovar2)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnCancel2))
                                .addComponent(spnKol2, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(forPCLayout.createSequentialGroup()
                            .addComponent(lblName2)
                            .addGap(18, 18, 18)
                            .addComponent(cmbName2, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        forPCLayout.setVerticalGroup(
            forPCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(forPCLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(forPCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblName2)
                    .addComponent(cmbName2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(forPCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblKol2)
                    .addComponent(spnKol2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblPriceInfo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(forPCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblPrice)
                    .addComponent(scrPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addGroup(forPCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCancel2)
                    .addComponent(btnAddTovar2))
                .addContainerGap())
        );

        tblAcc.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                tblAccWindowOpened(evt);
            }
        });

        txtTotalSumma2.setEditable(false);
        txtTotalSumma2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalSumma2ActionPerformed(evt);
            }
        });

        lbl2.setText("Общая сумма товаров");

        tbl2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "№ п,п", "Название", "Цена", "Количество", "Сумма"
            }
        ));
        tbl2.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                tbl2AncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane3.setViewportView(tbl2);

        tlBar2.setRollover(true);

        btnAdd2.setText("Добавить");
        btnAdd2.setFocusable(false);
        btnAdd2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnAdd2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnAdd2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdd2ActionPerformed(evt);
            }
        });
        tlBar2.add(btnAdd2);
        tlBar2.add(spr5);

        btnDecide2.setText("Вычислить");
        btnDecide2.setFocusable(false);
        btnDecide2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnDecide2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnDecide2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDecide2ActionPerformed(evt);
            }
        });
        tlBar2.add(btnDecide2);
        tlBar2.add(spr6);

        btnDelete1.setText("Удалить");
        btnDelete1.setFocusable(false);
        btnDelete1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnDelete1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnDelete1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelete1ActionPerformed(evt);
            }
        });
        tlBar2.add(btnDelete1);
        tlBar2.add(spr8);

        btnCancelComp2.setText("Назад");
        btnCancelComp2.setFocusable(false);
        btnCancelComp2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnCancelComp2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnCancelComp2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelComp2ActionPerformed(evt);
            }
        });
        tlBar2.add(btnCancelComp2);

        javax.swing.GroupLayout tblAccLayout = new javax.swing.GroupLayout(tblAcc.getContentPane());
        tblAcc.getContentPane().setLayout(tblAccLayout);
        tblAccLayout.setHorizontalGroup(
            tblAccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tblAccLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(tblAccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(tblAccLayout.createSequentialGroup()
                        .addComponent(lbl2)
                        .addGap(18, 18, 18)
                        .addComponent(txtTotalSumma2, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 106, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(tblAccLayout.createSequentialGroup()
                .addComponent(tlBar2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        tblAccLayout.setVerticalGroup(
            tblAccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tblAccLayout.createSequentialGroup()
                .addComponent(tlBar2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(tblAccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTotalSumma2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl2))
                .addContainerGap(36, Short.MAX_VALUE))
        );

        tblForPC.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                tblForPCWindowOpened(evt);
            }
        });

        txtTotalSumma1.setEditable(false);
        txtTotalSumma1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalSumma1ActionPerformed(evt);
            }
        });

        lbl1.setText("Общая сумма товаров");

        tbl1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "№ п,п", "Название", "Цена", "Количество", "Сумма"
            }
        ));
        tbl1.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                tbl1AncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane2.setViewportView(tbl1);

        tlBar1.setRollover(true);

        btnAdd1.setText("Добавить");
        btnAdd1.setFocusable(false);
        btnAdd1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnAdd1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnAdd1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdd1ActionPerformed(evt);
            }
        });
        tlBar1.add(btnAdd1);
        tlBar1.add(spr3);

        btnDecide1.setText("Вычислить");
        btnDecide1.setFocusable(false);
        btnDecide1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnDecide1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnDecide1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDecide1ActionPerformed(evt);
            }
        });
        tlBar1.add(btnDecide1);
        tlBar1.add(spr4);

        btnDelete2.setText("Удалить");
        btnDelete2.setFocusable(false);
        btnDelete2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnDelete2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnDelete2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelete2ActionPerformed(evt);
            }
        });
        tlBar1.add(btnDelete2);
        tlBar1.add(spr9);

        btnCancelComp1.setText("Назад");
        btnCancelComp1.setFocusable(false);
        btnCancelComp1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnCancelComp1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnCancelComp1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelComp1ActionPerformed(evt);
            }
        });
        tlBar1.add(btnCancelComp1);

        javax.swing.GroupLayout tblForPCLayout = new javax.swing.GroupLayout(tblForPC.getContentPane());
        tblForPC.getContentPane().setLayout(tblForPCLayout);
        tblForPCLayout.setHorizontalGroup(
            tblForPCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tblForPCLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(tblForPCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tblForPCLayout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 381, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(tblForPCLayout.createSequentialGroup()
                        .addComponent(lbl1)
                        .addGap(18, 18, 18)
                        .addComponent(txtTotalSumma1, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(tblForPCLayout.createSequentialGroup()
                .addComponent(tlBar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        tblForPCLayout.setVerticalGroup(
            tblForPCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tblForPCLayout.createSequentialGroup()
                .addComponent(tlBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(tblForPCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTotalSumma1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl1))
                .addContainerGap(36, Short.MAX_VALUE))
        );

        lblPriceInfo1.setText("1500");

        lblPrice1.setText("Цена");

        scrPrice1.setMaximum(1500);
        scrPrice1.setMinimum(100);
        scrPrice1.setOrientation(javax.swing.JScrollBar.HORIZONTAL);
        scrPrice1.setToolTipText("");
        scrPrice1.setUnitIncrement(100);
        scrPrice1.addAdjustmentListener(new java.awt.event.AdjustmentListener() {
            public void adjustmentValueChanged(java.awt.event.AdjustmentEvent evt) {
                scrPrice1AdjustmentValueChanged(evt);
            }
        });

        cmbName3.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Подставка для ноутбука FinePower IC-588A черный", "Компактная мышь проводная Defender Patch MS-759 черная", "Коврик \"Тигр\"" }));
        cmbName3.setToolTipText("");
        cmbName3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbName3ActionPerformed(evt);
            }
        });

        lblKol3.setText("Количество");

        lblName3.setText("Наименование");

        btnCancel3.setText("Отменить");
        btnCancel3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancel3ActionPerformed(evt);
            }
        });

        btnAddTovar3.setText("Добавить");
        btnAddTovar3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddTovar3ActionPerformed(evt);
            }
        });

        spnKol3.setModel(new javax.swing.SpinnerNumberModel(0, 0, 30, 1));

        javax.swing.GroupLayout addAccLayout = new javax.swing.GroupLayout(addAcc.getContentPane());
        addAcc.getContentPane().setLayout(addAccLayout);
        addAccLayout.setHorizontalGroup(
            addAccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addAccLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(addAccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(addAccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(addAccLayout.createSequentialGroup()
                            .addComponent(lblKol3)
                            .addGap(31, 31, 31)
                            .addGroup(addAccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(addAccLayout.createSequentialGroup()
                                    .addComponent(spnKol3, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(0, 0, Short.MAX_VALUE))
                                .addGroup(addAccLayout.createSequentialGroup()
                                    .addComponent(btnAddTovar3)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnCancel3))))
                        .addGroup(addAccLayout.createSequentialGroup()
                            .addComponent(lblName3)
                            .addGap(18, 18, 18)
                            .addComponent(cmbName3, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(addAccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(addAccLayout.createSequentialGroup()
                            .addComponent(lblPrice1)
                            .addGap(83, 83, 83)
                            .addComponent(scrPrice1, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, addAccLayout.createSequentialGroup()
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblPriceInfo1)
                            .addGap(75, 75, 75))))
                .addContainerGap(35, Short.MAX_VALUE))
        );
        addAccLayout.setVerticalGroup(
            addAccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addAccLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(addAccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblName3)
                    .addComponent(cmbName3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(addAccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblKol3)
                    .addComponent(spnKol3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblPriceInfo1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(addAccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblPrice1)
                    .addComponent(scrPrice1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addGroup(addAccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddTovar3)
                    .addComponent(btnCancel3))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        lblPriceInfo2.setText("150000");

        spnKol4.setModel(new javax.swing.SpinnerNumberModel(0, 0, 30, 1));

        btnAddTovar4.setText("Добавить");
        btnAddTovar4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddTovar4ActionPerformed(evt);
            }
        });

        btnCancel4.setText("Отменить");
        btnCancel4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancel4ActionPerformed(evt);
            }
        });

        lblName4.setText("Наименование");

        lblKol4.setText("Количество");

        cmbName4.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Компьютер Apple", "Компьютер Apple2", "Компьютер Apple3" }));
        cmbName4.setToolTipText("");
        cmbName4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbName4ActionPerformed(evt);
            }
        });

        scrPrice2.setMaximum(150000);
        scrPrice2.setMinimum(30000);
        scrPrice2.setOrientation(javax.swing.JScrollBar.HORIZONTAL);
        scrPrice2.setToolTipText("");
        scrPrice2.setUnitIncrement(30000);
        scrPrice2.setValue(150000);
        scrPrice2.setVisibleAmount(10);
        scrPrice2.addAdjustmentListener(new java.awt.event.AdjustmentListener() {
            public void adjustmentValueChanged(java.awt.event.AdjustmentEvent evt) {
                scrPrice2AdjustmentValueChanged(evt);
            }
        });

        lblPrice2.setText("Цена");

        javax.swing.GroupLayout addAppleLayout = new javax.swing.GroupLayout(addApple.getContentPane());
        addApple.getContentPane().setLayout(addAppleLayout);
        addAppleLayout.setHorizontalGroup(
            addAppleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addAppleLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(addAppleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(addAppleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(addAppleLayout.createSequentialGroup()
                            .addComponent(lblPrice2)
                            .addGap(83, 83, 83)
                            .addComponent(scrPrice2, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, addAppleLayout.createSequentialGroup()
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblPriceInfo2)
                            .addGap(75, 75, 75)))
                    .addGroup(addAppleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(addAppleLayout.createSequentialGroup()
                            .addComponent(lblKol4)
                            .addGap(31, 31, 31)
                            .addGroup(addAppleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(addAppleLayout.createSequentialGroup()
                                    .addComponent(btnAddTovar4)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnCancel4))
                                .addComponent(spnKol4, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(addAppleLayout.createSequentialGroup()
                            .addComponent(lblName4)
                            .addGap(18, 18, 18)
                            .addComponent(cmbName4, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        addAppleLayout.setVerticalGroup(
            addAppleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addAppleLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(addAppleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblName4)
                    .addComponent(cmbName4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(addAppleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblKol4)
                    .addComponent(spnKol4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblPriceInfo2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(addAppleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblPrice2)
                    .addComponent(scrPrice2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 125, Short.MAX_VALUE)
                .addGroup(addAppleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddTovar4)
                    .addComponent(btnCancel4))
                .addGap(24, 24, 24))
        );

        lblPriceInfo3.setText("150000");

        spnKol5.setModel(new javax.swing.SpinnerNumberModel(0, 0, 30, 1));

        btnAddTovar5.setText("Добавить");
        btnAddTovar5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddTovar5ActionPerformed(evt);
            }
        });

        btnCancel5.setText("Отменить");
        btnCancel5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancel5ActionPerformed(evt);
            }
        });

        lblName5.setText("Наименование");

        lblKol5.setText("Количество");

        cmbName5.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Компьютер MSI", "Компьютер MSI2", "Компьютер MSI3" }));
        cmbName5.setToolTipText("");
        cmbName5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbName5ActionPerformed(evt);
            }
        });

        scrPrice3.setMaximum(150000);
        scrPrice3.setMinimum(30000);
        scrPrice3.setOrientation(javax.swing.JScrollBar.HORIZONTAL);
        scrPrice3.setToolTipText("");
        scrPrice3.setUnitIncrement(150000);
        scrPrice3.addAdjustmentListener(new java.awt.event.AdjustmentListener() {
            public void adjustmentValueChanged(java.awt.event.AdjustmentEvent evt) {
                scrPrice3AdjustmentValueChanged(evt);
            }
        });

        lblPrice3.setText("Цена");

        javax.swing.GroupLayout addMSILayout = new javax.swing.GroupLayout(addMSI.getContentPane());
        addMSI.getContentPane().setLayout(addMSILayout);
        addMSILayout.setHorizontalGroup(
            addMSILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addMSILayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(addMSILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(addMSILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(addMSILayout.createSequentialGroup()
                            .addComponent(lblPrice3)
                            .addGap(83, 83, 83)
                            .addComponent(scrPrice3, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, addMSILayout.createSequentialGroup()
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblPriceInfo3)
                            .addGap(75, 75, 75)))
                    .addGroup(addMSILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(addMSILayout.createSequentialGroup()
                            .addComponent(lblKol5)
                            .addGap(31, 31, 31)
                            .addGroup(addMSILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(addMSILayout.createSequentialGroup()
                                    .addComponent(btnAddTovar5)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnCancel5))
                                .addComponent(spnKol5, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(addMSILayout.createSequentialGroup()
                            .addComponent(lblName5)
                            .addGap(18, 18, 18)
                            .addComponent(cmbName5, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        addMSILayout.setVerticalGroup(
            addMSILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addMSILayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(addMSILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblName5)
                    .addComponent(cmbName5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(addMSILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblKol5)
                    .addComponent(spnKol5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblPriceInfo3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(addMSILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblPrice3)
                    .addComponent(scrPrice3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 138, Short.MAX_VALUE)
                .addGroup(addMSILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCancel5)
                    .addComponent(btnAddTovar5))
                .addContainerGap())
        );

        lblPriceInfo4.setText("150000");

        spnKol6.setModel(new javax.swing.SpinnerNumberModel(0, 0, 30, 1));

        btnAddTovar6.setText("Добавить");
        btnAddTovar6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddTovar6ActionPerformed(evt);
            }
        });

        btnCancel6.setText("Отменить");
        btnCancel6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancel6ActionPerformed(evt);
            }
        });

        lblName6.setText("Наименование");

        lblKol6.setText("Количество");

        cmbName6.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Компьютер ASUS", "Компьютер ASUS2", "Компьютер ASUS3" }));
        cmbName6.setToolTipText("");
        cmbName6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbName6ActionPerformed(evt);
            }
        });

        scrPrice4.setMaximum(150000);
        scrPrice4.setMinimum(30000);
        scrPrice4.setOrientation(javax.swing.JScrollBar.HORIZONTAL);
        scrPrice4.setToolTipText("");
        scrPrice4.setUnitIncrement(150000);
        scrPrice4.addAdjustmentListener(new java.awt.event.AdjustmentListener() {
            public void adjustmentValueChanged(java.awt.event.AdjustmentEvent evt) {
                scrPrice4AdjustmentValueChanged(evt);
            }
        });

        lblPrice4.setText("Цена");

        javax.swing.GroupLayout addASUSLayout = new javax.swing.GroupLayout(addASUS.getContentPane());
        addASUS.getContentPane().setLayout(addASUSLayout);
        addASUSLayout.setHorizontalGroup(
            addASUSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addASUSLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(addASUSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(addASUSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(addASUSLayout.createSequentialGroup()
                            .addComponent(lblPrice4)
                            .addGap(83, 83, 83)
                            .addComponent(scrPrice4, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, addASUSLayout.createSequentialGroup()
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblPriceInfo4)
                            .addGap(75, 75, 75)))
                    .addGroup(addASUSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(addASUSLayout.createSequentialGroup()
                            .addComponent(lblKol6)
                            .addGap(31, 31, 31)
                            .addGroup(addASUSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(addASUSLayout.createSequentialGroup()
                                    .addComponent(btnAddTovar6)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnCancel6))
                                .addComponent(spnKol6, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(addASUSLayout.createSequentialGroup()
                            .addComponent(lblName6)
                            .addGap(18, 18, 18)
                            .addComponent(cmbName6, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        addASUSLayout.setVerticalGroup(
            addASUSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addASUSLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(addASUSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblName6)
                    .addComponent(cmbName6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(addASUSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblKol6)
                    .addComponent(spnKol6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblPriceInfo4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(addASUSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblPrice4)
                    .addComponent(scrPrice4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 138, Short.MAX_VALUE)
                .addGroup(addASUSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCancel6)
                    .addComponent(btnAddTovar6))
                .addContainerGap())
        );

        jLabel3.setText("Справочник адресов данного магазина по городу Киров");

        jLabel4.setText("Адрес 1");

        jLabel5.setText("Адрес 2");

        jLabel6.setText("Адрес 3");

        jLabel7.setText("Адрес 4");

        jLabel8.setText("Адрес 5");

        jLabel9.setText("Адрес 6");

        jLabel10.setText("Адрес 7");

        javax.swing.GroupLayout ScoresLayout = new javax.swing.GroupLayout(Scores.getContentPane());
        Scores.getContentPane().setLayout(ScoresLayout);
        ScoresLayout.setHorizontalGroup(
            ScoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ScoresLayout.createSequentialGroup()
                .addGroup(ScoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ScoresLayout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(jLabel3))
                    .addGroup(ScoresLayout.createSequentialGroup()
                        .addGap(156, 156, 156)
                        .addGroup(ScoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(jLabel4)
                            .addComponent(jLabel9)
                            .addComponent(jLabel8)
                            .addComponent(jLabel7)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6))))
                .addContainerGap(44, Short.MAX_VALUE))
        );
        ScoresLayout.setVerticalGroup(
            ScoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ScoresLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addGap(5, 5, 5)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel1.setText("МЕНЮ");

        doComputers.setText("Компьютеры/Ноутбуки");
        doComputers.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                doComputersActionPerformed(evt);
            }
        });

        btnAcc.setText("Аксессуары");
        btnAcc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAccActionPerformed(evt);
            }
        });

        btnExitMenu.setText("Выход");
        btnExitMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitMenuActionPerformed(evt);
            }
        });

        btnForPC.setText("Комплектующие для ПК");
        btnForPC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnForPCActionPerformed(evt);
            }
        });

        jButton1.setText("Адреса ");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(79, 79, 79)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(36, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(btnForPC, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnAcc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(doComputers, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnExitMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(38, 38, 38))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(doComputers, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnAcc, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnForPC, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnExitMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void doComputersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_doComputersActionPerformed

       Computers.setSize(500, 320);
       Computers.setVisible(true);
    }//GEN-LAST:event_doComputersActionPerformed

    private void btnExitMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitMenuActionPerformed
        setDefaultCloseOperation(this.EXIT_ON_CLOSE);
        System.exit(0);
    }//GEN-LAST:event_btnExitMenuActionPerformed

    private void txtTotalSummaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalSummaActionPerformed
        setDefaultCloseOperation(this.EXIT_ON_CLOSE);
        System.exit(0);
    }//GEN-LAST:event_txtTotalSummaActionPerformed

    private void tblAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_tblAncestorAdded
       
    }//GEN-LAST:event_tblAncestorAdded

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
        Post.setSize(300, 350);
        Post.setVisible(true);
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnDecideActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDecideActionPerformed
         try{
            txtTotalSumma.setText(Integer.toString(tovarService.getTovarServicePort().getSumOfTovar()));}      
            catch(Exception ex){
            ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Не удалось установить соединение с сервером:" + ex.getMessage() + ".",
                "Ошибка",
                JOptionPane.ERROR_MESSAGE);}    
    }//GEN-LAST:event_btnDecideActionPerformed

    private void btnCancelCompActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelCompActionPerformed
        Computers.setVisible(false);
    }//GEN-LAST:event_btnCancelCompActionPerformed

    private void btnAccActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAccActionPerformed
        tblAcc.setSize(550, 320);
        tblAcc.setVisible(true);

    }//GEN-LAST:event_btnAccActionPerformed

    private void btnAddTovar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddTovar2ActionPerformed
        forPC.setVisible(false);
        ForPC elF = new ForPC();
        elF = new ForPC();
            elF.setNameF(cmbName2.getSelectedItem().toString());
            elF.setKolF((int) spnKol2.getValue());
            elF.setPriceF(scrPrice.getValue());
        
         try{
            doVivod1(forpcService.getForPCServicePort().setNewTovarF(elF));
        }catch (Exception ex) {
            ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Не удалось добавить. Попытайтесь повторить попытку :" + ex.getMessage() + ".",
                "Ошибка",
                JOptionPane.ERROR_MESSAGE);
        }}                           
    private void doVivod1(ListOfForPC lstForPC){
        doClearTable1();
        int i = 1;
        for(ForPC forpc: lstForPC.getItem()){
            Object[] rowData = new Object[5];
            rowData[0] = i++;
            rowData[1] = forpc.getNameF();
            rowData[2] = forpc.getPriceF();
            rowData[3] = forpc.getKolF();
            rowData[4] = forpc.getPriceF() * forpc.getKolF();
            model1.addRow(rowData);
        }}
    private void doClearTable1(){
        while (model1.getRowCount()>0){
            model1.removeRow(0);
        }                                        
        
    }//GEN-LAST:event_btnAddTovar2ActionPerformed

    private void btnCancel2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancel2ActionPerformed
        forPC.setVisible(false);
    }//GEN-LAST:event_btnCancel2ActionPerformed

    private void cmbName2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbName2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbName2ActionPerformed

    private void btnASUSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnASUSActionPerformed
        addASUS.setSize(550, 320);
        addASUS.setVisible(true);
        Post.setVisible(false);
    }//GEN-LAST:event_btnASUSActionPerformed

    private void btnCancelPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelPActionPerformed
        Post.setVisible(false);        // TODO add your handling code here:
    }//GEN-LAST:event_btnCancelPActionPerformed

    private void btnForPCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnForPCActionPerformed
        tblForPC.setSize(400, 420);
        tblForPC.setVisible(true);
    }//GEN-LAST:event_btnForPCActionPerformed

    private void scrPriceAdjustmentValueChanged(java.awt.event.AdjustmentEvent evt) {//GEN-FIRST:event_scrPriceAdjustmentValueChanged
        lblPriceInfo.setText(Integer.toString((int) scrPrice.getValue())); // TODO add your handling code here:
    }//GEN-LAST:event_scrPriceAdjustmentValueChanged

    private void txtTotalSumma1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalSumma1ActionPerformed
        setDefaultCloseOperation(this.EXIT_ON_CLOSE);
        System.exit(0);
    }//GEN-LAST:event_txtTotalSumma1ActionPerformed

    private void tbl1AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_tbl1AncestorAdded
       
    }//GEN-LAST:event_tbl1AncestorAdded

    private void btnAdd1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdd1ActionPerformed
        forPC.setSize(550, 320);
        forPC.setVisible(true);       
    }//GEN-LAST:event_btnAdd1ActionPerformed

    private void btnDecide1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDecide1ActionPerformed
        try{
            txtTotalSumma1.setText(Integer.toString(forpcService.getForPCServicePort().getSumOfTovarF()));}      
            catch(Exception ex){
            ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Не удалось установить соединение с сервером:" + ex.getMessage() + ".",
                "Ошибка",
                JOptionPane.ERROR_MESSAGE);}    
    }//GEN-LAST:event_btnDecide1ActionPerformed

    private void txtTotalSumma2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalSumma2ActionPerformed
        setDefaultCloseOperation(this.EXIT_ON_CLOSE);
        System.exit(0);
    }//GEN-LAST:event_txtTotalSumma2ActionPerformed

    private void tbl2AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_tbl2AncestorAdded
    
    }//GEN-LAST:event_tbl2AncestorAdded

    private void btnAdd2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdd2ActionPerformed
        addAcc.setSize(550, 320);
        addAcc.setVisible(true);
    }//GEN-LAST:event_btnAdd2ActionPerformed

    private void btnDecide2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDecide2ActionPerformed
        try{
            txtTotalSumma2.setText(Integer.toString(accesuarsService.getAccesuarsServicePort().getSumOfTovarA()));}      
            catch(Exception ex){
            ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Не удалось установить соединение с сервером:" + ex.getMessage() + ".",
                "Ошибка",
                JOptionPane.ERROR_MESSAGE);}    
    }//GEN-LAST:event_btnDecide2ActionPerformed

    private void btnCancelComp2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelComp2ActionPerformed
        tblAcc.setVisible(false);
    }//GEN-LAST:event_btnCancelComp2ActionPerformed

    private void scrPrice1AdjustmentValueChanged(java.awt.event.AdjustmentEvent evt) {//GEN-FIRST:event_scrPrice1AdjustmentValueChanged
        lblPriceInfo1.setText(Integer.toString((int) scrPrice1.getValue())); // TODO add your handling code here:
    }//GEN-LAST:event_scrPrice1AdjustmentValueChanged

    private void cmbName3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbName3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbName3ActionPerformed

    private void btnCancel3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancel3ActionPerformed
        addAcc.setVisible(false);
    }//GEN-LAST:event_btnCancel3ActionPerformed

    private void btnAddTovar3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddTovar3ActionPerformed
        addAcc.setVisible(false);
        Accesuars el = new Accesuars();
        el.setNameA(cmbName3.getSelectedItem().toString());
        el.setKolA((int) spnKol3.getValue());
        el.setPriceA(scrPrice1.getValue());
        
        try{
            doVivod3(accesuarsService.getAccesuarsServicePort().setNewTovarA(el));
        }catch (Exception ex) {
            ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Не удалось добавить. Попытайтесь повторить попытку :" + ex.getMessage() + ".",
                "Ошибка",
                JOptionPane.ERROR_MESSAGE);
        }}
    private void doVivod3(ListOfAccesuars lstAccesuars){
        doClearTable3();
        int i = 1;
        for(Accesuars accesuars: lstAccesuars.getItem()){
            Object[] rowData = new Object[5];
            rowData[0] = i++;
            rowData[1] = accesuars.getNameA();
            rowData[2] = accesuars.getPriceA();
            rowData[3] = accesuars.getKolA();
            rowData[4] = accesuars.getPriceA() * accesuars.getKolA();
            model2.addRow(rowData);
        }}
    private void doClearTable3(){
        while (model2.getRowCount()>0){
            model2.removeRow(0);
        }                                        
        // TODO add your handling code here:
    }//GEN-LAST:event_btnAddTovar3ActionPerformed

    private void btnCancelComp1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelComp1ActionPerformed
        tblForPC.setVisible(false);
    }//GEN-LAST:event_btnCancelComp1ActionPerformed

    private void btnAppleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAppleActionPerformed
        addApple.setSize(550, 320);
        addApple.setVisible(true);
        Post.setVisible(false);
    }//GEN-LAST:event_btnAppleActionPerformed

    private void btnMSIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMSIActionPerformed
        addMSI.setSize(550, 320);
        addMSI.setVisible(true);
        Post.setVisible(false);
    }//GEN-LAST:event_btnMSIActionPerformed

    private void btnAddTovar4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddTovar4ActionPerformed
        addApple.setVisible(false);
        
        // проверка полей на правильность ввода
        Tovar el = new Tovar();
        el.setName(cmbName4.getSelectedItem().toString());
        el.setKol((int) spnKol4.getValue());
        el.setPrice(scrPrice2.getValue());
        
        try{
            doVivod2(tovarService.getTovarServicePort().setNewTovar(el));
        }catch (Exception ex) {
            ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Не удалось добавить. Попытайтесь повторить попытку :" + ex.getMessage() + ".",
                "Ошибка",
                JOptionPane.ERROR_MESSAGE);
        } 
    }                                           
    private void doVivod2(ListOfTovar lstTovar){
        doClearTable12();
        
        int i = 1;
        for(Tovar tovar: lstTovar.getItem()){
            Object[] rowData = new Object[5];
            rowData[0] = i++;
            rowData[1] = tovar.getName();
            rowData[2] = tovar.getPrice();
            rowData[3] = tovar.getKol();
            rowData[4] = tovar.getPrice() * tovar.getKol();
            model.addRow(rowData);
        }
    }    
    private void doClearTable12(){
        while (model.getRowCount()>0){
            model.removeRow(0);
        }                
    }//GEN-LAST:event_btnAddTovar4ActionPerformed

    private void btnCancel4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancel4ActionPerformed
        addApple.setVisible(false);
    }//GEN-LAST:event_btnCancel4ActionPerformed

    private void cmbName4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbName4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbName4ActionPerformed

    private void scrPrice2AdjustmentValueChanged(java.awt.event.AdjustmentEvent evt) {//GEN-FIRST:event_scrPrice2AdjustmentValueChanged
        lblPriceInfo2.setText(Integer.toString((int) scrPrice2.getValue())); 
    }//GEN-LAST:event_scrPrice2AdjustmentValueChanged

    private void btnAddTovar5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddTovar5ActionPerformed
        addMSI.setVisible(false);
        
        Tovar el = new Tovar();
        el.setName(cmbName5.getSelectedItem().toString());
        el.setKol((int) spnKol5.getValue());
        el.setPrice(scrPrice3.getValue());
        
        try{
            doVivod2(tovarService.getTovarServicePort().setNewTovar(el));
        }catch (Exception ex) {
            ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Не удалось добавить. Попытайтесь повторить попытку :" + ex.getMessage() + ".",
                "Ошибка",
                JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnAddTovar5ActionPerformed

    private void btnCancel5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancel5ActionPerformed
        addMSI.setVisible(false);// TODO add your handling code here:
    }//GEN-LAST:event_btnCancel5ActionPerformed

    private void cmbName5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbName5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbName5ActionPerformed

    private void scrPrice3AdjustmentValueChanged(java.awt.event.AdjustmentEvent evt) {//GEN-FIRST:event_scrPrice3AdjustmentValueChanged
        lblPriceInfo3.setText(Integer.toString((int) scrPrice3.getValue())); 
    }//GEN-LAST:event_scrPrice3AdjustmentValueChanged

    private void btnAddTovar6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddTovar6ActionPerformed
        addASUS.setVisible(false);
        Tovar el = new Tovar();
        el.setName(cmbName6.getSelectedItem().toString());
        el.setKol((int) spnKol6.getValue());
        el.setPrice(scrPrice4.getValue());
        
        try{
            doVivod2(tovarService.getTovarServicePort().setNewTovar(el));
        }catch (Exception ex) {
            ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Не удалось добавить. Попытайтесь повторить попытку :" + ex.getMessage() + ".",
                "Ошибка",
                JOptionPane.ERROR_MESSAGE);
        }
  
    }//GEN-LAST:event_btnAddTovar6ActionPerformed

    private void cmbName6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbName6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbName6ActionPerformed

    private void scrPrice4AdjustmentValueChanged(java.awt.event.AdjustmentEvent evt) {//GEN-FIRST:event_scrPrice4AdjustmentValueChanged
          lblPriceInfo4.setText(Integer.toString((int) scrPrice4.getValue())); // TODO add your handling code here:
    }//GEN-LAST:event_scrPrice4AdjustmentValueChanged

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        DefaultTableModel tblModel = (DefaultTableModel) tbl.getModel();
        if(tbl.getSelectedRowCount()==1){
        tblModel.removeRow(tbl.getSelectedRow());
    }
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnDelete1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelete1ActionPerformed
        DefaultTableModel tblModel2 = (DefaultTableModel) tbl2.getModel();
        if(tbl2.getSelectedRowCount()==1){
        tblModel2.removeRow(tbl2.getSelectedRow());}// TODO add your handling code here:
    }//GEN-LAST:event_btnDelete1ActionPerformed

    private void btnDelete2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelete2ActionPerformed
        DefaultTableModel tblModel1 = (DefaultTableModel) tbl1.getModel();
        if(tbl1.getSelectedRowCount()==1){
        tblModel1.removeRow(tbl1.getSelectedRow());}// TODO add your handling code here:
    }//GEN-LAST:event_btnDelete2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       Scores.setSize(500, 320);
       Scores.setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void ComputersWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_ComputersWindowOpened
         try {
            model = (DefaultTableModel)tbl.getModel(); 
            doVivod2(tovarService.getTovarServicePort().getAllTovar());
        } catch (Exception ex) {
            ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Не удалось установить соединение с сервером:" + ex.getMessage() + ".",
                "Ошибка",
                JOptionPane.ERROR_MESSAGE);

        }         
    }//GEN-LAST:event_ComputersWindowOpened

    private void tblAccWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_tblAccWindowOpened
         try {
            model2 = (DefaultTableModel)tbl2.getModel(); 
            doVivod3(accesuarsService.getAccesuarsServicePort().getAllAccesuars());
        } catch (Exception ex) {
            ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Не удалось установить соединение с сервером:" + ex.getMessage() + ".",
                "Ошибка",
                JOptionPane.ERROR_MESSAGE);

        }         
    }//GEN-LAST:event_tblAccWindowOpened

    private void tblForPCWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_tblForPCWindowOpened
         try {
            model1 = (DefaultTableModel)tbl1.getModel(); 
            doVivod1(forpcService.getForPCServicePort().getAllForPC());
        } catch (Exception ex) {
            ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Не удалось установить соединение с сервером:" + ex.getMessage() + ".",
                "Ошибка",
                JOptionPane.ERROR_MESSAGE);

        }         
    }//GEN-LAST:event_tblForPCWindowOpened

    private void btnCancel6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancel6ActionPerformed
        addASUS.setVisible(false);// TODO add your handling code here:
    }//GEN-LAST:event_btnCancel6ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDialog Computers;
    private javax.swing.JDialog Post;
    private javax.swing.JDialog Scores;
    private javax.swing.JDialog addASUS;
    private javax.swing.JDialog addAcc;
    private javax.swing.JDialog addApple;
    private javax.swing.JDialog addMSI;
    private javax.swing.JButton btnASUS;
    private javax.swing.JButton btnAcc;
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnAdd1;
    private javax.swing.JButton btnAdd2;
    private javax.swing.JButton btnAddTovar2;
    private javax.swing.JButton btnAddTovar3;
    private javax.swing.JButton btnAddTovar4;
    private javax.swing.JButton btnAddTovar5;
    private javax.swing.JButton btnAddTovar6;
    private javax.swing.JButton btnApple;
    private javax.swing.JButton btnCancel2;
    private javax.swing.JButton btnCancel3;
    private javax.swing.JButton btnCancel4;
    private javax.swing.JButton btnCancel5;
    private javax.swing.JButton btnCancel6;
    private javax.swing.JButton btnCancelComp;
    private javax.swing.JButton btnCancelComp1;
    private javax.swing.JButton btnCancelComp2;
    private javax.swing.JButton btnCancelP;
    private javax.swing.JButton btnDecide;
    private javax.swing.JButton btnDecide1;
    private javax.swing.JButton btnDecide2;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnDelete1;
    private javax.swing.JButton btnDelete2;
    private javax.swing.JButton btnExitMenu;
    private javax.swing.JButton btnForPC;
    private javax.swing.JButton btnMSI;
    private javax.swing.JComboBox cmbName2;
    private javax.swing.JComboBox cmbName3;
    private javax.swing.JComboBox cmbName4;
    private javax.swing.JComboBox cmbName5;
    private javax.swing.JComboBox cmbName6;
    private javax.swing.JButton doComputers;
    private javax.swing.JDialog forPC;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lbl;
    private javax.swing.JLabel lbl1;
    private javax.swing.JLabel lbl2;
    private javax.swing.JLabel lblKol2;
    private javax.swing.JLabel lblKol3;
    private javax.swing.JLabel lblKol4;
    private javax.swing.JLabel lblKol5;
    private javax.swing.JLabel lblKol6;
    private javax.swing.JLabel lblName2;
    private javax.swing.JLabel lblName3;
    private javax.swing.JLabel lblName4;
    private javax.swing.JLabel lblName5;
    private javax.swing.JLabel lblName6;
    private javax.swing.JLabel lblPrice;
    private javax.swing.JLabel lblPrice1;
    private javax.swing.JLabel lblPrice2;
    private javax.swing.JLabel lblPrice3;
    private javax.swing.JLabel lblPrice4;
    private javax.swing.JLabel lblPriceInfo;
    private javax.swing.JLabel lblPriceInfo1;
    private javax.swing.JLabel lblPriceInfo2;
    private javax.swing.JLabel lblPriceInfo3;
    private javax.swing.JLabel lblPriceInfo4;
    private javax.swing.JScrollBar scrPrice;
    private javax.swing.JScrollBar scrPrice1;
    private javax.swing.JScrollBar scrPrice2;
    private javax.swing.JScrollBar scrPrice3;
    private javax.swing.JScrollBar scrPrice4;
    private javax.swing.JSpinner spnKol2;
    private javax.swing.JSpinner spnKol3;
    private javax.swing.JSpinner spnKol4;
    private javax.swing.JSpinner spnKol5;
    private javax.swing.JSpinner spnKol6;
    private javax.swing.JToolBar.Separator spr1;
    private javax.swing.JToolBar.Separator spr2;
    private javax.swing.JToolBar.Separator spr3;
    private javax.swing.JToolBar.Separator spr4;
    private javax.swing.JToolBar.Separator spr5;
    private javax.swing.JToolBar.Separator spr6;
    private javax.swing.JToolBar.Separator spr7;
    private javax.swing.JToolBar.Separator spr8;
    private javax.swing.JToolBar.Separator spr9;
    private javax.swing.JTable tbl;
    private javax.swing.JTable tbl1;
    private javax.swing.JTable tbl2;
    private javax.swing.JDialog tblAcc;
    private javax.swing.JDialog tblForPC;
    private javax.swing.JToolBar tlBar;
    private javax.swing.JToolBar tlBar1;
    private javax.swing.JToolBar tlBar2;
    private javax.swing.JTextField txtTotalSumma;
    private javax.swing.JTextField txtTotalSumma1;
    private javax.swing.JTextField txtTotalSumma2;
    // End of variables declaration//GEN-END:variables
}
