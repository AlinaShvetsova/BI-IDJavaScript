
package types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for forPC complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="forPC">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="kolF" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="nameF" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="priceF" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "forPC", propOrder = {
    "kolF",
    "nameF",
    "priceF"
})
public class ForPC {

    protected int kolF;
    protected String nameF;
    protected double priceF;

    /**
     * Gets the value of the kolF property.
     * 
     */
    public int getKolF() {
        return kolF;
    }

    /**
     * Sets the value of the kolF property.
     * 
     */
    public void setKolF(int value) {
        this.kolF = value;
    }

    /**
     * Gets the value of the nameF property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNameF() {
        return nameF;
    }

    /**
     * Sets the value of the nameF property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNameF(String value) {
        this.nameF = value;
    }

    /**
     * Gets the value of the priceF property.
     * 
     */
    public double getPriceF() {
        return priceF;
    }

    /**
     * Sets the value of the priceF property.
     * 
     */
    public void setPriceF(double value) {
        this.priceF = value;
    }

}
