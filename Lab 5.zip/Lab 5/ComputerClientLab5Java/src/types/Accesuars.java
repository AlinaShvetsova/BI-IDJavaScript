
package types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;



@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "accesuars", propOrder = {
    "kolA",
    "nameA",
    "priceA"
})
public class Accesuars {

    protected int kolA;
    protected String nameA;
    protected double priceA;

    /**
     * Gets the value of the kolA property.
     * 
     */
    public int getKolA() {
        return kolA;
    }

    /**
     * Sets the value of the kolA property.
     * 
     */
    public void setKolA(int value) {
        this.kolA = value;
    }

    /**
     * Gets the value of the nameA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNameA() {
        return nameA;
    }

    /**
     * Sets the value of the nameA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNameA(String value) {
        this.nameA = value;
    }

    /**
     * Gets the value of the priceA property.
     * 
     */
    public double getPriceA() {
        return priceA;
    }

    /**
     * Sets the value of the priceA property.
     * 
     */
    public void setPriceA(double value) {
        this.priceA = value;
    }

}
