
package types;

import service.endpoint.*;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the service.endpoint package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetSumOfTovarFResponse_QNAME = new QName("http://endpoint.service/", "getSumOfTovarFResponse");
    private final static QName _GetAllForPC_QNAME = new QName("http://endpoint.service/", "getAllForPC");
    private final static QName _SetNewTovarFResponse_QNAME = new QName("http://endpoint.service/", "setNewTovarFResponse");
    private final static QName _SetNewTovarF_QNAME = new QName("http://endpoint.service/", "setNewTovarF");
    private final static QName _GetSumOfTovarF_QNAME = new QName("http://endpoint.service/", "getSumOfTovarF");
    private final static QName _GetAllForPCResponse_QNAME = new QName("http://endpoint.service/", "getAllForPCResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: service.endpoint
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetSumOfTovarFResponse }
     * 
     */
    public GetSumOfTovarFResponse createGetSumOfTovarFResponse() {
        return new GetSumOfTovarFResponse();
    }

    /**
     * Create an instance of {@link GetAllForPC }
     * 
     */
    public GetAllForPC createGetAllForPC() {
        return new GetAllForPC();
    }

    /**
     * Create an instance of {@link SetNewTovarFResponse }
     * 
     */
    public SetNewTovarFResponse createSetNewTovarFResponse() {
        return new SetNewTovarFResponse();
    }

    /**
     * Create an instance of {@link SetNewTovarF }
     * 
     */
    public SetNewTovarF createSetNewTovarF() {
        return new SetNewTovarF();
    }

    /**
     * Create an instance of {@link GetAllForPCResponse }
     * 
     */
    public GetAllForPCResponse createGetAllForPCResponse() {
        return new GetAllForPCResponse();
    }

    /**
     * Create an instance of {@link GetSumOfTovarF }
     * 
     */
    public GetSumOfTovarF createGetSumOfTovarF() {
        return new GetSumOfTovarF();
    }

    /**
     * Create an instance of {@link ForPC }
     * 
     */
    public ForPC createForPC() {
        return new ForPC();
    }

    /**
     * Create an instance of {@link ListOfForPC }
     * 
     */
    public ListOfForPC createListOfForPC() {
        return new ListOfForPC();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSumOfTovarFResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.service/", name = "getSumOfTovarFResponse")
    public JAXBElement<GetSumOfTovarFResponse> createGetSumOfTovarFResponse(GetSumOfTovarFResponse value) {
        return new JAXBElement<GetSumOfTovarFResponse>(_GetSumOfTovarFResponse_QNAME, GetSumOfTovarFResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllForPC }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.service/", name = "getAllForPC")
    public JAXBElement<GetAllForPC> createGetAllForPC(GetAllForPC value) {
        return new JAXBElement<GetAllForPC>(_GetAllForPC_QNAME, GetAllForPC.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetNewTovarFResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.service/", name = "setNewTovarFResponse")
    public JAXBElement<SetNewTovarFResponse> createSetNewTovarFResponse(SetNewTovarFResponse value) {
        return new JAXBElement<SetNewTovarFResponse>(_SetNewTovarFResponse_QNAME, SetNewTovarFResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetNewTovarF }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.service/", name = "setNewTovarF")
    public JAXBElement<SetNewTovarF> createSetNewTovarF(SetNewTovarF value) {
        return new JAXBElement<SetNewTovarF>(_SetNewTovarF_QNAME, SetNewTovarF.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSumOfTovarF }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.service/", name = "getSumOfTovarF")
    public JAXBElement<GetSumOfTovarF> createGetSumOfTovarF(GetSumOfTovarF value) {
        return new JAXBElement<GetSumOfTovarF>(_GetSumOfTovarF_QNAME, GetSumOfTovarF.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllForPCResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.service/", name = "getAllForPCResponse")
    public JAXBElement<GetAllForPCResponse> createGetAllForPCResponse(GetAllForPCResponse value) {
        return new JAXBElement<GetAllForPCResponse>(_GetAllForPCResponse_QNAME, GetAllForPCResponse.class, null, value);
    }

}
