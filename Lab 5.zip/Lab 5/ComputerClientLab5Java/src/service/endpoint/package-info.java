@javax.xml.bind.annotation.XmlSchema(namespace = "http://endpoint.service/")
package service.endpoint;
