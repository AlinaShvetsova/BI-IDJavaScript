﻿namespace Computer
{
    partial class addASUS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblKol = new System.Windows.Forms.Label();
            this.btnCancelAs = new System.Windows.Forms.Button();
            this.btnAddTovarAs = new System.Windows.Forms.Button();
            this.cmbNameAs = new System.Windows.Forms.ComboBox();
            this.lblName = new System.Windows.Forms.Label();
            this.scrPrice = new System.Windows.Forms.HScrollBar();
            this.lblPriceInfo = new System.Windows.Forms.Label();
            this.spnKol = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.spnKol)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(30, 104);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(33, 13);
            this.lblPrice.TabIndex = 28;
            this.lblPrice.Text = "Цена";
            // 
            // lblKol
            // 
            this.lblKol.AutoSize = true;
            this.lblKol.Location = new System.Drawing.Point(30, 63);
            this.lblKol.Name = "lblKol";
            this.lblKol.Size = new System.Drawing.Size(66, 13);
            this.lblKol.TabIndex = 26;
            this.lblKol.Text = "Количество";
            // 
            // btnCancelAs
            // 
            this.btnCancelAs.Location = new System.Drawing.Point(226, 152);
            this.btnCancelAs.Name = "btnCancelAs";
            this.btnCancelAs.Size = new System.Drawing.Size(75, 23);
            this.btnCancelAs.TabIndex = 25;
            this.btnCancelAs.Text = "Отмена";
            this.btnCancelAs.UseVisualStyleBackColor = true;
            this.btnCancelAs.Click += new System.EventHandler(this.btnCancelAs_Click);
            // 
            // btnAddTovarAs
            // 
            this.btnAddTovarAs.Location = new System.Drawing.Point(60, 152);
            this.btnAddTovarAs.Name = "btnAddTovarAs";
            this.btnAddTovarAs.Size = new System.Drawing.Size(75, 23);
            this.btnAddTovarAs.TabIndex = 24;
            this.btnAddTovarAs.Text = "Добавить";
            this.btnAddTovarAs.UseVisualStyleBackColor = true;
            this.btnAddTovarAs.Click += new System.EventHandler(this.btnAddTovarAs_Click);
            // 
            // cmbNameAs
            // 
            this.cmbNameAs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNameAs.Items.AddRange(new object[] {
            "Тетрадь",
            "Ручка",
            "Карандаш"});
            this.cmbNameAs.Location = new System.Drawing.Point(124, 14);
            this.cmbNameAs.Name = "cmbNameAs";
            this.cmbNameAs.Size = new System.Drawing.Size(121, 21);
            this.cmbNameAs.TabIndex = 21;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(30, 22);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(83, 13);
            this.lblName.TabIndex = 20;
            this.lblName.Text = "Наименование";
            // 
            // scrPrice
            // 
            this.scrPrice.Location = new System.Drawing.Point(124, 104);
            this.scrPrice.Maximum = 500000;
            this.scrPrice.Minimum = 10000;
            this.scrPrice.Name = "scrPrice";
            this.scrPrice.Size = new System.Drawing.Size(161, 17);
            this.scrPrice.TabIndex = 31;
            this.scrPrice.Value = 10000;
            this.scrPrice.Scroll += new System.Windows.Forms.ScrollEventHandler(this.scrPrice_Scroll);
            // 
            // lblPriceInfo
            // 
            this.lblPriceInfo.AutoSize = true;
            this.lblPriceInfo.Location = new System.Drawing.Point(182, 91);
            this.lblPriceInfo.Name = "lblPriceInfo";
            this.lblPriceInfo.Size = new System.Drawing.Size(43, 13);
            this.lblPriceInfo.TabIndex = 30;
            this.lblPriceInfo.Text = "500000";
            // 
            // spnKol
            // 
            this.spnKol.Location = new System.Drawing.Point(124, 56);
            this.spnKol.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.spnKol.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.spnKol.Name = "spnKol";
            this.spnKol.Size = new System.Drawing.Size(120, 20);
            this.spnKol.TabIndex = 29;
            this.spnKol.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // addASUS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(370, 204);
            this.Controls.Add(this.scrPrice);
            this.Controls.Add(this.lblPriceInfo);
            this.Controls.Add(this.spnKol);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblKol);
            this.Controls.Add(this.btnCancelAs);
            this.Controls.Add(this.btnAddTovarAs);
            this.Controls.Add(this.cmbNameAs);
            this.Controls.Add(this.lblName);
            this.Name = "addASUS";
            this.Text = "addASUS";
            this.Load += new System.EventHandler(this.addASUS_Load);
            ((System.ComponentModel.ISupportInitialize)(this.spnKol)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblKol;
        private System.Windows.Forms.Button btnCancelAs;
        private System.Windows.Forms.Button btnAddTovarAs;
        private System.Windows.Forms.ComboBox cmbNameAs;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.HScrollBar scrPrice;
        private System.Windows.Forms.Label lblPriceInfo;
        private System.Windows.Forms.NumericUpDown spnKol;
    }
}