﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using serverComp;

namespace Computer
{
    public partial class addForPC : Form
    {
        ServiceReference1.ForPCServiceClient forpc = new ServiceReference1.ForPCServiceClient();
        public addForPC()
        {
            InitializeComponent();
        }
        

        private void btnAddTovarF_Click(object sender, EventArgs e)
        {
            ServiceReference1.forPC el = new ServiceReference1.forPC();
            el.nameF = cmbNameF.Text;
            el.kolF = Convert.ToInt32(spnKolF.Value);

            el.priceF = Convert.ToInt32(scrPriceF.Value) * Convert.ToInt32(spnKolF.Value);

            AccesuarsTbl f = new AccesuarsTbl();
            forpc.setNewTovarF(el);
            f.doVivodA();
            this.Close();
        }

        private void addForPC_Load(object sender, EventArgs e)
        {
            cmbNameF.SelectedIndex = 0;
        }

        private void btnCancelF_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void scrPriceF_Scroll(object sender, ScrollEventArgs e)
        {
            lblPriceInfoAc.Text = scrPriceF.Value.ToString();
        }
    }
}