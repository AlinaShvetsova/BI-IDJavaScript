﻿namespace Computer
{
    partial class addApple
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.scrPrice = new System.Windows.Forms.HScrollBar();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblPriceInfo = new System.Windows.Forms.Label();
            this.lblKol = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnAddTovar = new System.Windows.Forms.Button();
            this.spnKol = new System.Windows.Forms.NumericUpDown();
            this.cmbName = new System.Windows.Forms.ComboBox();
            this.lblName = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.spnKol)).BeginInit();
            this.SuspendLayout();
            // 
            // scrPrice
            // 
            this.scrPrice.Location = new System.Drawing.Point(117, 113);
            this.scrPrice.Maximum = 500000;
            this.scrPrice.Minimum = 10000;
            this.scrPrice.Name = "scrPrice";
            this.scrPrice.Size = new System.Drawing.Size(161, 17);
            this.scrPrice.TabIndex = 19;
            this.scrPrice.Value = 10000;
            this.scrPrice.Scroll += new System.Windows.Forms.ScrollEventHandler(this.scrPrice_Scroll);
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(22, 113);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(33, 13);
            this.lblPrice.TabIndex = 18;
            this.lblPrice.Text = "Цена";
            // 
            // lblPriceInfo
            // 
            this.lblPriceInfo.AutoSize = true;
            this.lblPriceInfo.Location = new System.Drawing.Point(175, 100);
            this.lblPriceInfo.Name = "lblPriceInfo";
            this.lblPriceInfo.Size = new System.Drawing.Size(43, 13);
            this.lblPriceInfo.TabIndex = 17;
            this.lblPriceInfo.Text = "500000";
            // 
            // lblKol
            // 
            this.lblKol.AutoSize = true;
            this.lblKol.Location = new System.Drawing.Point(22, 72);
            this.lblKol.Name = "lblKol";
            this.lblKol.Size = new System.Drawing.Size(66, 13);
            this.lblKol.TabIndex = 16;
            this.lblKol.Text = "Количество";
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(219, 166);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 15;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnAddTovar
            // 
            this.btnAddTovar.Location = new System.Drawing.Point(53, 166);
            this.btnAddTovar.Name = "btnAddTovar";
            this.btnAddTovar.Size = new System.Drawing.Size(75, 23);
            this.btnAddTovar.TabIndex = 14;
            this.btnAddTovar.Text = "Добавить";
            this.btnAddTovar.UseVisualStyleBackColor = true;
            this.btnAddTovar.Click += new System.EventHandler(this.btnAddTovar_Click);
            // 
            // spnKol
            // 
            this.spnKol.Location = new System.Drawing.Point(117, 65);
            this.spnKol.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.spnKol.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.spnKol.Name = "spnKol";
            this.spnKol.Size = new System.Drawing.Size(120, 20);
            this.spnKol.TabIndex = 12;
            this.spnKol.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // cmbName
            // 
            this.cmbName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbName.Items.AddRange(new object[] {
            "Товар 1",
            "товар 2",
            "Товар 3"});
            this.cmbName.Location = new System.Drawing.Point(116, 23);
            this.cmbName.Name = "cmbName";
            this.cmbName.Size = new System.Drawing.Size(121, 21);
            this.cmbName.TabIndex = 11;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(22, 31);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(83, 13);
            this.lblName.TabIndex = 10;
            this.lblName.Text = "Наименование";
            // 
            // addApple
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(357, 212);
            this.Controls.Add(this.scrPrice);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblPriceInfo);
            this.Controls.Add(this.lblKol);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnAddTovar);
            this.Controls.Add(this.spnKol);
            this.Controls.Add(this.cmbName);
            this.Controls.Add(this.lblName);
            this.Name = "addApple";
            this.Text = "addComputer";
            this.Load += new System.EventHandler(this.addApple_Load);
            ((System.ComponentModel.ISupportInitialize)(this.spnKol)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.HScrollBar scrPrice;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblPriceInfo;
        private System.Windows.Forms.Label lblKol;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnAddTovar;
        private System.Windows.Forms.NumericUpDown spnKol;
        private System.Windows.Forms.ComboBox cmbName;
        private System.Windows.Forms.Label lblName;
    }
}