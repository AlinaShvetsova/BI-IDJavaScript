﻿namespace Computer
{
    partial class Post
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancelPost = new System.Windows.Forms.Button();
            this.btnMSI = new System.Windows.Forms.Button();
            this.btnASUS = new System.Windows.Forms.Button();
            this.btnApple = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCancelPost
            // 
            this.btnCancelPost.Location = new System.Drawing.Point(60, 182);
            this.btnCancelPost.Name = "btnCancelPost";
            this.btnCancelPost.Size = new System.Drawing.Size(75, 23);
            this.btnCancelPost.TabIndex = 7;
            this.btnCancelPost.Text = "Назад";
            this.btnCancelPost.UseVisualStyleBackColor = true;
            this.btnCancelPost.Click += new System.EventHandler(this.btnCancelPost_Click);
            // 
            // btnMSI
            // 
            this.btnMSI.Location = new System.Drawing.Point(60, 135);
            this.btnMSI.Name = "btnMSI";
            this.btnMSI.Size = new System.Drawing.Size(75, 23);
            this.btnMSI.TabIndex = 6;
            this.btnMSI.Text = "MSI";
            this.btnMSI.UseVisualStyleBackColor = true;
            this.btnMSI.Click += new System.EventHandler(this.btnMSI_Click);
            // 
            // btnASUS
            // 
            this.btnASUS.Location = new System.Drawing.Point(60, 83);
            this.btnASUS.Name = "btnASUS";
            this.btnASUS.Size = new System.Drawing.Size(75, 23);
            this.btnASUS.TabIndex = 5;
            this.btnASUS.Text = "ASUS";
            this.btnASUS.UseVisualStyleBackColor = true;
            this.btnASUS.Click += new System.EventHandler(this.btnASUS_Click);
            // 
            // btnApple
            // 
            this.btnApple.Location = new System.Drawing.Point(60, 38);
            this.btnApple.Name = "btnApple";
            this.btnApple.Size = new System.Drawing.Size(75, 23);
            this.btnApple.TabIndex = 4;
            this.btnApple.Text = "Apple";
            this.btnApple.UseVisualStyleBackColor = true;
            this.btnApple.Click += new System.EventHandler(this.btnApple_Click);
            // 
            // Post
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(198, 256);
            this.Controls.Add(this.btnCancelPost);
            this.Controls.Add(this.btnMSI);
            this.Controls.Add(this.btnASUS);
            this.Controls.Add(this.btnApple);
            this.Name = "Post";
            this.Text = "Post";
            this.Load += new System.EventHandler(this.Post_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCancelPost;
        private System.Windows.Forms.Button btnMSI;
        private System.Windows.Forms.Button btnASUS;
        private System.Windows.Forms.Button btnApple;
    }
}