﻿namespace Computer
{
    partial class addAcc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.scrPriceA = new System.Windows.Forms.HScrollBar();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblPriceInfoAc = new System.Windows.Forms.Label();
            this.lblKol = new System.Windows.Forms.Label();
            this.btnCancelA = new System.Windows.Forms.Button();
            this.btnAddTovarA = new System.Windows.Forms.Button();
            this.spnKolA = new System.Windows.Forms.NumericUpDown();
            this.cmbNameA = new System.Windows.Forms.ComboBox();
            this.lblName = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.spnKolA)).BeginInit();
            this.SuspendLayout();
            // 
            // scrPriceA
            // 
            this.scrPriceA.Location = new System.Drawing.Point(146, 118);
            this.scrPriceA.Maximum = 500000;
            this.scrPriceA.Minimum = 40000;
            this.scrPriceA.Name = "scrPriceA";
            this.scrPriceA.Size = new System.Drawing.Size(120, 17);
            this.scrPriceA.TabIndex = 29;
            this.scrPriceA.Value = 40000;
            this.scrPriceA.Scroll += new System.Windows.Forms.ScrollEventHandler(this.scrPriceA_Scroll);
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(51, 118);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(33, 13);
            this.lblPrice.TabIndex = 28;
            this.lblPrice.Text = "Цена";
            // 
            // lblPriceInfoAc
            // 
            this.lblPriceInfoAc.AutoSize = true;
            this.lblPriceInfoAc.Location = new System.Drawing.Point(187, 105);
            this.lblPriceInfoAc.Name = "lblPriceInfoAc";
            this.lblPriceInfoAc.Size = new System.Drawing.Size(43, 13);
            this.lblPriceInfoAc.TabIndex = 27;
            this.lblPriceInfoAc.Text = "500000";
            // 
            // lblKol
            // 
            this.lblKol.AutoSize = true;
            this.lblKol.Location = new System.Drawing.Point(51, 77);
            this.lblKol.Name = "lblKol";
            this.lblKol.Size = new System.Drawing.Size(66, 13);
            this.lblKol.TabIndex = 26;
            this.lblKol.Text = "Количество";
            // 
            // btnCancelA
            // 
            this.btnCancelA.Location = new System.Drawing.Point(255, 176);
            this.btnCancelA.Name = "btnCancelA";
            this.btnCancelA.Size = new System.Drawing.Size(75, 23);
            this.btnCancelA.TabIndex = 25;
            this.btnCancelA.Text = "Отмена";
            this.btnCancelA.UseVisualStyleBackColor = true;
            // 
            // btnAddTovarA
            // 
            this.btnAddTovarA.Location = new System.Drawing.Point(89, 176);
            this.btnAddTovarA.Name = "btnAddTovarA";
            this.btnAddTovarA.Size = new System.Drawing.Size(75, 23);
            this.btnAddTovarA.TabIndex = 24;
            this.btnAddTovarA.Text = "Добавить";
            this.btnAddTovarA.UseVisualStyleBackColor = true;
            this.btnAddTovarA.Click += new System.EventHandler(this.btnAddTovarA_Click);
            // 
            // spnKolA
            // 
            this.spnKolA.Location = new System.Drawing.Point(146, 70);
            this.spnKolA.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.spnKolA.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.spnKolA.Name = "spnKolA";
            this.spnKolA.Size = new System.Drawing.Size(120, 20);
            this.spnKolA.TabIndex = 22;
            this.spnKolA.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // cmbNameA
            // 
            this.cmbNameA.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNameA.Items.AddRange(new object[] {
            "Товар 1",
            "Товар 2",
            "Товар 3"});
            this.cmbNameA.Location = new System.Drawing.Point(145, 28);
            this.cmbNameA.Name = "cmbNameA";
            this.cmbNameA.Size = new System.Drawing.Size(121, 21);
            this.cmbNameA.TabIndex = 21;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(51, 36);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(83, 13);
            this.lblName.TabIndex = 20;
            this.lblName.Text = "Наименование";
            // 
            // addAcc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(395, 222);
            this.Controls.Add(this.scrPriceA);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblPriceInfoAc);
            this.Controls.Add(this.lblKol);
            this.Controls.Add(this.btnCancelA);
            this.Controls.Add(this.btnAddTovarA);
            this.Controls.Add(this.spnKolA);
            this.Controls.Add(this.cmbNameA);
            this.Controls.Add(this.lblName);
            this.Name = "addAcc";
            this.Text = "addAcc";
            this.Load += new System.EventHandler(this.addAcc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.spnKolA)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.HScrollBar scrPriceA;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblPriceInfoAc;
        private System.Windows.Forms.Label lblKol;
        private System.Windows.Forms.Button btnCancelA;
        private System.Windows.Forms.Button btnAddTovarA;
        private System.Windows.Forms.NumericUpDown spnKolA;
        private System.Windows.Forms.ComboBox cmbNameA;
        private System.Windows.Forms.Label lblName;
    }
}