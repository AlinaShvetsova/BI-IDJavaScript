﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using serverComp;

namespace Computer
{
    public partial class AccesuarsTbl : Form
    {
        public AccesuarsTbl()
        {
            InitializeComponent();
        }
        ServiceReference4.AccesuarsServiceClient service = new ServiceReference4.AccesuarsServiceClient();
        ServiceReference4.accesuars[] arrAccesuars;

        public void doVivodA()
        {
            arrAccesuars = service.getAllTovarA();

            dataGridView1.Rows.Clear();

            foreach (ServiceReference4.accesuars el in arrAccesuars)
            {
                object[] buffer = new object[4];

                buffer[0] = el.nameA;
                buffer[1] = el.priceA;
                buffer[2] = el.kolA;
                buffer[3] = el.priceA * el.kolA;

                dataGridView1.Rows.Add(buffer);
            }
        }

        private void btnCancelA_Click(object sender, EventArgs e)
        {
            this.Hide();
            Menu m = new Menu();
            m.Show();
        }

        private void btnUpdateA_Click(object sender, EventArgs e)
        {
            try
            {
                doVivodA();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelA_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 1)
            {
                MessageBox.Show(this, "Выберите элемент для удаления!", "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                try
                {
                    service.setDelTovarA(dataGridView1.CurrentRow.Index);
                    doVivodA();
                    
                    if (lbl.Text != "")
                        btnDecideA_Click(sender, e);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnAddA_Click(object sender, EventArgs e)
        {
            addAcc p = new addAcc();
            p.ShowDialog();
            try
            {
                doVivodA();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            
        }

        private void btnDecideA_Click(object sender, EventArgs e)
        {
            try
            {
                txtA.Text = service.getSumOfTovarA().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AccesuarsTbl_Load(object sender, EventArgs e)
        {
            try
            {
                doVivodA();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
