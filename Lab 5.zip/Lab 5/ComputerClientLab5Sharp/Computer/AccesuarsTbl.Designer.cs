﻿namespace Computer
{
    partial class AccesuarsTbl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtA = new System.Windows.Forms.TextBox();
            this.lbl = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.btnAddA = new System.Windows.Forms.ToolStripMenuItem();
            this.btnDecideA = new System.Windows.Forms.ToolStripMenuItem();
            this.btnDelA = new System.Windows.Forms.ToolStripMenuItem();
            this.btnUpdateA = new System.Windows.Forms.ToolStripMenuItem();
            this.btnCancelA = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(166, 223);
            this.txtA.Name = "txtA";
            this.txtA.ReadOnly = true;
            this.txtA.Size = new System.Drawing.Size(100, 20);
            this.txtA.TabIndex = 10;
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.Location = new System.Drawing.Point(44, 226);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(116, 13);
            this.lbl.TabIndex = 9;
            this.lbl.Text = "Общая сумма товара";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.btnAddA,
            this.btnDecideA,
            this.btnDelA,
            this.btnUpdateA,
            this.btnCancelA});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(470, 24);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(12, 20);
            // 
            // btnAddA
            // 
            this.btnAddA.Name = "btnAddA";
            this.btnAddA.Size = new System.Drawing.Size(71, 20);
            this.btnAddA.Text = "Добавить";
            this.btnAddA.Click += new System.EventHandler(this.btnAddA_Click);
            // 
            // btnDecideA
            // 
            this.btnDecideA.Name = "btnDecideA";
            this.btnDecideA.Size = new System.Drawing.Size(80, 20);
            this.btnDecideA.Text = "Вычислить";
            this.btnDecideA.Click += new System.EventHandler(this.btnDecideA_Click);
            // 
            // btnDelA
            // 
            this.btnDelA.Name = "btnDelA";
            this.btnDelA.Size = new System.Drawing.Size(63, 20);
            this.btnDelA.Text = "Удалить";
            this.btnDelA.Click += new System.EventHandler(this.btnDelA_Click);
            // 
            // btnUpdateA
            // 
            this.btnUpdateA.Name = "btnUpdateA";
            this.btnUpdateA.Size = new System.Drawing.Size(73, 20);
            this.btnUpdateA.Text = "Обновить";
            this.btnUpdateA.Click += new System.EventHandler(this.btnUpdateA_Click);
            // 
            // btnCancelA
            // 
            this.btnCancelA.Name = "btnCancelA";
            this.btnCancelA.Size = new System.Drawing.Size(51, 20);
            this.btnCancelA.Text = "Назад";
            this.btnCancelA.Click += new System.EventHandler(this.btnCancelA_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4});
            this.dataGridView1.Location = new System.Drawing.Point(12, 37);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(444, 171);
            this.dataGridView1.TabIndex = 11;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Название";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Цена";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Количество";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Сумма";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // AccesuarsTbl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(470, 271);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txtA);
            this.Controls.Add(this.lbl);
            this.Controls.Add(this.menuStrip1);
            this.Name = "AccesuarsTbl";
            this.Text = "AccesuarsTbl";
            this.Load += new System.EventHandler(this.AccesuarsTbl_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem btnAddA;
        private System.Windows.Forms.ToolStripMenuItem btnDecideA;
        private System.Windows.Forms.ToolStripMenuItem btnDelA;
        private System.Windows.Forms.ToolStripMenuItem btnUpdateA;
        private System.Windows.Forms.ToolStripMenuItem btnCancelA;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
    }
}