﻿namespace Computer
{
    partial class addMSI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblKol = new System.Windows.Forms.Label();
            this.btnCancelMs = new System.Windows.Forms.Button();
            this.btnAddTovarMs = new System.Windows.Forms.Button();
            this.lblName = new System.Windows.Forms.Label();
            this.scrPrice = new System.Windows.Forms.HScrollBar();
            this.lblPriceInfo = new System.Windows.Forms.Label();
            this.spnKol = new System.Windows.Forms.NumericUpDown();
            this.cmbNameAs = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.spnKol)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(44, 116);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(33, 13);
            this.lblPrice.TabIndex = 38;
            this.lblPrice.Text = "Цена";
            // 
            // lblKol
            // 
            this.lblKol.AutoSize = true;
            this.lblKol.Location = new System.Drawing.Point(44, 75);
            this.lblKol.Name = "lblKol";
            this.lblKol.Size = new System.Drawing.Size(66, 13);
            this.lblKol.TabIndex = 36;
            this.lblKol.Text = "Количество";
            // 
            // btnCancelMs
            // 
            this.btnCancelMs.Location = new System.Drawing.Point(244, 171);
            this.btnCancelMs.Name = "btnCancelMs";
            this.btnCancelMs.Size = new System.Drawing.Size(75, 23);
            this.btnCancelMs.TabIndex = 35;
            this.btnCancelMs.Text = "Отмена";
            this.btnCancelMs.UseVisualStyleBackColor = true;
            this.btnCancelMs.Click += new System.EventHandler(this.btnCancelMs_Click);
            // 
            // btnAddTovarMs
            // 
            this.btnAddTovarMs.Location = new System.Drawing.Point(78, 171);
            this.btnAddTovarMs.Name = "btnAddTovarMs";
            this.btnAddTovarMs.Size = new System.Drawing.Size(75, 23);
            this.btnAddTovarMs.TabIndex = 34;
            this.btnAddTovarMs.Text = "Добавить";
            this.btnAddTovarMs.UseVisualStyleBackColor = true;
            this.btnAddTovarMs.Click += new System.EventHandler(this.btnAddTovarMs_Click);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(44, 34);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(83, 13);
            this.lblName.TabIndex = 30;
            this.lblName.Text = "Наименование";
            // 
            // scrPrice
            // 
            this.scrPrice.Location = new System.Drawing.Point(133, 121);
            this.scrPrice.Maximum = 500000;
            this.scrPrice.Minimum = 10000;
            this.scrPrice.Name = "scrPrice";
            this.scrPrice.Size = new System.Drawing.Size(161, 17);
            this.scrPrice.TabIndex = 42;
            this.scrPrice.Value = 10000;
            // 
            // lblPriceInfo
            // 
            this.lblPriceInfo.AutoSize = true;
            this.lblPriceInfo.Location = new System.Drawing.Point(191, 108);
            this.lblPriceInfo.Name = "lblPriceInfo";
            this.lblPriceInfo.Size = new System.Drawing.Size(43, 13);
            this.lblPriceInfo.TabIndex = 41;
            this.lblPriceInfo.Text = "500000";
            // 
            // spnKol
            // 
            this.spnKol.Location = new System.Drawing.Point(133, 73);
            this.spnKol.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.spnKol.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.spnKol.Name = "spnKol";
            this.spnKol.Size = new System.Drawing.Size(120, 20);
            this.spnKol.TabIndex = 40;
            this.spnKol.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // cmbNameAs
            // 
            this.cmbNameAs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNameAs.Items.AddRange(new object[] {
            "Тетрадь",
            "Ручка",
            "Карандаш"});
            this.cmbNameAs.Location = new System.Drawing.Point(133, 31);
            this.cmbNameAs.Name = "cmbNameAs";
            this.cmbNameAs.Size = new System.Drawing.Size(121, 21);
            this.cmbNameAs.TabIndex = 39;
            // 
            // addMSI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(380, 220);
            this.Controls.Add(this.scrPrice);
            this.Controls.Add(this.lblPriceInfo);
            this.Controls.Add(this.spnKol);
            this.Controls.Add(this.cmbNameAs);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblKol);
            this.Controls.Add(this.btnCancelMs);
            this.Controls.Add(this.btnAddTovarMs);
            this.Controls.Add(this.lblName);
            this.Name = "addMSI";
            this.Text = "addMSI";
            this.Load += new System.EventHandler(this.addMSI_Load);
            ((System.ComponentModel.ISupportInitialize)(this.spnKol)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblKol;
        private System.Windows.Forms.Button btnCancelMs;
        private System.Windows.Forms.Button btnAddTovarMs;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.HScrollBar scrPrice;
        private System.Windows.Forms.Label lblPriceInfo;
        private System.Windows.Forms.NumericUpDown spnKol;
        private System.Windows.Forms.ComboBox cmbNameAs;
    }
}