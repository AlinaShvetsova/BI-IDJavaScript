﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using serverComp;

namespace Computer
{
    public partial class ComputersTbl : Form
    {
        public ComputersTbl()
        {
            InitializeComponent();
        }

        ServiceReference2.TovarServiceClient service = new ServiceReference2.TovarServiceClient();
        ServiceReference2.tovar[] arrTovar;

        public void doVivod()
        {
            arrTovar = service.getAllTovar();

            dataGridView1.Rows.Clear();

            foreach (ServiceReference2.tovar el in arrTovar)
            {
                object[] buffer = new object[4];

                buffer[0] = el.name;
                buffer[1] = el.price;
                buffer[2] = el.kol;
                buffer[3] = el.price * el.kol;

                dataGridView1.Rows.Add(buffer);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Post p = new Post();
            p.ShowDialog();

            try
            {
                doVivod();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void ComputersTbl_Load(object sender, EventArgs e)
        {
            try
            {
                doVivod();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDecide_Click(object sender, EventArgs e)
        {
            try
            {
                txt.Text = service.getSumOfTovar().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
           
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 1)
            {
                MessageBox.Show(this, "Выберите элемент для удаления!", "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                try
                {
                    service.setDelTovar(dataGridView1.CurrentRow.Index);
                    doVivod();

                    if (lbl.Text != "")
                        btnDecide_Click(sender, e);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                doVivod();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancelC_Click(object sender, EventArgs e)
        {
            this.Hide();
            Menu m = new Menu();
            m.Show();
        }
    }
}
