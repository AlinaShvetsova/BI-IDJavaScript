﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using serverComp;

namespace Computer
{
    public partial class addMSI : Form
    {
        ServiceReference2.TovarServiceClient service = new ServiceReference2.TovarServiceClient();
        public addMSI()
        {
            InitializeComponent();
        }

        private void btnCancelMs_Click(object sender, EventArgs e)
        {
            Post p = new Post();
            p.ShowDialog();
        }
        public addMSI(TovarOperation tovarOperation)
        {
            InitializeComponent();
            this.tovarOperation = tovarOperation;
        }
        TovarOperation tovarOperation = null;

        private void btnAddTovarMs_Click(object sender, EventArgs e)
        {

            ServiceReference2.tovar el = new ServiceReference2.tovar();
            el.name = cmbNameAs.Text;
            el.kol = Convert.ToInt32(spnKol.Value);
            el.price = Convert.ToInt32(scrPrice.Value) * Convert.ToInt32(spnKol.Value);

            ComputersTbl f = new ComputersTbl();
            service.setNewTovar(el);
            f.doVivod();
            this.Close();
        }

        private void addMSI_Load(object sender, EventArgs e)
        {
            cmbNameAs.SelectedIndex = 0;
        }
    }
}
