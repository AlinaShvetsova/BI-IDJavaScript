﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using serverComp;

namespace Computer
{
    public partial class ForPCTbl : Form
    {
        public ForPCTbl()
        {
            InitializeComponent();
        }
        ServiceReference1.ForPCServiceClient service = new ServiceReference1.ForPCServiceClient();
        ServiceReference1.forPC[] arrForPC;

        public void doVivodF()
        {
            arrForPC = service.getAllTovarF();

            dataGridView1.Rows.Clear();

            foreach (ServiceReference1.forPC el in arrForPC)
            {
                object[] buffer = new object[4];

                buffer[0] = el.nameF;
                buffer[1] = el.priceF;
                buffer[2] = el.kolF;
                buffer[3] = el.priceF * el.kolF;

                dataGridView1.Rows.Add(buffer);
            }

        }

        private void ForPCTbl_Load(object sender, EventArgs e)
        {
            try
            {
                doVivodF();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAddF_Click(object sender, EventArgs e)
        {
            addForPC p = new addForPC();
            p.ShowDialog();
           
            try
            {
                doVivodF();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDecideF_Click(object sender, EventArgs e)
        {
            try
            {
                txtF.Text = service.getSumOfTovarF().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelF_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 1)
            {
                MessageBox.Show(this, "Выберите элемент для удаления!", "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                try
                {
                    service.setDelTovarF(dataGridView1.CurrentRow.Index);
                    doVivodF();

                    if (lbl.Text != "")
                        btnDecideF_Click(sender, e);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnUpdateF_Click(object sender, EventArgs e)
        {
            try
            {
                doVivodF();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancelF_Click(object sender, EventArgs e)
        {
            this.Hide();
            Menu m = new Menu();
            m.Show();
        }
    }
}
