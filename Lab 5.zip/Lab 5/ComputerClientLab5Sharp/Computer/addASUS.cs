﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using serverComp;


namespace Computer
{
    public partial class addASUS : Form
    {
        ServiceReference2.TovarServiceClient accesuars = new ServiceReference2.TovarServiceClient();
        public addASUS()
        {
            InitializeComponent();
        }

        
        private void btnCancelAs_Click(object sender, EventArgs e)
        {
            
            Post p = new Post();
            p.ShowDialog();
        }

        private void btnAddTovarAs_Click(object sender, EventArgs e)
        {

            ServiceReference2.tovar el = new ServiceReference2.tovar();
            el.name = cmbNameAs.Text;
            el.kol = Convert.ToInt32(spnKol.Value);

            el.price = Convert.ToInt32(scrPrice.Value) * Convert.ToInt32(spnKol.Value);

            AccesuarsTbl f = new AccesuarsTbl();
            accesuars.setNewTovar(el);
            f.doVivodA();
            this.Close();
        }

        private void addASUS_Load(object sender, EventArgs e)
        {
            cmbNameAs.SelectedIndex = 0;
        }

        private void scrPrice_Scroll(object sender, ScrollEventArgs e)
        {
            lblPriceInfo.Text = scrPrice.Value.ToString();
        }

        
    }
}
