﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using serverComp;

namespace Computer
{
    public partial class addAcc : Form
    {
        ServiceReference4.AccesuarsServiceClient accesuars = new ServiceReference4.AccesuarsServiceClient();
        public addAcc()
        {
            InitializeComponent();
        }
        
        private void btnAddTovarA_Click(object sender, EventArgs e)
        {
            
            ServiceReference4.accesuars el = new ServiceReference4.accesuars();
            el.nameA = cmbNameA.Text;
            el.kolA = Convert.ToInt32(spnKolA.Value);
            //el.priceA = Convert.ToInt32(scrPriceA.Text);
            el.priceA = Convert.ToInt32(scrPriceA.Value) * Convert.ToInt32(spnKolA.Value);

            AccesuarsTbl f = new AccesuarsTbl();
            accesuars.setNewTovarA(el);
            f.doVivodA();
            this.Close();
        }

        private void addAcc_Load(object sender, EventArgs e)
        {
            cmbNameA.SelectedIndex = 0;
        }

        private void scrPriceA_Scroll(object sender, ScrollEventArgs e)
        {
            lblPriceInfoAc.Text = scrPriceA.Value.ToString();
        }
    }
}
