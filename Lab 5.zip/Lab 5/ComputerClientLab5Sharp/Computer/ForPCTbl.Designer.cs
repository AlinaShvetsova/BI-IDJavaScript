﻿namespace Computer
{
    partial class ForPCTbl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtF = new System.Windows.Forms.TextBox();
            this.lbl = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.btnAddF = new System.Windows.Forms.ToolStripMenuItem();
            this.btnDecideF = new System.Windows.Forms.ToolStripMenuItem();
            this.btnDelF = new System.Windows.Forms.ToolStripMenuItem();
            this.btnUpdateF = new System.Windows.Forms.ToolStripMenuItem();
            this.btnCancelF = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtF
            // 
            this.txtF.Location = new System.Drawing.Point(187, 221);
            this.txtF.Name = "txtF";
            this.txtF.ReadOnly = true;
            this.txtF.Size = new System.Drawing.Size(100, 20);
            this.txtF.TabIndex = 10;
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.Location = new System.Drawing.Point(65, 224);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(116, 13);
            this.lbl.TabIndex = 9;
            this.lbl.Text = "Общая сумма товара";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.btnAddF,
            this.btnDecideF,
            this.btnDelF,
            this.btnUpdateF,
            this.btnCancelF});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(470, 24);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(12, 20);
            // 
            // btnAddF
            // 
            this.btnAddF.Name = "btnAddF";
            this.btnAddF.Size = new System.Drawing.Size(71, 20);
            this.btnAddF.Text = "Добавить";
            this.btnAddF.Click += new System.EventHandler(this.btnAddF_Click);
            // 
            // btnDecideF
            // 
            this.btnDecideF.Name = "btnDecideF";
            this.btnDecideF.Size = new System.Drawing.Size(80, 20);
            this.btnDecideF.Text = "Вычислить";
            this.btnDecideF.Click += new System.EventHandler(this.btnDecideF_Click);
            // 
            // btnDelF
            // 
            this.btnDelF.Name = "btnDelF";
            this.btnDelF.Size = new System.Drawing.Size(63, 20);
            this.btnDelF.Text = "Удалить";
            this.btnDelF.Click += new System.EventHandler(this.btnDelF_Click);
            // 
            // btnUpdateF
            // 
            this.btnUpdateF.Name = "btnUpdateF";
            this.btnUpdateF.Size = new System.Drawing.Size(73, 20);
            this.btnUpdateF.Text = "Обновить";
            this.btnUpdateF.Click += new System.EventHandler(this.btnUpdateF_Click);
            // 
            // btnCancelF
            // 
            this.btnCancelF.Name = "btnCancelF";
            this.btnCancelF.Size = new System.Drawing.Size(51, 20);
            this.btnCancelF.Text = "Назад";
            this.btnCancelF.Click += new System.EventHandler(this.btnCancelF_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4});
            this.dataGridView1.Location = new System.Drawing.Point(12, 27);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(444, 171);
            this.dataGridView1.TabIndex = 12;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Название";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Цена";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Количество";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Сумма";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // ForPCTbl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(470, 260);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txtF);
            this.Controls.Add(this.lbl);
            this.Controls.Add(this.menuStrip1);
            this.Name = "ForPCTbl";
            this.Text = "ForPCTbl";
            this.Load += new System.EventHandler(this.ForPCTbl_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtF;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem btnAddF;
        private System.Windows.Forms.ToolStripMenuItem btnDecideF;
        private System.Windows.Forms.ToolStripMenuItem btnDelF;
        private System.Windows.Forms.ToolStripMenuItem btnUpdateF;
        private System.Windows.Forms.ToolStripMenuItem btnCancelF;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
    }
}