﻿namespace Computer
{
    partial class addForPC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblKol = new System.Windows.Forms.Label();
            this.btnCancelF = new System.Windows.Forms.Button();
            this.btnAddTovarF = new System.Windows.Forms.Button();
            this.lblName = new System.Windows.Forms.Label();
            this.scrPriceF = new System.Windows.Forms.HScrollBar();
            this.lblPriceInfoAc = new System.Windows.Forms.Label();
            this.spnKolF = new System.Windows.Forms.NumericUpDown();
            this.cmbNameF = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.spnKolF)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(65, 125);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(33, 13);
            this.lblPrice.TabIndex = 28;
            this.lblPrice.Text = "Цена";
            // 
            // lblKol
            // 
            this.lblKol.AutoSize = true;
            this.lblKol.Location = new System.Drawing.Point(65, 84);
            this.lblKol.Name = "lblKol";
            this.lblKol.Size = new System.Drawing.Size(66, 13);
            this.lblKol.TabIndex = 26;
            this.lblKol.Text = "Количество";
            // 
            // btnCancelF
            // 
            this.btnCancelF.Location = new System.Drawing.Point(267, 178);
            this.btnCancelF.Name = "btnCancelF";
            this.btnCancelF.Size = new System.Drawing.Size(75, 23);
            this.btnCancelF.TabIndex = 25;
            this.btnCancelF.Text = "Отмена";
            this.btnCancelF.UseVisualStyleBackColor = true;
            this.btnCancelF.Click += new System.EventHandler(this.btnCancelF_Click);
            // 
            // btnAddTovarF
            // 
            this.btnAddTovarF.Location = new System.Drawing.Point(101, 178);
            this.btnAddTovarF.Name = "btnAddTovarF";
            this.btnAddTovarF.Size = new System.Drawing.Size(75, 23);
            this.btnAddTovarF.TabIndex = 24;
            this.btnAddTovarF.Text = "Добавить";
            this.btnAddTovarF.UseVisualStyleBackColor = true;
            this.btnAddTovarF.Click += new System.EventHandler(this.btnAddTovarF_Click);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(65, 43);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(83, 13);
            this.lblName.TabIndex = 20;
            this.lblName.Text = "Наименование";
            // 
            // scrPriceF
            // 
            this.scrPriceF.Location = new System.Drawing.Point(176, 130);
            this.scrPriceF.Maximum = 500000;
            this.scrPriceF.Minimum = 40000;
            this.scrPriceF.Name = "scrPriceF";
            this.scrPriceF.Size = new System.Drawing.Size(120, 17);
            this.scrPriceF.TabIndex = 33;
            this.scrPriceF.Value = 40000;
            this.scrPriceF.Scroll += new System.Windows.Forms.ScrollEventHandler(this.scrPriceF_Scroll);
            // 
            // lblPriceInfoAc
            // 
            this.lblPriceInfoAc.AutoSize = true;
            this.lblPriceInfoAc.Location = new System.Drawing.Point(217, 117);
            this.lblPriceInfoAc.Name = "lblPriceInfoAc";
            this.lblPriceInfoAc.Size = new System.Drawing.Size(43, 13);
            this.lblPriceInfoAc.TabIndex = 32;
            this.lblPriceInfoAc.Text = "500000";
            // 
            // spnKolF
            // 
            this.spnKolF.Location = new System.Drawing.Point(176, 82);
            this.spnKolF.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.spnKolF.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.spnKolF.Name = "spnKolF";
            this.spnKolF.Size = new System.Drawing.Size(120, 20);
            this.spnKolF.TabIndex = 31;
            this.spnKolF.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // cmbNameF
            // 
            this.cmbNameF.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNameF.Items.AddRange(new object[] {
            "Товар 1",
            "Товар 2",
            "Товар 3"});
            this.cmbNameF.Location = new System.Drawing.Point(175, 40);
            this.cmbNameF.Name = "cmbNameF";
            this.cmbNameF.Size = new System.Drawing.Size(121, 21);
            this.cmbNameF.TabIndex = 30;
            // 
            // addForPC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(422, 245);
            this.Controls.Add(this.scrPriceF);
            this.Controls.Add(this.lblPriceInfoAc);
            this.Controls.Add(this.spnKolF);
            this.Controls.Add(this.cmbNameF);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblKol);
            this.Controls.Add(this.btnCancelF);
            this.Controls.Add(this.btnAddTovarF);
            this.Controls.Add(this.lblName);
            this.Name = "addForPC";
            this.Text = "addForPC";
            this.Load += new System.EventHandler(this.addForPC_Load);
            ((System.ComponentModel.ISupportInitialize)(this.spnKolF)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblKol;
        private System.Windows.Forms.Button btnCancelF;
        private System.Windows.Forms.Button btnAddTovarF;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.HScrollBar scrPriceF;
        private System.Windows.Forms.Label lblPriceInfoAc;
        private System.Windows.Forms.NumericUpDown spnKolF;
        private System.Windows.Forms.ComboBox cmbNameF;
    }
}