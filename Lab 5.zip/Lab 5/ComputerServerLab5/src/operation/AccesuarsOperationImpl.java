package operation;

import java.util.ArrayList;
import java.util.List;
import types.Accesuars;

public class AccesuarsOperationImpl implements AccesuarsOperation{
    static List<Accesuars> lstAccesuars = new ArrayList<Accesuars>();
   
    @Override
    public List<Accesuars> getListOfTovarA(){
        return lstAccesuars;
    }
    @Override
    public List<Accesuars> addNewTovarA(Accesuars item){
        lstAccesuars.add(item);
        return lstAccesuars;
    }

    @Override
    public List<Accesuars> delTovarA(int index)
    {
        lstAccesuars.remove(index);
        return lstAccesuars;
    }

    @Override
    public int getSumOfTovarA(){
        int sum =0;
        for(Accesuars accesuars: lstAccesuars)
            sum+= accesuars.getKolA()*accesuars.getPriceA();
        return sum;}}

