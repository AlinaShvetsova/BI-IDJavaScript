package operation;

import java.util.List;

import types.Accesuars;
import types.ForPC;

public interface ForPCOperation{
    List<ForPC> getListOfTovarF();
    List<ForPC> addNewTovarF(ForPC forPC);
    List<ForPC> delTovarF(int index);
    int getSumOfTovarF();
}

