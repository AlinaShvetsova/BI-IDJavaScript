package operation;

import java.util.List;

import types.Accesuars;
import types.Tovar;

public interface TovarOperation{
    List<Tovar> getListOfTovar();
    List<Tovar> addNewTovar(Tovar tovar);
    List<Tovar> delTovar(int index);
    int getSumOfTovar();
}