package operation;

import java.util.ArrayList;
import java.util.List;
import types.ForPC;

public class ForPCOperationImpl implements ForPCOperation{
    static List<ForPC> lstForPC = new ArrayList<ForPC>();
     static {
        lstForPC.add(new ForPC("Товар1", 10, 100));
        lstForPC.add(new ForPC("Товар2", 20, 100));
        lstForPC.add(new ForPC("Товар3", 30, 100));
        lstForPC.add(new ForPC("Товар4", 40, 100));
    }
           
    @Override
    public List<ForPC> getListOfTovarF(){
        return lstForPC;
    }
    @Override
    public List<ForPC> addNewTovarF(ForPC item){
        lstForPC.add(item);
        return lstForPC;
    }

    @Override
    public List<ForPC> delTovarF(int index)
    {
        lstForPC.remove(index);
        return lstForPC;
    }
    @Override
    public int getSumOfTovarF(){
        int sum =0;
        for(ForPC forPC: lstForPC)
            sum+= forPC.getKolF()*forPC.getPriceF();
        return sum;
    }}

