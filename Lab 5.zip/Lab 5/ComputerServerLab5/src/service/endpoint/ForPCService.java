package service.endpoint;

import java.util.List;
import javax.jws.WebMethod;
import javax.jws.WebService;
import operation.ForPCOperationImpl;
import types.ListOfForPC;
import types.ForPC;

@WebService()
public class ForPCService {
    
    static ForPCOperationImpl obj = new ForPCOperationImpl();
    
    @WebMethod()
    public ListOfForPC getAllTovarF(){
        ListOfForPC lstRet = null;
                
        List<ForPC> lst = obj.getListOfTovarF();
        if(lst != null){
            lstRet = new ListOfForPC();
            lstRet.setItem(lst);
        }
        return lstRet; 
    }
    
    @WebMethod()
    public ListOfForPC setNewTovarF(ForPC forpc){
        ListOfForPC lstRet = null;
        
        List<ForPC> lst = obj.addNewTovarF(forpc);
        if(lst != null){
            lstRet = new ListOfForPC();
            lstRet.setItem(lst);
        }
        return lstRet; 
    }
    public ListOfForPC setDelTovarF(int index){
        ListOfForPC lstRet = null;

        List<ForPC> lst = obj.delTovarF(index);
        if(lst != null){
            lstRet = new ListOfForPC();
            lstRet.setItem(lst);
        }
        return lstRet;}
    @WebMethod()
    public int getSumOfTovarF(){
        return obj.getSumOfTovarF();
    }
}
