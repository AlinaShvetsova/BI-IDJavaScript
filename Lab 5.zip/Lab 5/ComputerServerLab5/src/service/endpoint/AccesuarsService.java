package service.endpoint;

import java.util.List;
import javax.jws.WebMethod;
import javax.jws.WebService;
import operation.AccesuarsOperationImpl;
import types.ListOfAccesuars;
import types.Accesuars;

@WebService()
public class AccesuarsService {
    
    static AccesuarsOperationImpl obj = new AccesuarsOperationImpl();
    
    @WebMethod()
    public ListOfAccesuars getAllTovarA(){
        ListOfAccesuars lstRet = null;
                
        List<Accesuars> lst = obj.getListOfTovarA();
        if(lst != null){
            lstRet = new ListOfAccesuars();
            lstRet.setItem(lst);
        }
        return lstRet; 
    }
    
    @WebMethod()
    public ListOfAccesuars setNewTovarA(Accesuars accesuars){
        ListOfAccesuars lstRet = null;
        
        List<Accesuars> lst = obj.addNewTovarA(accesuars);
        if(lst != null){
            lstRet = new ListOfAccesuars();
            lstRet.setItem(lst);
        }
        return lstRet; 
    }
    @WebMethod()
    public ListOfAccesuars setDelTovarA(int index){
        ListOfAccesuars lstRet = null;

        List<Accesuars> lst = obj.delTovarA(index);
        if(lst != null){
            lstRet = new ListOfAccesuars();
            lstRet.setItem(lst);
        }
        return lstRet;
    }
    
    @WebMethod()
    public int getSumOfTovarA(){
        return obj.getSumOfTovarA();
    }
}
