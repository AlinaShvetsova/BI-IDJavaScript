package types;

import java.util.List;

public class ListOfForPC {
    private List<ForPC> item;

    public List<ForPC> getItem() {
        return item;
    }

    public void setItem(List<ForPC> item) {
        this.item = item;
    }
}

