package types;

import java.util.List;

public class ListOfAccesuars {
    private List<Accesuars> item;

    public List<Accesuars> getItem() {
        return item;
    }

    public void setItem(List<Accesuars> item) {
        this.item = item;
    }
}

