package types;

import java.util.List;

public class ListOfTovar {
    private List<Tovar> item;

    public List<Tovar> getItem() {
        return item;
    }

    public void setItem(List<Tovar> item) {
        this.item = item;
    }
}

