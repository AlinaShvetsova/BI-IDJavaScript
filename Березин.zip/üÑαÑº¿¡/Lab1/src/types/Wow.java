package types;

public class Wow{
    private String nameW;
    private int kolW;
    private double priceW;

    public Wow() {
        this.nameW ="";
        this.kolW=0;
        this.priceW=0;
    }

    public Wow(String nameW, int kolW, double priceW) {
        this.nameW = nameW;
        this.kolW = kolW;
        this.priceW = priceW;
    }

    public String getNameW() {
        return nameW;
    }

    public void setNameW(String nameW) {
        this.nameW = nameW;
    }

    public int getKolW() {
        return kolW;
    }

    public void setKolW(int kolW) {
        this.kolW = kolW;
    }

    public double getPriceW() {
        return priceW;
    }

    public void setPriceW(double priceW) {
        this.priceW = priceW;
    }
    
}
