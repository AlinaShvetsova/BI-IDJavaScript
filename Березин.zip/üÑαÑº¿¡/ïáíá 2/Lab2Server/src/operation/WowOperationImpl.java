package operation;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;
import types.Wow;

public class WowOperationImpl extends UnicastRemoteObject implements WowOperation{
    static List<Wow> lstWow = new ArrayList<Wow>();
    
    public WowOperationImpl() throws RemoteException{
   }
    
    @Override
    public List<Wow> getListOfTovarW() throws RemoteException{
        return lstWow;
    }
    
    @Override
    public List<Wow> addNewTovarW(Wow item) throws RemoteException{
        lstWow.add(item);
        return lstWow;
    }
    
    @Override
    public int getSumOfTovarW() throws RemoteException{
        int sum = 0;
        for(Wow wow: lstWow)
            sum+= wow.getKolW()*wow.getPriceW();
        return sum;
    }}

