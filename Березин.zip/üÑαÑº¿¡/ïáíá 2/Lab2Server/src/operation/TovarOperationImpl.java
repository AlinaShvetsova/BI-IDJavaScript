package operation;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;
import types.Tovar;

public class TovarOperationImpl extends UnicastRemoteObject implements TovarOperation{
    static List<Tovar> lstTovar = new ArrayList<Tovar>();
    public TovarOperationImpl() throws RemoteException{
   }
    @Override
    public List<Tovar> getListOfTovar() throws RemoteException{
        return lstTovar;
    }
    @Override
    public List<Tovar> addNewTovar(Tovar item) throws RemoteException{
        lstTovar.add(item);
        return lstTovar;
    }
    @Override
    public int getSumOfTovar() throws RemoteException{
        int sum =0;
        for(Tovar tovar: lstTovar)
            sum+= tovar.getKol()*tovar.getPrice();
        return sum;
    }}

