package base;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import service.endpoint.TovarServiceService;
import service.endpoint.WowServiceService;
import types.ListOfTovar;
import types.ListOfWow;
import types.Tovar;
import types.Wow;

public class menu extends javax.swing.JFrame {
    public menu() {
        initComponents();
    }

   static DefaultTableModel model = new DefaultTableModel();
    static TovarServiceService tovarService = null;
    static{
        tovarService = new TovarServiceService();
    }
    
    static DefaultTableModel model1 = new DefaultTableModel();
    static WowServiceService wowService = null;
    static{
        wowService = new WowServiceService();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tblCoffe = new javax.swing.JDialog();
        txtTotalSumma = new javax.swing.JTextField();
        lbl = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl = new javax.swing.JTable();
        tlBar = new javax.swing.JToolBar();
        btnAdd = new javax.swing.JButton();
        spr1 = new javax.swing.JToolBar.Separator();
        btnDecide = new javax.swing.JButton();
        spr2 = new javax.swing.JToolBar.Separator();
        btnCancelComp = new javax.swing.JButton();
        dlgAddCoffe = new javax.swing.JDialog();
        lblName = new javax.swing.JLabel();
        lblKol = new javax.swing.JLabel();
        cmbName = new javax.swing.JComboBox();
        spnKol = new javax.swing.JSpinner();
        btnAddTovar = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        scrPrice1 = new javax.swing.JScrollBar();
        lblPriceInfo1 = new javax.swing.JLabel();
        lblPrice1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        tblWow = new javax.swing.JDialog();
        txtTotalSumma2 = new javax.swing.JTextField();
        lbl2 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl2 = new javax.swing.JTable();
        tlBar2 = new javax.swing.JToolBar();
        btnAdd2 = new javax.swing.JButton();
        spr5 = new javax.swing.JToolBar.Separator();
        btnDecide2 = new javax.swing.JButton();
        spr6 = new javax.swing.JToolBar.Separator();
        btnCancelComp2 = new javax.swing.JButton();
        Prod = new javax.swing.JDialog();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        dlgAddWow = new javax.swing.JDialog();
        lblName2 = new javax.swing.JLabel();
        lblKol2 = new javax.swing.JLabel();
        cmbName2 = new javax.swing.JComboBox();
        scrPrice3 = new javax.swing.JScrollBar();
        lblPriceInfo3 = new javax.swing.JLabel();
        lblPrice3 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        spnKol2 = new javax.swing.JSpinner();
        btnAddTovar2 = new javax.swing.JButton();
        btnCancel2 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        TehCarta = new javax.swing.JDialog();
        jLabel14 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        Espr = new javax.swing.JDialog();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        Latte = new javax.swing.JDialog();
        jLabel17 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        Cap = new javax.swing.JDialog();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        doCoffe = new javax.swing.JButton();
        Wow = new javax.swing.JButton();
        btnExitMenu = new javax.swing.JButton();
        btnProd = new javax.swing.JButton();
        btnHowDo = new javax.swing.JButton();

        tblCoffe.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                tblCoffeWindowOpened(evt);
            }
        });

        txtTotalSumma.setEditable(false);
        txtTotalSumma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalSummaActionPerformed(evt);
            }
        });

        lbl.setText("Общая сумма товаров");

        tbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "№ п,п", "Название", "Цена", "Количество", "Сумма"
            }
        ));
        tbl.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                tblAncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane1.setViewportView(tbl);

        tlBar.setRollover(true);

        btnAdd.setText("Добавить");
        btnAdd.setFocusable(false);
        btnAdd.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnAdd.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });
        tlBar.add(btnAdd);
        tlBar.add(spr1);

        btnDecide.setText("Вычислить");
        btnDecide.setFocusable(false);
        btnDecide.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnDecide.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnDecide.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDecideActionPerformed(evt);
            }
        });
        tlBar.add(btnDecide);
        tlBar.add(spr2);

        btnCancelComp.setText("Назад");
        btnCancelComp.setFocusable(false);
        btnCancelComp.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnCancelComp.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnCancelComp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelCompActionPerformed(evt);
            }
        });
        tlBar.add(btnCancelComp);

        javax.swing.GroupLayout tblCoffeLayout = new javax.swing.GroupLayout(tblCoffe.getContentPane());
        tblCoffe.getContentPane().setLayout(tblCoffeLayout);
        tblCoffeLayout.setHorizontalGroup(
            tblCoffeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tblCoffeLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(tblCoffeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(tblCoffeLayout.createSequentialGroup()
                        .addComponent(lbl)
                        .addGap(18, 18, 18)
                        .addComponent(txtTotalSumma, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 106, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(tblCoffeLayout.createSequentialGroup()
                .addComponent(tlBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        tblCoffeLayout.setVerticalGroup(
            tblCoffeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tblCoffeLayout.createSequentialGroup()
                .addComponent(tlBar, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(tblCoffeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTotalSumma, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl))
                .addContainerGap(36, Short.MAX_VALUE))
        );

        lblName.setText("Наименование");

        lblKol.setText("Количество");

        cmbName.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Кофе", "Эспрессо", "Латте", "Капучино" }));
        cmbName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbNameActionPerformed(evt);
            }
        });

        spnKol.setModel(new javax.swing.SpinnerNumberModel(Integer.valueOf(0), Integer.valueOf(0), null, Integer.valueOf(1)));

        btnAddTovar.setText("Добавить");
        btnAddTovar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddTovarActionPerformed(evt);
            }
        });

        btnCancel.setText("Отменить");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });

        scrPrice1.setMaximum(250);
        scrPrice1.setMinimum(50);
        scrPrice1.setOrientation(javax.swing.JScrollBar.HORIZONTAL);
        scrPrice1.setToolTipText("");
        scrPrice1.setUnitIncrement(100);
        scrPrice1.addAdjustmentListener(new java.awt.event.AdjustmentListener() {
            public void adjustmentValueChanged(java.awt.event.AdjustmentEvent evt) {
                scrPrice1AdjustmentValueChanged(evt);
            }
        });

        lblPriceInfo1.setText("250");

        lblPrice1.setText("Цена");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel2.setText("Выберите кофе");

        jLabel11.setText("50");

        javax.swing.GroupLayout dlgAddCoffeLayout = new javax.swing.GroupLayout(dlgAddCoffe.getContentPane());
        dlgAddCoffe.getContentPane().setLayout(dlgAddCoffeLayout);
        dlgAddCoffeLayout.setHorizontalGroup(
            dlgAddCoffeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dlgAddCoffeLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(53, 53, 53))
            .addGroup(dlgAddCoffeLayout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(dlgAddCoffeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(dlgAddCoffeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(dlgAddCoffeLayout.createSequentialGroup()
                            .addGroup(dlgAddCoffeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(lblKol)
                                .addComponent(lblName))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(dlgAddCoffeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(spnKol)
                                .addComponent(cmbName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(dlgAddCoffeLayout.createSequentialGroup()
                            .addComponent(lblPrice1)
                            .addGap(27, 27, 27)
                            .addGroup(dlgAddCoffeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel11)
                                .addComponent(scrPrice1, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dlgAddCoffeLayout.createSequentialGroup()
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblPriceInfo1)
                            .addGap(13, 13, 13)))
                    .addGroup(dlgAddCoffeLayout.createSequentialGroup()
                        .addComponent(btnAddTovar)
                        .addGap(75, 75, 75)
                        .addComponent(btnCancel)))
                .addContainerGap(50, Short.MAX_VALUE))
        );
        dlgAddCoffeLayout.setVerticalGroup(
            dlgAddCoffeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dlgAddCoffeLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel2)
                .addGap(29, 29, 29)
                .addGroup(dlgAddCoffeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(dlgAddCoffeLayout.createSequentialGroup()
                        .addComponent(lblName)
                        .addGap(33, 33, 33)
                        .addComponent(lblKol))
                    .addGroup(dlgAddCoffeLayout.createSequentialGroup()
                        .addComponent(cmbName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27)
                        .addComponent(spnKol, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(dlgAddCoffeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblPriceInfo1)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(dlgAddCoffeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(scrPrice1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblPrice1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                .addGroup(dlgAddCoffeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddTovar)
                    .addComponent(btnCancel))
                .addContainerGap())
        );

        tblWow.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                tblWowWindowOpened(evt);
            }
        });

        txtTotalSumma2.setEditable(false);
        txtTotalSumma2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalSumma2ActionPerformed(evt);
            }
        });

        lbl2.setText("Общая сумма товаров");

        tbl2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "№ п,п", "Название", "Цена", "Количество", "Сумма"
            }
        ));
        tbl2.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                tbl2AncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane3.setViewportView(tbl2);

        tlBar2.setRollover(true);

        btnAdd2.setText("Добавить");
        btnAdd2.setFocusable(false);
        btnAdd2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnAdd2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnAdd2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdd2ActionPerformed(evt);
            }
        });
        tlBar2.add(btnAdd2);
        tlBar2.add(spr5);

        btnDecide2.setText("Вычислить");
        btnDecide2.setFocusable(false);
        btnDecide2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnDecide2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnDecide2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDecide2ActionPerformed(evt);
            }
        });
        tlBar2.add(btnDecide2);
        tlBar2.add(spr6);

        btnCancelComp2.setText("Назад");
        btnCancelComp2.setFocusable(false);
        btnCancelComp2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnCancelComp2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnCancelComp2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelComp2ActionPerformed(evt);
            }
        });
        tlBar2.add(btnCancelComp2);

        javax.swing.GroupLayout tblWowLayout = new javax.swing.GroupLayout(tblWow.getContentPane());
        tblWow.getContentPane().setLayout(tblWowLayout);
        tblWowLayout.setHorizontalGroup(
            tblWowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tblWowLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(tblWowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(tblWowLayout.createSequentialGroup()
                        .addComponent(lbl2)
                        .addGap(18, 18, 18)
                        .addComponent(txtTotalSumma2, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 106, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(tblWowLayout.createSequentialGroup()
                .addComponent(tlBar2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        tblWowLayout.setVerticalGroup(
            tblWowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tblWowLayout.createSequentialGroup()
                .addComponent(tlBar2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(tblWowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTotalSumma2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl2))
                .addContainerGap(36, Short.MAX_VALUE))
        );

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setText("Точки продажи");

        jLabel4.setText("Адрес 1");

        jLabel5.setText("Адрес 2");

        jLabel6.setText("Адрес 3");

        jLabel7.setText("Адрес 4");

        jLabel8.setText("Адрес 5");

        jLabel9.setText("Адрес 6");

        jLabel10.setText("Адрес 7");

        jButton1.setText("Назад");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ProdLayout = new javax.swing.GroupLayout(Prod.getContentPane());
        Prod.getContentPane().setLayout(ProdLayout);
        ProdLayout.setHorizontalGroup(
            ProdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ProdLayout.createSequentialGroup()
                .addGroup(ProdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ProdLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel3))
                    .addGroup(ProdLayout.createSequentialGroup()
                        .addGap(69, 69, 69)
                        .addGroup(ProdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(jLabel4)
                            .addComponent(jLabel9)
                            .addComponent(jLabel8)
                            .addComponent(jLabel7)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6))))
                .addContainerGap(21, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ProdLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(55, 55, 55))
        );
        ProdLayout.setVerticalGroup(
            ProdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ProdLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addGap(5, 5, 5)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        lblName2.setText("Наименование");

        lblKol2.setText("Количество");

        cmbName2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Кофе", "Эспрессо", "Латте", "Капучино" }));
        cmbName2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbName2ActionPerformed(evt);
            }
        });

        scrPrice3.setMaximum(150);
        scrPrice3.setMinimum(50);
        scrPrice3.setOrientation(javax.swing.JScrollBar.HORIZONTAL);
        scrPrice3.setToolTipText("");
        scrPrice3.setUnitIncrement(100);
        scrPrice3.addAdjustmentListener(new java.awt.event.AdjustmentListener() {
            public void adjustmentValueChanged(java.awt.event.AdjustmentEvent evt) {
                scrPrice3AdjustmentValueChanged(evt);
            }
        });

        lblPriceInfo3.setText("150");

        lblPrice3.setText("Цена");

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel12.setText("Акция -n%!");

        spnKol2.setModel(new javax.swing.SpinnerNumberModel(Integer.valueOf(0), Integer.valueOf(0), null, Integer.valueOf(1)));

        btnAddTovar2.setText("Добавить");
        btnAddTovar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddTovar2ActionPerformed(evt);
            }
        });

        btnCancel2.setText("Отменить");
        btnCancel2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancel2ActionPerformed(evt);
            }
        });

        jLabel13.setText("50");

        javax.swing.GroupLayout dlgAddWowLayout = new javax.swing.GroupLayout(dlgAddWow.getContentPane());
        dlgAddWow.getContentPane().setLayout(dlgAddWowLayout);
        dlgAddWowLayout.setHorizontalGroup(
            dlgAddWowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dlgAddWowLayout.createSequentialGroup()
                .addGroup(dlgAddWowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(dlgAddWowLayout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addGroup(dlgAddWowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(dlgAddWowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(dlgAddWowLayout.createSequentialGroup()
                                    .addGroup(dlgAddWowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(lblKol2)
                                        .addComponent(lblName2))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addGroup(dlgAddWowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(spnKol2)
                                        .addComponent(cmbName2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(dlgAddWowLayout.createSequentialGroup()
                                    .addComponent(lblPrice3)
                                    .addGap(27, 27, 27)
                                    .addGroup(dlgAddWowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel13)
                                        .addComponent(scrPrice3, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dlgAddWowLayout.createSequentialGroup()
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblPriceInfo3)
                                    .addGap(13, 13, 13)))
                            .addGroup(dlgAddWowLayout.createSequentialGroup()
                                .addComponent(btnAddTovar2)
                                .addGap(75, 75, 75)
                                .addComponent(btnCancel2))))
                    .addGroup(dlgAddWowLayout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addComponent(jLabel12)))
                .addContainerGap(47, Short.MAX_VALUE))
        );
        dlgAddWowLayout.setVerticalGroup(
            dlgAddWowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dlgAddWowLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel12)
                .addGap(28, 28, 28)
                .addGroup(dlgAddWowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(dlgAddWowLayout.createSequentialGroup()
                        .addComponent(lblName2)
                        .addGap(33, 33, 33)
                        .addComponent(lblKol2))
                    .addGroup(dlgAddWowLayout.createSequentialGroup()
                        .addComponent(cmbName2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27)
                        .addComponent(spnKol2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(dlgAddWowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblPriceInfo3)
                    .addComponent(jLabel13))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(dlgAddWowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(scrPrice3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblPrice3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                .addGroup(dlgAddWowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddTovar2)
                    .addComponent(btnCancel2))
                .addContainerGap())
        );

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel14.setText("Технологическая карта");

        jButton2.setText("Эспрессо");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Латте");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Капучино");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton6.setText("Назад");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout TehCartaLayout = new javax.swing.GroupLayout(TehCarta.getContentPane());
        TehCarta.getContentPane().setLayout(TehCartaLayout);
        TehCartaLayout.setHorizontalGroup(
            TehCartaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TehCartaLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(TehCartaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(TehCartaLayout.createSequentialGroup()
                        .addGap(62, 62, 62)
                        .addGroup(TehCartaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        TehCartaLayout.setVerticalGroup(
            TehCartaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TehCartaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel14)
                .addGap(18, 18, 18)
                .addComponent(jButton2)
                .addGap(18, 18, 18)
                .addComponent(jButton3)
                .addGap(18, 18, 18)
                .addComponent(jButton4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                .addComponent(jButton6)
                .addContainerGap())
        );

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel15.setText("Эспрессо");

        jLabel16.setText("Ингридиенты");

        jLabel18.setText("Способ приготовления");

        jButton7.setText("Назад");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jLabel28.setFont(new java.awt.Font("Tahoma", 1, 90)); // NOI18N
        jLabel28.setText("?");

        jLabel29.setFont(new java.awt.Font("Tahoma", 1, 90)); // NOI18N
        jLabel29.setText("?");

        javax.swing.GroupLayout EsprLayout = new javax.swing.GroupLayout(Espr.getContentPane());
        Espr.getContentPane().setLayout(EsprLayout);
        EsprLayout.setHorizontalGroup(
            EsprLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, EsprLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 127, Short.MAX_VALUE)
                .addComponent(jLabel18)
                .addGap(55, 55, 55))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, EsprLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton7)
                .addGap(31, 31, 31))
            .addGroup(EsprLayout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(jLabel29)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel28)
                .addGap(81, 81, 81))
            .addGroup(EsprLayout.createSequentialGroup()
                .addGap(138, 138, 138)
                .addComponent(jLabel15)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        EsprLayout.setVerticalGroup(
            EsprLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EsprLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel15)
                .addGap(17, 17, 17)
                .addGroup(EsprLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(jLabel18))
                .addGap(18, 18, 18)
                .addGroup(EsprLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29)
                    .addComponent(jLabel28))
                .addGap(11, 11, 11)
                .addComponent(jButton7)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Latte.setPreferredSize(new java.awt.Dimension(402, 236));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel17.setText("Латте");

        jLabel19.setText("Ингридиенты");

        jLabel20.setText("Способ приготовления");

        jButton8.setText("Назад");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jLabel24.setFont(new java.awt.Font("Tahoma", 1, 90)); // NOI18N
        jLabel24.setText("?");

        jLabel25.setFont(new java.awt.Font("Tahoma", 1, 90)); // NOI18N
        jLabel25.setText("?");

        javax.swing.GroupLayout LatteLayout = new javax.swing.GroupLayout(Latte.getContentPane());
        Latte.getContentPane().setLayout(LatteLayout);
        LatteLayout.setHorizontalGroup(
            LatteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LatteLayout.createSequentialGroup()
                .addGap(195, 195, 195)
                .addComponent(jLabel17)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(LatteLayout.createSequentialGroup()
                .addGroup(LatteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(LatteLayout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(jLabel19))
                    .addGroup(LatteLayout.createSequentialGroup()
                        .addGap(63, 63, 63)
                        .addComponent(jLabel25)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 117, Short.MAX_VALUE)
                .addGroup(LatteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, LatteLayout.createSequentialGroup()
                        .addComponent(jLabel20)
                        .addGap(55, 55, 55))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, LatteLayout.createSequentialGroup()
                        .addComponent(jLabel24)
                        .addGap(84, 84, 84))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, LatteLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton8)
                .addContainerGap())
        );
        LatteLayout.setVerticalGroup(
            LatteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LatteLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel17)
                .addGap(17, 17, 17)
                .addGroup(LatteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(jLabel20))
                .addGap(18, 18, 18)
                .addGroup(LatteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(jLabel24))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton8)
                .addGap(28, 28, 28))
        );

        Cap.setPreferredSize(new java.awt.Dimension(402, 236));

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel21.setText("Капучино");

        jLabel22.setText("Ингридиенты");

        jLabel23.setText("Способ приготовления");

        jButton9.setText("Назад");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jLabel26.setFont(new java.awt.Font("Tahoma", 1, 90)); // NOI18N
        jLabel26.setText("?");

        jLabel27.setFont(new java.awt.Font("Tahoma", 1, 90)); // NOI18N
        jLabel27.setText("?");

        javax.swing.GroupLayout CapLayout = new javax.swing.GroupLayout(Cap.getContentPane());
        Cap.getContentPane().setLayout(CapLayout);
        CapLayout.setHorizontalGroup(
            CapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CapLayout.createSequentialGroup()
                .addGap(195, 195, 195)
                .addComponent(jLabel21)
                .addContainerGap(115, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CapLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton9)
                .addGap(31, 31, 31))
            .addGroup(CapLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(CapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(CapLayout.createSequentialGroup()
                        .addComponent(jLabel22)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel23)
                        .addGap(55, 55, 55))
                    .addGroup(CapLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel26)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel27)
                        .addGap(73, 73, 73))))
        );
        CapLayout.setVerticalGroup(
            CapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CapLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel21)
                .addGap(17, 17, 17)
                .addGroup(CapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(jLabel23))
                .addGap(11, 11, 11)
                .addGroup(CapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel27, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel26))
                .addGap(18, 18, 18)
                .addComponent(jButton9)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel1.setText("МЕНЮ");

        doCoffe.setText("Выбрать кофе");
        doCoffe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                doCoffeActionPerformed(evt);
            }
        });

        Wow.setText("Бонусы и акции");
        Wow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WowActionPerformed(evt);
            }
        });

        btnExitMenu.setText("Выход");
        btnExitMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitMenuActionPerformed(evt);
            }
        });

        btnProd.setText("Точки продажи");
        btnProd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProdActionPerformed(evt);
            }
        });

        btnHowDo.setText("Технологическая карта");
        btnHowDo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHowDoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnExitMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(93, 93, 93))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnProd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(doCoffe, javax.swing.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE))
                        .addGap(49, 49, 49)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnHowDo, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Wow, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(25, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(169, 169, 169))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(doCoffe, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Wow, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnProd, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnHowDo, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnExitMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void doCoffeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_doCoffeActionPerformed

       tblCoffe.setSize(500, 320);
       tblCoffe.setVisible(true);
    }//GEN-LAST:event_doCoffeActionPerformed

    private void btnExitMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitMenuActionPerformed
        setDefaultCloseOperation(this.EXIT_ON_CLOSE);
        System.exit(0);
    }//GEN-LAST:event_btnExitMenuActionPerformed

    private void txtTotalSummaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalSummaActionPerformed
        setDefaultCloseOperation(this.EXIT_ON_CLOSE);
        System.exit(0);
    }//GEN-LAST:event_txtTotalSummaActionPerformed

    private void tblAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_tblAncestorAdded
        
    }//GEN-LAST:event_tblAncestorAdded

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
        dlgAddCoffe.setSize(334, 273);
        dlgAddCoffe.setVisible(true);
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnDecideActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDecideActionPerformed
        try{
            txtTotalSumma.setText(Integer.toString(tovarService.getTovarServicePort().getSumOfTovar()));}      
            catch(Exception ex){
            ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Не удалось установить соединение с сервером:" + ex.getMessage() + ".",
                "Ошибка",
                JOptionPane.ERROR_MESSAGE);}    
    }//GEN-LAST:event_btnDecideActionPerformed

    private void btnCancelCompActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelCompActionPerformed
        tblCoffe.setVisible(false);
    }//GEN-LAST:event_btnCancelCompActionPerformed

    private void cmbNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbNameActionPerformed

    private void btnAddTovarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddTovarActionPerformed
        dlgAddCoffe.setVisible(false);
        // д.б. код для проверки полей на правильность ввода
        Tovar el = new Tovar();
        el.setName(cmbName.getSelectedItem().toString());
        el.setKol((int) spnKol.getValue());
        el.setPrice(scrPrice1.getValue());
        
        try{
            doVivod2(tovarService.getTovarServicePort().setNewTovar(el));
        }catch (Exception ex) {
            ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Не удалось добавить. Попытайтесь повторить попытку :" + ex.getMessage() + ".",
                "Ошибка",
                JOptionPane.ERROR_MESSAGE);
        } 
    }                                           
    private void doVivod2(ListOfTovar lstTovar){
        doClearTable();
        
        int i = 1;
        for(Tovar tovar: lstTovar.getItem()){
            Object[] rowData = new Object[5];
            rowData[0] = i++;
            rowData[1] = tovar.getName();
            rowData[2] = tovar.getPrice();
            rowData[3] = tovar.getKol();
            rowData[4] = tovar.getPrice() * tovar.getKol();
            model.addRow(rowData);
        }
        }
        private void doClearTable(){
            while (model.getRowCount()>0){
                model.removeRow(0);
            }
    }//GEN-LAST:event_btnAddTovarActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        dlgAddCoffe.setVisible(false);
    }//GEN-LAST:event_btnCancelActionPerformed

    private void WowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WowActionPerformed
        tblWow.setSize(550, 320);
        tblWow.setVisible(true);

    }//GEN-LAST:event_WowActionPerformed

    private void btnProdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProdActionPerformed
        Prod.setSize(400, 420);
        Prod.setVisible(true);
    }//GEN-LAST:event_btnProdActionPerformed

    private void txtTotalSumma2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalSumma2ActionPerformed
        setDefaultCloseOperation(this.EXIT_ON_CLOSE);
        System.exit(0);
    }//GEN-LAST:event_txtTotalSumma2ActionPerformed

    private void tbl2AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_tbl2AncestorAdded
      
    }//GEN-LAST:event_tbl2AncestorAdded

    private void btnAdd2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdd2ActionPerformed
        dlgAddWow.setSize(334, 273);
        dlgAddWow.setVisible(true);
    }//GEN-LAST:event_btnAdd2ActionPerformed

    private void btnDecide2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDecide2ActionPerformed
        try{
            txtTotalSumma2.setText(Integer.toString(wowService.getWowServicePort().getSumOfTovarW()));}      
            catch(Exception ex){
            ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Не удалось установить соединение с сервером:" + ex.getMessage() + ".",
                "Ошибка",
                JOptionPane.ERROR_MESSAGE);}      
    }//GEN-LAST:event_btnDecide2ActionPerformed

    private void btnCancelComp2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelComp2ActionPerformed
        tblWow.setVisible(false);
    }//GEN-LAST:event_btnCancelComp2ActionPerformed

    private void btnHowDoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHowDoActionPerformed
        TehCarta.setSize(550, 320);
        TehCarta.setVisible(true);
    }//GEN-LAST:event_btnHowDoActionPerformed

    private void scrPrice1AdjustmentValueChanged(java.awt.event.AdjustmentEvent evt) {//GEN-FIRST:event_scrPrice1AdjustmentValueChanged
        lblPriceInfo1.setText(Integer.toString((int) scrPrice1.getValue())); // TODO add your handling code here:
    }//GEN-LAST:event_scrPrice1AdjustmentValueChanged

    private void cmbName2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbName2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbName2ActionPerformed

    private void scrPrice3AdjustmentValueChanged(java.awt.event.AdjustmentEvent evt) {//GEN-FIRST:event_scrPrice3AdjustmentValueChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_scrPrice3AdjustmentValueChanged

    private void btnAddTovar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddTovar2ActionPerformed
        dlgAddWow.setVisible(false);
        // д.б. код для проверки полей на правильность ввода
        
        
            Wow el1 = new Wow();
            el1.setNameW(cmbName2.getSelectedItem().toString());
            el1.setKolW((int) spnKol2.getValue());
            el1.setPriceW(scrPrice3.getValue());
    
        try{
            doVivod1(wowService.getWowServicePort().setNewTovarW(el1));
        }catch (Exception ex) {
            ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Не удалось добавить. Попытайтесь повторить попытку :" + ex.getMessage() + ".",
                "Ошибка",
                JOptionPane.ERROR_MESSAGE);
        }}
        

        private void doVivod1(ListOfWow lstTovarW){
            doClearTable1();
            int i = 1;
            for(Wow wow: lstTovarW.getItem()){
                Object[] rowData = new Object[5];
                rowData[0] = i++;
                rowData[1] = wow.getNameW();
                rowData[2] = wow.getPriceW();
                rowData[3] = wow.getKolW();
                rowData[4] = wow.getPriceW() * wow.getKolW();
                model1.addRow(rowData);
            }
        }
        private void doClearTable1(){
            while (model1.getRowCount()>0){
                model1.removeRow(0);
            }
    }//GEN-LAST:event_btnAddTovar2ActionPerformed

    private void btnCancel2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancel2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCancel2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Prod.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        Cap.setSize(402, 236);
        Cap.setVisible(true);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        Espr.setVisible(false);
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        TehCarta.setVisible(false);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        Latte.setVisible(false);
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        Cap.setVisible(false);
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Espr.setSize(402, 236);
        Espr.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        Latte.setSize(402, 236);
        Latte.setVisible(true);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void tblCoffeWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_tblCoffeWindowOpened
               try {
            model = (DefaultTableModel)tbl.getModel(); 
            doVivod2(tovarService.getTovarServicePort().getAllTovar());
        } catch (Exception ex) {
            ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Не удалось установить соединение с сервером:" + ex.getMessage() + ".",
                "Ошибка",
                JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_tblCoffeWindowOpened

    private void tblWowWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_tblWowWindowOpened
                try {
            model1 = (DefaultTableModel)tbl2.getModel(); 
            doVivod1(wowService.getWowServicePort().getAllTovarW());
        } catch (Exception ex) {
            ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Не удалось установить соединение с сервером:" + ex.getMessage() + ".",
                "Ошибка",
                JOptionPane.ERROR_MESSAGE);

        }
    }//GEN-LAST:event_tblWowWindowOpened

    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDialog Cap;
    private javax.swing.JDialog Espr;
    private javax.swing.JDialog Latte;
    private javax.swing.JDialog Prod;
    private javax.swing.JDialog TehCarta;
    private javax.swing.JButton Wow;
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnAdd2;
    private javax.swing.JButton btnAddTovar;
    private javax.swing.JButton btnAddTovar2;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnCancel2;
    private javax.swing.JButton btnCancelComp;
    private javax.swing.JButton btnCancelComp2;
    private javax.swing.JButton btnDecide;
    private javax.swing.JButton btnDecide2;
    private javax.swing.JButton btnExitMenu;
    private javax.swing.JButton btnHowDo;
    private javax.swing.JButton btnProd;
    private javax.swing.JComboBox cmbName;
    private javax.swing.JComboBox cmbName2;
    private javax.swing.JDialog dlgAddCoffe;
    private javax.swing.JDialog dlgAddWow;
    private javax.swing.JButton doCoffe;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lbl;
    private javax.swing.JLabel lbl2;
    private javax.swing.JLabel lblKol;
    private javax.swing.JLabel lblKol2;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblName2;
    private javax.swing.JLabel lblPrice1;
    private javax.swing.JLabel lblPrice3;
    private javax.swing.JLabel lblPriceInfo1;
    private javax.swing.JLabel lblPriceInfo3;
    private javax.swing.JScrollBar scrPrice1;
    private javax.swing.JScrollBar scrPrice3;
    private javax.swing.JSpinner spnKol;
    private javax.swing.JSpinner spnKol2;
    private javax.swing.JToolBar.Separator spr1;
    private javax.swing.JToolBar.Separator spr2;
    private javax.swing.JToolBar.Separator spr5;
    private javax.swing.JToolBar.Separator spr6;
    private javax.swing.JTable tbl;
    private javax.swing.JTable tbl2;
    private javax.swing.JDialog tblCoffe;
    private javax.swing.JDialog tblWow;
    private javax.swing.JToolBar tlBar;
    private javax.swing.JToolBar tlBar2;
    private javax.swing.JTextField txtTotalSumma;
    private javax.swing.JTextField txtTotalSumma2;
    // End of variables declaration//GEN-END:variables
}
