package types;

import java.util.List;

public class ListOfWow {
    private List<Wow> item;

    public List<Wow> getItemw() {
        return item;
    }

    public void setItem(List<Wow> item) {
        this.item = item;
    }

    public Iterable<Wow> getItem() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

