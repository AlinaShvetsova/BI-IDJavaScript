
package types;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "listOfTovar", propOrder = {
    "item"
})
public class ListOfTovar {

    @XmlElement(nillable = true)
    protected List<Tovar> item;

    public List<Tovar> getItem() {
        if (item == null) {
            item = new ArrayList<Tovar>();
        }
        return this.item;
    }

}
