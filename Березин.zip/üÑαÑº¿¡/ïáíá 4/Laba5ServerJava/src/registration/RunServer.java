package registration;

import javax.xml.ws.Endpoint;
import service.endpoint.TovarService;
import service.endpoint.WowService;

public class RunServer {
    public static void main (String[] argv) {
        Endpoint.publish("http://localhost:8080/ws02/TovarService",new TovarService());
        Endpoint.publish("http://localhost:8080/ws02/WowService",new WowService());
    }
}
