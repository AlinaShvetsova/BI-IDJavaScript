package operation;

import java.util.List;
import types.Wow;

public interface WowOperation {
    List<Wow> getListOfTovarW() ;
    List<Wow> addNewTovarW(Wow item);
    List<Wow> delTovarW(int index);
    int getSumOfTovarW();}