package operation;

import java.util.ArrayList;
import java.util.List;
import types.Wow;

public class WowOperationImpl implements WowOperation{
    static List<Wow> lstWow = new ArrayList<Wow>();
    
    public WowOperationImpl() {
   }
    
    @Override
    public List<Wow> getListOfTovarW() {
        return lstWow;
    }
    
    @Override
    public List<Wow> addNewTovarW(Wow item){
        lstWow.add(item);
        return lstWow;
    }
    @Override
    public List<Wow> delTovarW(int index)
    {
        lstWow.remove(index);
        return lstWow;
    }
    @Override
    public int getSumOfTovarW(){
        int sum = 0;
        for(Wow wow: lstWow)
            sum+= wow.getKolW()*wow.getPriceW();
        return sum;
    }}

