 package service.endpoint;

import java.util.List;
import javax.jws.WebMethod;
import javax.jws.WebService;
import operation.WowOperationImpl;
import types.ListOfWow;
import types.Wow;

@WebService()
public class WowService {
    
    static WowOperationImpl obj = new WowOperationImpl();
    
    @WebMethod()
    public ListOfWow getAllTovarW(){
        ListOfWow lstRet = null;
                
        List<Wow> lst = obj.getListOfTovarW();
        if(lst != null){
            lstRet = new ListOfWow();
            lstRet.setItemW(lst);
        }
        return lstRet; 
    }
    
    @WebMethod()
    public ListOfWow setNewTovarW(Wow wow){
        ListOfWow lstRet = null;
        
        List<Wow> lst = obj.addNewTovarW(wow);
        if(lst != null){
            lstRet = new ListOfWow();
            lstRet.setItemW(lst);
        }
        return lstRet; 
    }public ListOfWow setDelTovarW(int index){
        ListOfWow lstRet = null;

        List<Wow> lst = obj.delTovarW(index);
        if(lst != null){
            lstRet = new ListOfWow();
            lstRet.setItemW(lst);
        }
        return lstRet;}
    
    @WebMethod()
    public int getSumOfTovarW(){
        return obj.getSumOfTovarW();
    }
}
