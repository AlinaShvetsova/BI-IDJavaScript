package types;

import java.util.List;

public class ListOfWow {
    private List<Wow> item;

    public List<Wow> getItemw() {
        return item;
    }

    public void setItemW(List<Wow> item) {
        this.item = item;
    }
}

