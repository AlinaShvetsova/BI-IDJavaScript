﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CoffeServer;


namespace CoffeClientSharp
{
    public partial class addCoffe : Form
    {
        ServiceReference1.TovarServiceClient service = new ServiceReference1.TovarServiceClient();
        public addCoffe()
        {
            InitializeComponent();
        }

        private void btnAddTovarA_Click(object sender, EventArgs e)
        {
            ServiceReference1.tovar el = new ServiceReference1.tovar();
            el.name = cmbName.Text;
            el.kol = Convert.ToInt32(spnKol.Value);
            //el.priceA = Convert.ToInt32(scrPriceA.Text);
            el.price = Convert.ToInt32(scrPrice.Value) * Convert.ToInt32(spnKol.Value);

            tblCoffe f = new tblCoffe();
            service.setNewTovar(el);
            f.doVivod();
            this.Close();

        }

        private void btnCancelA_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void scrPriceA_Scroll(object sender, ScrollEventArgs e)
        {
            lblPriceInfo.Text = scrPrice.Value.ToString();
        }

        private void addCoffe_Load(object sender, EventArgs e)
        {
            cmbName.SelectedIndex = 0;
        }
    }
}
