﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using CoffeServer;

namespace CoffeClientSharp
{
    public partial class tblCoffe : Form
    {
        public tblCoffe()
        {
            InitializeComponent();
        }
        ServiceReference1.TovarServiceClient service = new ServiceReference1.TovarServiceClient();
        ServiceReference1.tovar[] arrTovar;

        public void doVivod()
        {
            arrTovar = service.getAllTovar();

            dataGridView1.Rows.Clear();

            foreach (ServiceReference1.tovar el in arrTovar)
            {
                object[] buffer = new object[4];

                buffer[0] = el.name;
                buffer[1] = el.price;
                buffer[2] = el.kol;
                buffer[3] = el.price * el.kol;

                dataGridView1.Rows.Add(buffer);
            }
        }
        TovarOperation tovarOperation = null;

        private void btnAddF_Click(object sender, EventArgs e)
        {
            addCoffe f = new addCoffe();
            f.ShowDialog();
            try
            {
                doVivod();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnDecideF_Click(object sender, EventArgs e)
        {
            try
            {
                txt.Text = tovarOperation.getSumOfTovar().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void tblCoffe_Load(object sender, EventArgs e)
        {
            try
            {
                doVivod();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                doVivod();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 1)
            {
                MessageBox.Show(this, "Выберите элемент для удаления!", "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                try
                {
                    service.setDelTovar(dataGridView1.CurrentRow.Index);
                    doVivod();

                    if (lbl.Text != "")
                        btnDecideF_Click(sender, e);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }
    }
}
