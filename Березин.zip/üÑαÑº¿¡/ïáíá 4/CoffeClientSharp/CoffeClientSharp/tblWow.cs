﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CoffeServer;

namespace CoffeClientSharp
{
    public partial class tblWow : Form
    {
        public tblWow()
        {
            InitializeComponent();
        }
        ServiceReference2.WowServiceClient service = new ServiceReference2.WowServiceClient();
        ServiceReference2.wow[] arrTovar;

        public void doVivod()
        {
            arrTovar = service.getAllTovarW();

            dataGridView1.Rows.Clear();

            foreach (ServiceReference2.wow el in arrTovar)
            {
                object[] buffer = new object[4];

                buffer[0] = el.nameW;
                buffer[1] = el.priceW;
                buffer[2] = el.kolW;
                buffer[3] = el.priceW * el.kolW;

                dataGridView1.Rows.Add(buffer);
            }
        }
        WowOperation wowOperation = null;
        private void tblWow_Load(object sender, EventArgs e)
        {
            try
            {
                doVivod();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            addWow f = new addWow();
            f.ShowDialog();
            try
            {
                doVivod();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

            private void btnDecide_Click(object sender, EventArgs e)
        {
            try
            {
                txt.Text = wowOperation.getSumOfTovarW().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 1)
            {
                MessageBox.Show(this, "Выберите элемент для удаления!", "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                try
                {
                    service.setDelTovarW(dataGridView1.CurrentRow.Index);
                    doVivod();

                    if (lbl.Text != "")
                        btnDecide_Click(sender, e);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                doVivod();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
