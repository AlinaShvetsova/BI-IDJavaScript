﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeServer
{
    public class WowOperationImpl : MarshalByRefObject, WowOperation
    {
        public static List<Wow> lstTovarW = new List<Wow>();

        public List<Wow> getListOfTovarW()
        {
            return lstTovarW;
        }
        public List<Wow> addNewTovarW(Wow item)
        {
            lstTovarW.Add(item);
            return lstTovarW;
        }
        public List<Wow> delTovarW(int index)
        {
            lstTovarW.RemoveAt(index);
            return lstTovarW;
        }
        public int getSumOfTovarW()
        {
            int sum = 0;
            foreach (Wow wow in lstTovarW)
                sum += wow.getKolW() * wow.getPriceW();
            return sum;
        }
    }
}