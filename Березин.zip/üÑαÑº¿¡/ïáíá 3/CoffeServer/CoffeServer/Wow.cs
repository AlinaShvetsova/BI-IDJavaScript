﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeServer
{
    [Serializable]
    public class Wow
    {
        private String nameW;
        private int kolW;
        private int priceW;

        public Wow()
        {
            this.nameW = "";
            this.kolW = 0;
            this.priceW = 0;
        }

        public Wow(String nameW, int kolW, int priceW)
        {
            this.nameW = nameW;
            this.kolW = kolW;
            this.priceW = priceW;
        }

        public String getNameW()
        {
            return nameW;
        }

        public void setNameW(String nameW)
        {
            this.nameW = nameW;
        }

        public int getKolW()
        {
            return kolW;
        }

        public void setKolW(int kolW)
        {
            this.kolW = kolW;
        }

        public int getPriceW()
        {
            return priceW;
        }

        public void setPriceW(int priceW)
        {
            this.priceW = priceW;
        }
    }
}
