﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeServer
{
    public interface WowOperation
    {
        List<Wow> getListOfTovarW();
        List<Wow> addNewTovarW(Wow item);
        List<Wow> delTovarW(int index);
        int getSumOfTovarW();
    }
}
