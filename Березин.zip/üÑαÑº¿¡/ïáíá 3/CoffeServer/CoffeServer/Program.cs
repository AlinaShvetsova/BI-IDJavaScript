﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;


namespace CoffeServer
{
    class Program
    {
        static void Main()
        {
            // Register channel
            TcpChannel channel = new TcpChannel(9000);
            ChannelServices.RegisterChannel(channel, false);
            TovarOperationImpl lstTovar = new TovarOperationImpl();
            RemotingServices.Marshal(lstTovar, "TalkIsGoodTovar");

            WowOperationImpl lstTovarW = new WowOperationImpl();
            RemotingServices.Marshal(lstTovarW, "TalkIsGoodWow");

            // Register MyRemoteObject
            /* RemotingConfiguration.RegisterWellKnownServiceType(
                 typeof(TovarOperationImpl),
                 "TalkIsGood",
                 WellKnownObjectMode.Singleton);*/
            // Также можно зарегестрировать не тип, а неоходимый объект:

            //lstTovar – объект, который необходимо передать, "TalkIsGood" - параметр, который //используется клиентом для активизации объекта (унифицированный идентификатор ресурса)
            Console.WriteLine("Press enter to stop this process.");
            Console.ReadLine();
        }
    }
}

