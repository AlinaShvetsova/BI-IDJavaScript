﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CoffeServer;


namespace CoffeClientSharp
{
    public partial class addWow : Form
    {
        Wow wow = null;
        public addWow()
        {
            InitializeComponent();
        }
        public Wow getTovarW
        {
            get
            {
                return wow;
            }
        }

        private void addWow_Load(object sender, EventArgs e)
        {
            cmbName.SelectedIndex = 0;
        }

        private void btnCancelA_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAddTovarA_Click(object sender, EventArgs e)
        {
            //код проверки на правильность ввода
            if (rdbYesParam.Checked)
            {
                wow = new Wow(cmbName.SelectedItem.ToString(), Convert.ToInt32(spnKol.Value), scrPrice.Value);
            }
            else
            {
                wow = new Wow();
                wow.setNameW(cmbName.SelectedItem.ToString());
                wow.setKolW(Convert.ToInt32(spnKol.Value));
                wow.setPriceW(scrPrice.Value);
            }
            this.Close();
        }

        private void scrPrice_Scroll(object sender, ScrollEventArgs e)
        {
            lblPriceInfo.Text = scrPrice.Value.ToString();
        }
    }
}
