﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CoffeServer;


namespace CoffeClientSharp
{
    public partial class addCoffe : Form
    {
        Tovar tovar = null;
        public addCoffe()
        {
            InitializeComponent();
        }

        private void btnAddTovarA_Click(object sender, EventArgs e)
        {
            //код проверки на правильность ввода
            if (rdbYesParam.Checked)
            {
                tovar = new Tovar(cmbName.SelectedItem.ToString(), Convert.ToInt32(spnKol.Value), scrPrice.Value);
            }
            else
            {
                tovar = new Tovar();
                tovar.setName(cmbName.SelectedItem.ToString());
                tovar.setKol(Convert.ToInt32(spnKol.Value));
                tovar.setPrice(scrPrice.Value);
            }
            this.Close();

        }

        private void btnCancelA_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void scrPriceA_Scroll(object sender, ScrollEventArgs e)
        {
            lblPriceInfo.Text = scrPrice.Value.ToString();
        }
        public Tovar getTovar
        {
            get
            {
                return tovar;
            }
        }

        private void addCoffe_Load(object sender, EventArgs e)
        {
            cmbName.SelectedIndex = 0;
        }
    }
}
