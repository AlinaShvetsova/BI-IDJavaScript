﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CoffeServer;

namespace CoffeClientSharp
{
    public partial class tblWow : Form
    {
        public tblWow()
        {
            InitializeComponent();
        }
        private void doVivod(List<CoffeServer.Wow> lstTovarW)
        {
            lvListW.Items.Clear();
            int i = 1;
            foreach (CoffeServer.Wow wow in lstTovarW)
            {
                ListViewItem newItem = new ListViewItem(i.ToString());
                lvListW.Items.Add(newItem);
                newItem.SubItems.Add(wow.getNameW());
                newItem.SubItems.Add(wow.getPriceW().ToString());
                newItem.SubItems.Add(wow.getKolW().ToString());
                newItem.SubItems.Add((wow.getKolW() * wow.getPriceW()).ToString());
                i++;
            }
        }
        WowOperation wowOperation = null;
        private void tblWow_Load(object sender, EventArgs e)
        {
            try
            {
                TcpClientChannel chan = new TcpClientChannel();
                ChannelServices.RegisterChannel(chan, false);
                wowOperation = (WowOperation)Activator.GetObject(
                typeof(WowOperation), "tcp://localhost:9000/TalkIsGoodWow");
                doVivod(wowOperation.getListOfTovarW());
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            addWow f = new addWow();
            f.ShowDialog();
            if (f.getTovarW != null)
            {
                try
                {
                    doVivod(wowOperation.addNewTovarW(f.getTovarW));
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            if (txt.Text != "") btnDecide_Click(sender, e);
        }

        private void btnDecide_Click(object sender, EventArgs e)
        {
            try
            {
                txt.Text = wowOperation.getSumOfTovarW().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            try
            {
                wowOperation.delTovarW(lvListW.SelectedIndices[0]);
                doVivod(wowOperation.getListOfTovarW());
                if (txt.Text != "") btnDecide_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                doVivod(wowOperation.getListOfTovarW());
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка соединения: +" + ex, "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
