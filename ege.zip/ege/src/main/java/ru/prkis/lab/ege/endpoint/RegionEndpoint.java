package ru.prkis.lab.ege.endpoint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import ru.prkis.lab.ege.service.RegionService;
import ru.vyatgu.prkis.lab.ege.*;

@Endpoint
public class RegionEndpoint {
    private static final String NAMESPACE_URI = "http://vyatgu.ru/prkis/lab/ege";

    /**
     * Сервис для работы с группами
     */
    private final RegionService regionService;

    @Autowired
    public RegionEndpoint(RegionService regionService){
        this.regionService=regionService;
    }
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getAddRegionRequest")
    @ResponsePayload
    public GetAddRegionResponse getAllRegions(@RequestPayload  GetAddRegionRequest request) throws Exception{
        // создаем объект ответа сервиса
        GetAddRegionResponse response = new GetAddRegionResponse();
        // записываем в него результат.
        response.setRegion(regionService.addRegion(request.getRegion()));
        return response;
    }
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getRegionByIdRequest")
    @ResponsePayload
    public GetRegionByIdResponse getAllRegions(@RequestPayload GetRegionByIdRequest request) throws Exception {
        GetRegionByIdResponse response = new GetRegionByIdResponse();
        response.setRegion(regionService.getByIdRegion(request.getIdRegion()));
        return response;
    }
    @PayloadRoot(namespace = NAMESPACE_URI,localPart = "getAllRegionRequest")
    @ResponsePayload
    public GetAllRegionResponse getAllRegion(@RequestPayload GetAllRegionRequest request) throws Exception {
        GetAllRegionResponse response = new GetAllRegionResponse();
        response.getRegion().addAll(regionService.getAllRegion());
        return response;
    }
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getDeleteRegionRequest")
    @ResponsePayload
    public GetDeleteRegionResponse getDeleteRegion(@RequestPayload GetDeleteRegionRequest request) throws Exception{
        GetDeleteRegionResponse response = new GetDeleteRegionResponse();
        response.setRegion(regionService.delete(request.getIdRegion()));
        return response;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getChangeRegionRequest")
    @ResponsePayload
    public GetChangeRegionResponse getChangeRegion(@RequestPayload GetChangeRegionRequest request) throws Exception{
        GetChangeRegionResponse response = new GetChangeRegionResponse();
        response.setRegion(regionService.changeRegion(request.getRegion()));
        return response;
    }
}
