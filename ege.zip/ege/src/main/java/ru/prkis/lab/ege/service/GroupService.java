package ru.prkis.lab.ege.service;

import org.springframework.stereotype.Service;
import ru.vyatgu.prkis.lab.sample.Group;

import java.util.ArrayList;
import java.util.List;

@Service
public class GroupService {
    private static List<Group> testGroups;
    private List<Group> getTestGroups(){
        if(testGroups != null){
            return testGroups;
        }
        testGroups = new ArrayList<>();
        for(long i=1; i<=10;i++){
            Group testGroup = new Group();
            testGroup.setId(i);
            testGroup.setName("Наименование группы "+i);
            testGroup.setDescription("Описание группы "+i);
            testGroups.add(testGroup);
        }
        return testGroups;
    }

    public List<Group> getAll(){
        return getTestGroups();
    }
    public Group addGroup(Group newGroup){
        getTestGroups().add(newGroup);
        return newGroup;
    }}

