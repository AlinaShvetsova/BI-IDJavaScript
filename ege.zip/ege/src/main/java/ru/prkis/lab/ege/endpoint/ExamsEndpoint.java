package ru.prkis.lab.ege.endpoint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import ru.prkis.lab.ege.service.ExamsService;
import ru.vyatgu.prkis.lab.ege.*;

@Endpoint
public class ExamsEndpoint {
    private static final String NAMESPACE_URI = "http://vyatgu.ru/prkis/lab/ege";

    private final ExamsService examsService;

    @Autowired
    public ExamsEndpoint(ExamsService examsService){
        this.examsService=examsService;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart="getAddExamsRequest")
    @ResponsePayload
    public GetAddExamsResponse getAllExams(@RequestPayload GetAddExamsRequest request) throws Exception{
        GetAddExamsResponse response = new GetAddExamsResponse();
        response.setExams(examsService.addExams(request.getExams()));
        return response;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart="getExamsByIdRequest")
    @ResponsePayload
    public GetExamsByIdResponse getByIdExams(@RequestPayload GetExamsByIdRequest request) throws Exception{
        GetExamsByIdResponse response = new GetExamsByIdResponse();
        response.setExams(examsService.getByIdExams(request.getIdExam()));
        return response;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart="getAllExamsRequest")
    @ResponsePayload
    public GetAllExamsResponse getAllExams(@RequestPayload GetAllExamsRequest request) throws Exception {
        GetAllExamsResponse response = new GetAllExamsResponse();
        response.getExams().addAll(examsService.getAllExams());
        return response;}

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getDeleteExamsRequest")
    @ResponsePayload
    public GetDeleteExamsResponse getDeleteExams(@RequestPayload GetDeleteExamsRequest request) throws Exception{
        GetDeleteExamsResponse response = new GetDeleteExamsResponse();
        response.setExams(examsService.delete(request.getIdExams()));
        return response;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getChangeExamsRequest")
    @ResponsePayload
    public GetChangeExamsResponse getChangeExams(@RequestPayload GetChangeExamsRequest request) throws Exception{
        GetChangeExamsResponse response = new GetChangeExamsResponse();
        response.setExams(examsService.changeExams(request.getExams()));
        return response;
    }}
