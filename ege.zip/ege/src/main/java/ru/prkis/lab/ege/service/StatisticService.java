package ru.prkis.lab.ege.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.prkis.lab.ege.entity.StatisticEntity;
import ru.prkis.lab.ege.repositoy.StatisticRepository;
import ru.vyatgu.prkis.lab.ege.Statistic;


import java.util.ArrayList;
import java.util.List;

@Service
public class StatisticService {
    @Autowired
    private StatisticRepository statisticRepository;
    //Преобразование данных из БД в формат SOAP-сервиса
    private Statistic mapEntityToBean(StatisticEntity entity){
        Statistic bean = new Statistic();
        bean.setIdStatistic(entity.getIdStatistic());
        bean.setIdExam(entity.getIdExam());
        bean.setIdRegion(entity.getIdRegion());
        bean.setQuarnity(entity.getQuarnity());
        bean.setPoints(entity.getPoints());
        bean.setFailedExam(entity.getFailedExam());
        bean.setDayMonthYear(entity.getDayMonthYear());
        return bean;
    }
    //Преобразование данных из SOAP-сервиса в формат БД
    private StatisticEntity mapBeanToEntity(Statistic bean) {
        StatisticEntity entity = new StatisticEntity();
        entity.setIdStatistic(bean.getIdStatistic());
        entity.setIdExam(bean.getIdExam());
        entity.setIdRegion(bean.getIdRegion());
        entity.setQuarnity(bean.getQuarnity());
        entity.setPoints(bean.getPoints());
        entity.setFailedExam(bean.getFailedExam());
        entity.setDayMonthYear(bean.getDayMonthYear());
        return entity;
    }
    public List<Statistic> getAllStatistic(){
        //Получаем все записи из БД
        List<StatisticEntity> statisticFromBd = statisticRepository.findAll();
        //Список для возврата из метода
        List<Statistic> statistic = new ArrayList<>();
        //преобразуем все объекты из БД в объекты SOAP-сервиса
        for(StatisticEntity statisticEntity: statisticFromBd){
            statistic.add(mapEntityToBean(statisticEntity));
        }
        return statistic;
    }

    //Добавление нового экзамена
    public Statistic addStatistic(Statistic newStatistic){
        //Сохраняем новый экзамен в БД
        StatisticEntity newStatisticEntity = statisticRepository.save(mapBeanToEntity(newStatistic));
        //Устанавливаем идентификатор сгенерированный при добавлении записи в БД
        newStatistic.setIdStatistic(newStatisticEntity.getIdStatistic());
        return newStatistic;
    }

    public Statistic getByIdStatistic(long id){
        return mapEntityToBean(statisticRepository.findById(id).get());
    }

    public Statistic delete(long id){
        StatisticEntity tmp = statisticRepository.findById(id).get();
        Statistic statistic = mapEntityToBean(tmp);
        statisticRepository.deleteById(id);
        return statistic;
        }

    public Statistic changeStatistic(Statistic newStatistic){
        StatisticEntity tmp = statisticRepository.save(mapBeanToEntity(newStatistic));
        newStatistic.setIdStatistic(tmp.getIdStatistic());
        return newStatistic;
    }}