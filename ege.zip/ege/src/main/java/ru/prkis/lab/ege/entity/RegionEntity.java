package ru.prkis.lab.ege.entity;

import javax.persistence.*;

@Entity
@Table(name = "REGION_TABLE")
public class RegionEntity {
    @Id
    @Column(nullable = false, unique =  true)
    private Long id_region;

    @Column(nullable = false, unique =  true)
    private Long code_region;
    //Наименование группы

    @Column(length = 100, nullable = true, unique = true)
    private String name_region;
    // далее геттеры и сеттеры

    public long getIdRegion() {
        return id_region;
    }

    /**
     * Sets the value of the idRegion property.
     *
     */
    public void setIdRegion(long value) {
        this.id_region = value;
    }

    /**
     * Gets the value of the codeRegion property.
     *
     */
    public long getCodeRegion() {
        return code_region;
    }

    /**
     * Sets the value of the codeRegion property.
     *
     */
    public void setCodeRegion(long value) {
        this.code_region = value;
    }

    /**
     * Gets the value of the nameRegion property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNameRegion() {
        return name_region;
    }

    /**
     * Sets the value of the nameRegion property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setNameRegion(String value) {
        this.name_region = value;
    }

}
