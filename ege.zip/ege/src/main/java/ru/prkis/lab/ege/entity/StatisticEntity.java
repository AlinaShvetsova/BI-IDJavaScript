package ru.prkis.lab.ege.entity;

import javax.persistence.*;

@Entity
@Table(name = "STATISTIC_TABLE")
public class StatisticEntity {
    @Id
    @Column(nullable = false, unique =  true)
    private Long id_statistic;

    @Column(nullable = false, unique =  true)
    private Long id_exam;

    @Column(nullable = false, unique =  true)
    private Long id_region;

    @Column(nullable = false, unique =  true)
    private Long quarnity;

    @Column(nullable = false, unique =  true)
    private Long points;

    @Column(nullable = false, unique =  true)
    private Long failed_exam;


    @Column(nullable = false, unique = true)
    private String day_month_year;

    public long getIdStatistic() {
        return id_statistic;
    }

    /**
     * Sets the value of the idStatistic property.
     *
     */
    public void setIdStatistic(long value) {
        this.id_statistic = value;
    }

    /**
     * Gets the value of the idExam property.
     *
     */
    public long getIdExam() {
        return id_exam;
    }

    /**
     * Sets the value of the idExam property.
     *
     */
    public void setIdExam(long value) {
        this.id_exam = value;
    }

    /**
     * Gets the value of the idRegion property.
     *
     */
    public long getIdRegion() {
        return id_region;
    }

    /**
     * Sets the value of the idRegion property.
     *
     */
    public void setIdRegion(long value) {
        this.id_region = value;
    }

    /**
     * Gets the value of the quarnity property.
     *
     */
    public long getQuarnity() {
        return quarnity;
    }

    /**
     * Sets the value of the quarnity property.
     *
     */
    public void setQuarnity(long value) {
        this.quarnity = value;
    }

    /**
     * Gets the value of the points property.
     *
     */
    public long getPoints() {
        return points;
    }

    /**
     * Sets the value of the points property.
     *
     */
    public void setPoints(long value) {
        this.points = value;
    }

    /**
     * Gets the value of the failedExam property.
     *
     */
    public long getFailedExam() {
        return failed_exam;
    }

    /**
     * Sets the value of the failedExam property.
     *
     */
    public void setFailedExam(long value) {
        this.failed_exam = value;
    }

    /**
     * Gets the value of the dayMonthYear property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDayMonthYear() {
        return day_month_year;
    }

    /**
     * Sets the value of the dayMonthYear property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDayMonthYear(String value) {
        this.day_month_year = value;
    }

}