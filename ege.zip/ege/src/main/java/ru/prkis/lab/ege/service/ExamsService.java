package ru.prkis.lab.ege.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.prkis.lab.ege.entity.ExamsEntity;
import ru.prkis.lab.ege.repositoy.ExamsRepository;
import ru.vyatgu.prkis.lab.ege.Exams;
import java.util.ArrayList;
import java.util.List;

@Service
public class ExamsService {
    @Autowired
    private ExamsRepository examsRepository;

    //Преобразование данных из БД в формат SOAP-сервиса
    private Exams mapEntityToBean(ExamsEntity entity){
            Exams bean = new Exams();
            bean.setIdExam(entity.getIdExam());
            bean.setNameExam(entity.getNameExam());
            bean.setDescription(entity.getDescription());
            return bean;
    }

    //Преобразование данных из SOAP-сервиса в формат БД
    private ExamsEntity mapBeanToEntity(Exams bean) {
        ExamsEntity entity = new ExamsEntity();
        entity.setIdExam(bean.getIdExam());
        entity.setNameExam(bean.getNameExam());
        entity.setDescription(bean.getDescription());
        return entity;
    }
    public List<Exams> getAllExams(){
        //Получаем все записи из БД
        List<ExamsEntity> examsFromBd = examsRepository.findAll();
        //Список для возврата из метода
        List<Exams> exams = new ArrayList<>();
        //преобразуем все объекты из БД в объекты SOAP-сервиса
        for(ExamsEntity examsEntity: examsFromBd){
            exams.add(mapEntityToBean(examsEntity));
        }
        return exams;
    }

    //Добавление нового экзамена
    public Exams addExams(Exams newExams){
        //Сохраняем новый экзамен в БД
         ExamsEntity newExamsEntity = examsRepository.save(mapBeanToEntity(newExams));
        //Устанавливаем идентификатор сгенерированный при добавлении записи в БД
        newExams.setIdExam(newExamsEntity.getIdExam());
        return newExams;
    }
    public Exams getByIdExams(long id){
        return mapEntityToBean(examsRepository.findById(id).get());
    }

    public Exams delete(long id){
        ExamsEntity tmp = examsRepository.findById(id).get();
        Exams exams = mapEntityToBean(tmp);
        examsRepository.deleteById(id);
        return exams;
    }

    public Exams changeExams(Exams newExams) {
        ExamsEntity tmp = examsRepository.save(mapBeanToEntity(newExams));
        newExams.setIdExam(tmp.getIdExam());
        return newExams;
    }
}

