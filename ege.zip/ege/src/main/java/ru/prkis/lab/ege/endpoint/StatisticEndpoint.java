package ru.prkis.lab.ege.endpoint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import ru.prkis.lab.ege.service.StatisticService;
import ru.vyatgu.prkis.lab.ege.*;

@Endpoint
public class StatisticEndpoint {
    private static final String NAMESPACE_URI = "http://vyatgu.ru/prkis/lab/ege";

    /**
     * Сервис для работы с группами
     */
    private final StatisticService statisticService;

    @Autowired
    public StatisticEndpoint(StatisticService statisticService){
        this.statisticService=statisticService;
    }
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getAddStatisticRequest")
    @ResponsePayload
    public GetAddStatisticResponse getAllStatistic(@RequestPayload  GetAddStatisticRequest request) throws Exception{
        // создаем объект ответа сервиса
        GetAddStatisticResponse response = new GetAddStatisticResponse();
        // записываем в него результат.
        response.setStatistic(statisticService.addStatistic(request.getStatistic()));
        return response;
    }
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getStatisticByIdRequest")
    @ResponsePayload
    public GetStatisticByIdResponse getAllRain(@RequestPayload GetStatisticByIdRequest request) throws Exception {
        GetStatisticByIdResponse response = new GetStatisticByIdResponse();
        response.setStatistic(statisticService.getByIdStatistic(request.getIdStatistic()));
        return response;
    }
    @PayloadRoot(namespace = NAMESPACE_URI,localPart = "getAllStatisticRequest")
    @ResponsePayload
    public GetAllStatisticResponse getAllStatistic(@RequestPayload GetAllStatisticRequest request) throws Exception {
        GetAllStatisticResponse response = new GetAllStatisticResponse();
        response.getStatistic().addAll(statisticService.getAllStatistic());
        return response;
    }
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getDeleteStatisticRequest")
    @ResponsePayload
    public GetDeleteStatisticResponse getDeleteStatistic(@RequestPayload GetDeleteStatisticRequest request) throws Exception{
        GetDeleteStatisticResponse response = new GetDeleteStatisticResponse();
        response.setStatistic(statisticService.delete(request.getIdStatistic()));
        return response;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getChangeStatisticRequest")
    @ResponsePayload
    public GetChangeStatisticResponse getChangeRain(@RequestPayload GetChangeStatisticRequest request) throws Exception{
        GetChangeStatisticResponse response = new GetChangeStatisticResponse();
        response.setStatistic(statisticService.changeStatistic(request.getStatistic()));
        return response;
    }
}

