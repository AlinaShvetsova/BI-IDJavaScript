package ru.prkis.lab.ege.entity;

import javax.persistence.*;

@Entity
@Table(name = "EXAMS_TABLE")
public class ExamsEntity {
    @Id
    @Column(nullable = false, unique =  true)
    private Long id_exams;

    //Наименование группы

    @Column(length = 50, nullable = true, unique = true)
    private String name_exam;

    @Column(columnDefinition = "TEXT")
    private String description;
    // геттеры и сеттеры

    public long getIdExam() {
        return id_exams;
    }

    /**
     * Sets the value of the idExam property.
     *
     */
    public void setIdExam(long value) {
        this.id_exams = value;
    }

    /**
     * Gets the value of the nameExam property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNameExam() {
        return name_exam;
    }

    /**
     * Sets the value of the nameExam property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setNameExam(String value) {
        this.name_exam = value;
    }

    /**
     * Gets the value of the description property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDescription(String value) {
        this.description = value;
    }

}
