package ru.prkis.lab.ege.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.prkis.lab.ege.entity.ExamsEntity;
import ru.prkis.lab.ege.entity.RegionEntity;
import ru.prkis.lab.ege.repositoy.RegionRepository;
import ru.vyatgu.prkis.lab.ege.Exams;
import ru.vyatgu.prkis.lab.ege.Region;

import java.util.ArrayList;
import java.util.List;

@Service
public class RegionService {
    @Autowired
    private RegionRepository regionRepository;
    //Преобразование данных из БД в формат SOAP-сервиса
    private Region mapEntityToBean(RegionEntity entity){
        Region bean = new Region();
        bean.setIdRegion(entity.getIdRegion());
        bean.setCodeRegion(entity.getCodeRegion());
        bean.setNameRegion(entity.getNameRegion());

        return bean;
    }

    //Преобразование данных из SOAP-сервиса в формат БД
    private RegionEntity mapBeanToEntity(Region bean) {
        RegionEntity entity = new RegionEntity();
        entity.setIdRegion(bean.getIdRegion());
        entity.setCodeRegion(bean.getCodeRegion());
        entity.setNameRegion(bean.getNameRegion());
        return entity;
    }
    public List<Region> getAllRegion(){
        //Получаем все записи из БД
        List<RegionEntity> regionFromBd = regionRepository.findAll();
        //Список для возврата из метода
        List<Region> region = new ArrayList<>();
        //преобразуем все объекты из БД в объекты SOAP-сервиса
        for(RegionEntity regionEntity: regionFromBd){
            region.add(mapEntityToBean(regionEntity));
        }
        return region;
    }

    //Добавление нового экзамена
    public Region addRegion(Region newRegions){
        //Сохраняем новый экзамен в БД
        RegionEntity newRegionEntity = regionRepository.save(mapBeanToEntity(newRegions));
        //Устанавливаем идентификатор сгенерированный при добавлении записи в БД
        newRegions.setIdRegion(newRegionEntity.getIdRegion());
        return newRegions;
    }

    public Region getByIdRegion(long id){
        return mapEntityToBean(regionRepository.findById(id).get());
    }

    public Region delete(long id){
        RegionEntity tmp = regionRepository.findById(id).get();
        Region region = mapEntityToBean(tmp);
        regionRepository.deleteById(id);
        return region;
    }

    public Region changeRegion(Region newRegion) {
        RegionEntity tmp = regionRepository.save(mapBeanToEntity(newRegion));
        newRegion.setIdRegion(tmp.getIdRegion());
        return newRegion;
    }}

