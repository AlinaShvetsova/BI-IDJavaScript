package ru.prkis.lab.ege.repositoy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.prkis.lab.ege.entity.RegionEntity;

@Repository
public interface RegionRepository extends JpaRepository<RegionEntity, Long>{
}