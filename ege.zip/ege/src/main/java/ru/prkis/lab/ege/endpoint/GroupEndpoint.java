package ru.prkis.lab.ege.endpoint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import ru.prkis.lab.ege.service.GroupService;
import ru.vyatgu.prkis.lab.sample.*;

@Endpoint
public class GroupEndpoint {
    private static final String NAMESPACE_URI = "http://vyatgu.ru/prkis/lab/sample";

    private final GroupService groupService;

    @Autowired
    public GroupEndpoint(GroupService groupService){
        this.groupService=groupService;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart="getAddGroupRequest")
    @ResponsePayload
    public GetAddGroupResponse getAllGroups(@RequestPayload GetAddGroupRequest request) throws Exception{
        GetAddGroupResponse response = new GetAddGroupResponse();
        response.setGroup(groupService.addGroup(request.getGroup()));
        return response;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart="getGroupByIdRequest")
    @ResponsePayload
    public GetGroupByIdResponse getGroupById(@RequestPayload GetGroupByIdRequest request) throws Exception{
        GetGroupByIdResponse response = new GetGroupByIdResponse();
        response.setGroup(groupService.addGroup(request.getGroup()));
        return response;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart="getAllGroupRequest")
    @ResponsePayload
    public GetAllGroupsResponse getAllGroups(@RequestPayload GetAllGroupsRequest request) throws Exception {
        GetAllGroupsResponse response = new GetAllGroupsResponse();
        response.getGroup().addAll(groupService.getAll());
        return response;}}
