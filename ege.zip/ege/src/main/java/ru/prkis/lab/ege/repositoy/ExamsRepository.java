package ru.prkis.lab.ege.repositoy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.prkis.lab.ege.entity.ExamsEntity;

@Repository
public interface ExamsRepository extends JpaRepository<ExamsEntity, Long>{
}
